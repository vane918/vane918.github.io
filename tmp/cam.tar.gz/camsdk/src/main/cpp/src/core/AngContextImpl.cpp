/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "AngContextImpl.h"
#include "AngLog.hpp"
#include "AndroidDeviceWatcher.h"
#include "AngUtil.h"
#include "Mutex.h"

#include <string>

using namespace ang;

static DeviceWatcher* g_device_watcher = new AndroidDeviceWatcher();

static std::atomic<bool> g_start_monitor;

static std::vector<std::string> g_hot_plug_dev;

Mutex restart_mutex_;

ContextImpl::ContextImpl() : auto_reconnect_{false}{
}

ContextImpl::~ContextImpl() {
    if (auto_reconnect_)
        unregisterDeviceChangeCallback(this);
}

AngStatus ContextImpl::initialize() {
    ANG_LOGI("ContextImpl::initialize");
    g_hot_plug_dev.clear();
    camera_session_list_.clear();
    std::string _temp = "/dev/bus/usb";
    if (access(_temp.c_str(), R_OK) != 0) {
        chmodPermission();
    }
    initialized_ = true;
    return ANG_STATUS_SUCCESS;
}

AngStatus ContextImpl::shutdown() {
    ANG_LOGI("ContextImpl::shutdown");
    initialized_ = false;
    return ANG_STATUS_SUCCESS;
}

std::shared_ptr<DeviceList> ContextImpl::enumerateDevices(std::map<std::string, unsigned char *>* rawDescriptors) {
    AutoMutex l_(mutex_);
    ANG_LOGI("ContextImpl::enumerateDevices");
    chmodPermission();
    usb_descriptor_ = std::make_shared<AngDescriptor>();
    bool rc = usb_descriptor_->parseDescriptor(rawDescriptors);
    if (!rc) {
        ANG_LOGE("parseDescriptor failed!");
        device_list_ = std::make_shared<DeviceList>(nullptr, rawDescriptors);
    }

    device_list_ = std::make_shared<DeviceList>(usb_descriptor_, rawDescriptors);
    return device_list_;
}

std::shared_ptr<DeviceList> ContextImpl::getDeviceList() const {
    return device_list_;
}

std::shared_ptr<CameraSession> ContextImpl::createCameraSession(std::shared_ptr<Device> device) {
    //删除该USB物理端口旧的session(如果存在的话)
    for (auto it = camera_session_list_.begin(); it != camera_session_list_.end(); ++it) {
        if (device->getDeviceInfo()) {
            if ((*it)->getDevPath() == device->getDeviceInfo()->getDeviceDevPath()) {
                camera_session_list_.erase(it);
                break;
            }
        }
    }
    auto session = std::make_shared<CameraSession>(device);
    camera_session_list_.push_back(session);
    return session;
}

int ContextImpl::registerDeviceChangeCallback(void* ptr, deviceChangedCallback callback) {
    g_device_watcher->registerCallback(ptr, callback);
    if (!g_start_monitor) {
        g_device_watcher->start();
        g_start_monitor = true;
    }
    return ANG_STATUS_SUCCESS;
}

int ContextImpl::unregisterDeviceChangeCallback(void* ptr) {
    g_device_watcher->unregisterCallback(ptr);
    return ANG_STATUS_SUCCESS;
}

void ContextImpl::onDeviceChangedCallback(void* ptr, std::string action, AngDevInfo devInfo) {
    ANG_LOGI("ContextImpl onDeviceChangedCallback action:%s, devInfo:%s", action.c_str(), devInfo.usb.dump().c_str());
    auto context = static_cast<ContextImpl *>(ptr);
    if (!context->auto_reconnect_) {
        ANG_LOGE("onDeviceChangedCallback do nothing, auto_reconnect_ is false");
        return;
    }
    if (action == "remove") {
        g_hot_plug_dev.push_back(devInfo.usb.devpath);
    } else if (action == "add") {
        bool found = false;
        for (auto it = g_hot_plug_dev.begin(); it != g_hot_plug_dev.end(); ++it) {
            if (*it == devInfo.usb.devpath) {
                g_hot_plug_dev.erase(it);
                found = true;
                break;
            }
        }
        if (!found) {
            ANG_LOGI("ignore this add event");
            return;
        }
        //TODO:针对女娲星情况

//        if (g_hot_plug_dev.size() > 0) {
//            ANG_LOGI("onDeviceChangedCallback do nothing, g_hot_plug_dev size:%d", g_hot_plug_dev.size());
//            return;
//        }

        Mutex::Autolock _l(restart_mutex_);
        ANG_LOGI("onDeviceChangedCallback start to do reconnect");
        chmodPermission();
        bool rc = context->usb_descriptor_->parseDescriptor(nullptr);
        if (!rc) {
            ANG_LOGE("onDeviceChangedCallback parseDescriptor failed!");
        }
        auto devices = context->usb_descriptor_->getUsbDeviceDescriptors();
        for (auto &it : *devices) {
            ANG_LOGI("device[%p]:%s", it.get(), it->dump().c_str());
            auto info = it->getAngDevInfo();
            ANG_LOGI("info[%p]:%s", info.get(), info->usb.dump().c_str());
        }
        for (auto session : context->camera_session_list_) {
            if (devInfo.usb.devpath == session->getDevPath()) {
                session->restart(context->usb_descriptor_);
                return;
            }
        }
    }
}

int ContextImpl::enableAutoReconnect(bool enable) {
    ANG_LOGI("ContextImpl enableAutoReconnect:%d", enable);
    g_hot_plug_dev.clear();
    auto_reconnect_ = enable;
    if (enable) {
        registerDeviceChangeCallback(this, onDeviceChangedCallback);
    } else {
        unregisterDeviceChangeCallback(this);
    }
    return ANG_STATUS_SUCCESS;
}