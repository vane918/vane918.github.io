/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "AngSensor.h"
#include "AngSensorImpl.h"
#include "AngLog.hpp"

using namespace ang;

Sensor::Sensor(std::shared_ptr<Driver> driver, std::shared_ptr<AngDescriptor> descriptor,
               std::shared_ptr<AngDevInfo> devInfo) :
        impl_(std::make_unique<SensorImpl>(driver, descriptor, devInfo)) {
}

Sensor::~Sensor() {
}


AngSensorType Sensor::getSensorType() const {
    if (!this) {
        ANG_LOGE("Sensor::getSensorType failed, Sensor already release");
        return ANG_SENSOR_UNKNOWN;
    }
    return impl_->getSensorType();
}

std::vector<ang_stream_config*> Sensor::getStreamConfigList() const {
    if (!this) {
        ANG_LOGE("Sensor::getStreamConfigList failed, Sensor already release");
        return std::vector<ang_stream_config*>();
    }
    return impl_->getStreamConfigList();
}

int Sensor::start(long sensorHandle, ang_stream_config* streamConfig,
                  FrameCallback callback) {
    if (!this) {
        ANG_LOGE("Sensor::start failed, Sensor already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->start(sensorHandle, streamConfig, callback);
}

int Sensor::stop() {
    if (!this) {
        ANG_LOGE("Sensor::stop failed, Sensor already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->stop();
}

int Sensor::switchConfig(ang_stream_config* streamConfig) {
    if (!this) {
        ANG_LOGE("Sensor::switchConfig failed, Sensor already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->switchConfig(streamConfig);
}

SensorImpl::SensorImpl(std::shared_ptr<Driver> driver, std::shared_ptr<AngDescriptor> descriptor,
                       std::shared_ptr<AngDevInfo> devInfo) :
        driver_(driver), usb_descriptor_(descriptor), dev_info_(devInfo) {
    stream_config_list_.clear();
    //TODO：根据描述符信息赋值sensor_type_
    bool _uvc = false;
    sensor_type_ = ANG_SENSOR_COLOR;
    auto devs = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *devs) {
        auto info = dev->getAngDevInfo();
        if (devInfo->type == USB_DEV) {
            _uvc = false;
            if (dev->getAngDevInfo()->usb.uid != devInfo->usb.uid)
                continue;

            auto formats = dev->getConfigurationDescriptor()->getFormatTypeDescriptorList();
            for (auto &format : *formats) {
                _uvc = true;
                auto frames = format->getFrameTypeDescriptorList();
                for (auto &frame : *frames) {
                    StreamConfig* _streamConfig = new StreamConfig();
                    _streamConfig->format_ = format->isMjpeg() ? ANG_FRAME_FORMAT_MJPEG : ANG_FRAME_FORMAT_YUYV;
                    _streamConfig->fps_ = frame->getDefaultFrameInterval();
                    _streamConfig->width_ = frame->getWidth();
                    _streamConfig->height_ = frame->getHeight();
                    //TODO:根据vid和pid决策是否是深度还是RGB
                    _streamConfig->type_ = ANG_STREAM_COLOR;
                    stream_config_list_.emplace_back(reinterpret_cast<ang_stream_config *>(_streamConfig));
                }
            }

            //自定义版本
            if (!_uvc) {
                //织女星
                if (devInfo->usb.pid == SupportedISPPid[2].productID) {
                    StreamConfig* _streamConfig = new StreamConfig();
                    _streamConfig->format_ = ANG_FRAME_FORMAT_MJPEG;
                    _streamConfig->fps_ = 25;
                    _streamConfig->width_ = 640;
                    _streamConfig->height_ = 562;
                    _streamConfig->type_ = ANG_STREAM_COLOR;
                    stream_config_list_.emplace_back(reinterpret_cast<ang_stream_config *>(_streamConfig));
                }
                //CHANG-A
                else if (devInfo->usb.pid == SupportedISPPid[8].productID) {
                    StreamConfig* _streamConfig = new StreamConfig();
                    _streamConfig->format_ = ANG_FRAME_FORMAT_MJPEG;
                    _streamConfig->fps_ = 30;
                    _streamConfig->width_ = 640;
                    _streamConfig->height_ = 400;
                    _streamConfig->type_ = ANG_STREAM_COLOR;
                    stream_config_list_.emplace_back(reinterpret_cast<ang_stream_config *>(_streamConfig));
                }
            }
        }
        else if (devInfo->type == NET_DEV) {
            StreamConfig* _streamConfig = new StreamConfig();
            _streamConfig->format_ = ANG_FRAME_FORMAT_MJPEG;
            _streamConfig->fps_ = 30;
            _streamConfig->width_ = 640;
            _streamConfig->height_ = 642;
            _streamConfig->type_ = ANG_STREAM_COLOR;
            stream_config_list_.emplace_back(reinterpret_cast<ang_stream_config *>(_streamConfig));
        }
    }
}

SensorImpl::~SensorImpl() {
    for (auto config : stream_config_list_) {
        delete reinterpret_cast<StreamConfig *>(config);
    }
}

AngSensorType SensorImpl::getSensorType() const {
    return sensor_type_;
}

std::vector<ang_stream_config*> SensorImpl::getStreamConfigList() const {
    return stream_config_list_;
}

int SensorImpl::start(long sensorHandle, ang_stream_config* streamConfig,
                      FrameCallback callback) {
    ANG_LOGI("SensorImpl start");
    return driver_->startStream(sensorHandle, streamConfig, callback);
}

int SensorImpl::stop() {
    ANG_LOGI("SensorImpl stop");
    return driver_->stopStream();
}

int SensorImpl::switchConfig(ang_stream_config* streamConfig) {
    ANG_LOGI("SensorImpl switchConfig");
    return driver_->switchConfig(streamConfig);
}