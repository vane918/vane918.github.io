/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <memory>

#include "AngDeviceInfoImpl.h"
#include "AngLog.hpp"
#include "AngUtil.h"

using namespace ang;

DeviceInfo::DeviceInfo(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo) : impl_(
        std::make_unique<DeviceInfoImpl>(descriptor, devInfo)) {
}

DeviceInfo::~DeviceInfo() {
}

std::string DeviceInfo::getDeviceName() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceName failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceName();
}

std::string DeviceInfo::getDeviceBus() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceBus failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceBus();
}

std::string DeviceInfo::getDeviceDevId() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceDevId failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceDevId();
}

std::string DeviceInfo::getDevicePid() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDevicePid failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDevicePid();
}

std::string DeviceInfo::getDeviceVid() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceVid failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceVid();
}

std::string DeviceInfo::getDeviceUid() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceUid failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceUid();
}

std::string DeviceInfo::getDeviceDevPath() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceUid failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceDevPath();
}

std::string DeviceInfo::getDeviceMcuUid() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceMcuUid failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceMcuUid();
}

std::string DeviceInfo::getDeviceSerialNumber() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceSerialNumber failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceSerialNumber();
}

std::string DeviceInfo::getDeviceFirmwareVersion() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceFirmwareVersion failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceFirmwareVersion();
}

std::string DeviceInfo::getDeviceHardwareVersion() const {
    if (!this) {
        ANG_LOGE("DeviceInfo::getDeviceHardwareVersion failed, DeviceInfo already release");
        return "";
    }
    return impl_->getDeviceHardwareVersion();
}


DeviceInfoImpl::DeviceInfoImpl(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo) :
        usb_descriptor_(descriptor), dev_info_(devInfo) {
}

std::string DeviceInfoImpl::getDeviceName() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        auto info = dev->getAngDevInfo();
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.product;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceBus() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.bus;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceDevId() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.dev;
    }
    return "";
}

std::string DeviceInfoImpl::getDevicePid() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.pid;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceVid() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.vid;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceUid() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.uid;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceDevPath() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.devpath;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceMcuUid() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    std::string uvc_devpath = "";
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid) {
            uvc_devpath = dev->getAngDevInfo()->usb.devpath;
            break;
        }
    }

    auto pos = uvc_devpath.find_last_of(".");
    std::string uvc_devpath_split = uvc_devpath.substr(0, pos);

    std::string mcu_devpath = "";
    std::string mcu_devpath_split = "";
    for (auto &dev : *deviceDescriptors) {
        if (!checkAngMcuDev(dev->getAngDevInfo()->usb.uid))
            continue;

        mcu_devpath = dev->getAngDevInfo()->usb.devpath;
        auto pos_ = mcu_devpath.find_last_of(".");
        if (pos_ == std::string::npos) {
            ANG_LOGE("mcu_devpath is wrong");
        }
        mcu_devpath_split = mcu_devpath.substr(0, pos_);

        if (mcu_devpath_split.find(uvc_devpath_split) != std::string::npos) {
            return dev->getAngDevInfo()->usb.uid;
        }

    }

    return "";
}

std::string DeviceInfoImpl::getDeviceSerialNumber() const {
    auto deviceDescriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == dev_info_->usb.uid)
            return dev->getAngDevInfo()->usb.serialNumber;
    }
    return "";
}

std::string DeviceInfoImpl::getDeviceFirmwareVersion() const {

    return "";
}

std::string DeviceInfoImpl::getDeviceHardwareVersion() const {
    return "";
}