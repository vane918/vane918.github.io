/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <memory>

#include "AngDeviceImpl.h"
#include "AngDriver.h"
#include "AngUvcDriver.h"
#include "AngVendorDriver.h"
#include "AngV4l2Driver.h"
#include "AngNetDriver.h"
#include "AngLog.hpp"

#include "AngFrame.h"

using namespace ang;

Device::Device(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo) : impl_(
        std::make_unique<DeviceImpl>(descriptor, devInfo)) {
    ANG_LOGI("Device:%p", this);
}

Device::~Device() {
    ANG_LOGI("~Device:%p", this);
}

int Device::angOpen(int fd) {
    ANG_LOGI("Device angOpen:%p", this);
    if (!this) {
        ANG_LOGE("Device::open failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->angOpen(fd);
}

int Device::angOpenMcu(int fd) {
    if (!this) {
        ANG_LOGE("Device::open mcu failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->angOpenMcu(fd);
}

int Device::angClose() {
    if (!this) {
        ANG_LOGE("Device::close failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->angClose();
}

std::shared_ptr<DeviceInfo> Device::getDeviceInfo() const {
    if (!this) {
        ANG_LOGE("Device::getDeviceInfo failed, Device already release");
        return nullptr;
    }
    return impl_->getDeviceInfo();
}

int Device::updateDeviceInfo(std::shared_ptr<AngDevInfo> devInfo) {
    if (!this) {
        ANG_LOGE("Device::getDeviceInfo failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->updateDeviceInfo(devInfo);
}

std::shared_ptr<SensorList> Device::getSensorList() const {
    if (!this) {
        ANG_LOGE("Device::getSensorList failed, Device already release");
        return nullptr;
    }
    return impl_->getSensorList();
}

int Device::getFirmwareInfo(AngPropertyID propertyId, char **info) const {
    if (!this) {
        ANG_LOGE("Device::getFirmwareInfo failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->getFirmwareInfo(propertyId, info);
}

int Device::communicateWithMcu(char** value, int& len) {
    if (!this) {
        ANG_LOGE("Device::communicateWithMcu failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->communicateWithMcu(value, len);
}

int Device::setFirmwareInfo(AngPropertyID propertyId, const char *value, int len) const {
    if (!this) {
        ANG_LOGE("Device::setFirmwareInfo failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->setFirmwareInfo(propertyId, value, len);
}

int Device::getChipSeInfo(AngPropertyID propertyId, char **info) const {
    if (!this) {
        ANG_LOGE("Device::getChipSeInfo failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->getChipSeInfo(propertyId, info);
}

int Device::setChipSeInfo(AngPropertyID propertyId, const char *value, int len) const {
    if (!this) {
        ANG_LOGE("Device::setChipSeInfo failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->setChipSeInfo(propertyId, value, len);
}

int Device::upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) {
    if (!this) {
        ANG_LOGE("Device::upgradeCamera failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->upgradeCamera(cmd, upgradeFile, callback);
}

int Device::cancelUpgradeCamera() {
    if (!this) {
        ANG_LOGE("Device::cancelUpgradeCamera failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->cancelUpgradeCamera();
}

int Device::angReboot() {
    if (!this) {
        ANG_LOGE("Device::angReboot failed, Device already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->angReboot();
}

std::shared_ptr<CameraParamList> Device::getCalibrationCameraParamList() const {
    if (!this) {
        ANG_LOGE("Device::getCalibrationCameraParamList failed, Device already release");
        return nullptr;
    }
    return impl_->getCalibrationCameraParamList();
}


DeviceImpl::DeviceImpl(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo) :
        usb_descriptor_(descriptor), devInfo_(devInfo) {
    auto device_descriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *device_descriptors) {
        auto info = dev->getAngDevInfo();
        if (devInfo->type == UNKNOWN_DEV) {
            ANG_LOGE("device:%s is unknown type device", dev->dump().c_str());
            continue;
        }
        if (devInfo->type == USB_DEV) {
            if (info->usb.uid == devInfo->usb.uid) {
                auto config = dev->getConfigurationDescriptor();
                auto interfaces = config->getInterfaceDescriptorList();
                for (auto &interface : *interfaces) {
                    //UVC协议
                    if (interface->getInterfaceClass() == 0x0E &&
                        interface->getInterfaceSubClass() == 0x02) {
#ifdef _USE_V4L2_DRIVER
                        auto driver = std::make_shared<V4l2Driver>(descriptor, devInfo, ANG_DRIVER_V4L2);
#else
                        auto driver = std::make_shared<UvcDriver>(descriptor, devInfo, ANG_DRIVER_UVC);
#endif
                        driver_type_ = driver->getDriverType();
                        driver->init(interface->getInterfaceNumber());
                        driver_map_.insert(std::make_pair(interface->getInterfaceNumber(), driver));
                        ANG_LOGI("driver_map_ insert uvc interface:%d", interface->getInterfaceNumber());
                        //自定义协议
                    } else if (interface->getInterfaceClass() == 0xFF &&
                               interface->getInterfaceSubClass() == 0x0) {
                        auto driver = std::make_shared<VendorDriver>(descriptor, devInfo, ANG_DRIVER_VENDOR);
                        driver_type_ = driver->getDriverType();
                        driver->init(interface->getInterfaceNumber());
                        driver_map_.insert(std::make_pair(interface->getInterfaceNumber(), driver));
                        ANG_LOGI("driver_map_ insert vendor interface:%d", interface->getInterfaceNumber());
                    }
                }
                sensor_list_ = std::make_shared<SensorList>(driver_map_, descriptor, devInfo);
            }
        } else {
            if (info->net.ip == devInfo->net.ip) {
                auto driver = std::make_shared<NetDriver>(descriptor, devInfo, ANG_DRIVER_NET);
                driver_type_ = driver->getDriverType();
                driver->init(0);
                driver_map_.insert(std::make_pair(0, driver));
                sensor_list_ = std::make_shared<SensorList>(driver_map_, descriptor, devInfo);
                ANG_LOGI("driver_map_ insert net interface:%d", 0);
            }
        }
    }
}

DeviceImpl::~DeviceImpl() {
    for (auto &it : driver_map_) {
        it.second->shutdown();
    }
}

int DeviceImpl::angOpen(int fd) {
    ANG_LOGI("DeviceImpl open fd:%d, driver_map_ size:%lu", fd, driver_map_.size());
    if (opened_) {
        ANG_LOGI("DeviceImpl is already open!");
        return ANG_STATUS_SUCCESS;
    }

    int rc = ANG_STATUS_FAILED;
    long usb_handle = 0L;
    for (auto &it : driver_map_) {
        rc = it.second->open(fd);
        usb_handle = it.second->getUsbHandle();
    }
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("DeviceImpl[%s] open failed, rc:%d", devInfo_->usb.uid.c_str(), rc);
        return rc;
    }
    ANG_LOGI("DeviceImpl open, uid_:%s", devInfo_->usb.uid.c_str());
    auto driver = driver_map_.begin()->second;
    if (checkVegaDev(devInfo_->usb.uid) || checkHP60CDev(devInfo_->usb.uid) || devInfo_->type == NET_DEV)
        usb_messenger_ = std::make_unique<VegaMessenger>(usb_descriptor_, devInfo_, usb_handle, driver);

    opened_ = true;
    return ANG_STATUS_SUCCESS;
}

int DeviceImpl::angOpenMcu(int fd) {
    ANG_LOGI("DeviceImpl open mcu fd:%d", fd);
    if (!checkNuwaDev(devInfo_->usb.uid) && !checkAngMcuDev(devInfo_->usb.uid)) {
        ANG_LOGI("[%s]dev is not a mcu device!!!", devInfo_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
#ifdef _USE_MCU_DEV
    auto driver = driver_map_.begin()->second;
    usb_messenger_ = std::make_unique<NuwaMessenger>(usb_descriptor_, devInfo_, fd, driver);
#endif
    return ANG_STATUS_SUCCESS;
}

int DeviceImpl::angClose() {
    ANG_LOGI("DeviceImpl close");
    int rc = ANG_STATUS_FAILED;
    for (auto &it : driver_map_) {
        rc = it.second->close();
    }
    usb_messenger_.reset();
    usb_messenger_ = nullptr;
    opened_ = false;
    return rc;
}

std::shared_ptr<DeviceInfo> DeviceImpl::getDeviceInfo() const {
    return std::make_shared<DeviceInfo>(usb_descriptor_, devInfo_);
}

int DeviceImpl::updateDeviceInfo(std::shared_ptr<AngDevInfo> devInfo) {
    devInfo_.reset();
    devInfo_ = devInfo;
    for (auto &it : driver_map_) {
        it.second->updateDevInfo(devInfo);
    }
    return ANG_STATUS_SUCCESS;
}

std::shared_ptr<SensorList> DeviceImpl::getSensorList() const {
    return sensor_list_;
}

int DeviceImpl::getFirmwareInfo(AngPropertyID propertyId, char **info) const {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }

    return usb_messenger_->getFirmwareInfo(propertyId, info);
}

int DeviceImpl::communicateWithMcu(char** value, int& len) {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }


    return usb_messenger_->communicateWithDevice(value, len);
}

int DeviceImpl::setFirmwareInfo(AngPropertyID propertyId, const char *value, int len) const {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }

    return usb_messenger_->setFirmwareInfo(propertyId, value, len);
}

int DeviceImpl::getChipSeInfo(AngPropertyID propertyId, char **info) const {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }

    return usb_messenger_->getChipSeInfo(propertyId, info);
}

int DeviceImpl::setChipSeInfo(AngPropertyID propertyId, const char *value, int len) const {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }

    return usb_messenger_->setChipSeInfo(propertyId, value, len);
}

int DeviceImpl::upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }
    return usb_messenger_->upgradeCamera(cmd, upgradeFile, callback);
}

int DeviceImpl::cancelUpgradeCamera() {
    if (!usb_messenger_) {
        ANG_LOGE("usb_messenger_ is null");
        return ANG_STATUS_FAILED;
    }
    return usb_messenger_->cancelUpgradeCamera();
}

int DeviceImpl::angReboot() {
    return ANG_STATUS_NOT_SUPPORT;
}

std::shared_ptr<CameraParamList> DeviceImpl::getCalibrationCameraParamList() const {
    return nullptr;
}