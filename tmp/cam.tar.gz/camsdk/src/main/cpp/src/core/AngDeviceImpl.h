/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_DEVICEIMPL_H_
#define _ANG_DEVICEIMPL_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>
#include <map>

#include "AngDefines.h"
#include "AngDevice.h"
#include "AngSensorImpl.h"
#include "AngDescriptors.h"
#include "VegaMessenger.h"
#ifdef _USE_MCU_DEV
#include "NuwaMessenger.h"
#endif

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class DeviceImpl {

    public:
        explicit DeviceImpl(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo);

        ~DeviceImpl();

        DeviceImpl &operator=(const DeviceImpl &rhs) = delete;

        DeviceImpl(const DeviceImpl &context) = delete;

        int angOpen(int fd);

        int angOpenMcu(int fd);

        int angClose();

        /**
         * @brief 获取设备信息
         *
         * @return std::shared_ptr<DeviceInfo> 返回设备的信息
         */
        std::shared_ptr<DeviceInfo> getDeviceInfo() const;

        /**
         * @brief 热插拔后更新设备信息，该API仅供内部使用
         * @param: devInfo:需要更新的设备信息
         *
         * @return 0：成功；其他值：失败
         */
        int updateDeviceInfo(std::shared_ptr<AngDevInfo> devInfo);

        /**
         * @brief 获取设备传感器列表
         *
         * @return std::shared_ptr<SensorList> 返回传感器列表
         */
        std::shared_ptr<SensorList> getSensorList() const;

        /**
         * @brief 发送自定义MCU命令
         *
         * @param: sn:enumerateDevices()函数返回的uvc设备的sn；
         * @param: value：发送自定义命令的buff，也是接收返回结果的buff，如获取SN的命令：下发"ARG READ:SN="，
         * 然后根据len长度来取value的值，value开辟空间建议设为传输的最大值：64 bytes
         * @param: len：value的长度
         * @return: 0: 成功; 其他: 失败
         **/
        int communicateWithMcu(char** value, int& len);

        /**
         * @brief 获取设备属性
         *
         * @param propertyId 属性id
         * @param info 填充获取设备属性的buffer
         * @return int 是否成功获取的属性数据, 0：成功，其他值：失败
         */
        int getFirmwareInfo(AngPropertyID propertyId, char **info) const;

        /**
        * @brief 设置设备属性
        *
        * @param propertyId 属性id
        * @param value 需要设置设备属性的信息
        * @param len  需要设置设备属性的信息长度
        * @return int 设置属性是否成功，0：成功，其他值：失败
        */
        int setFirmwareInfo(AngPropertyID propertyId, const char* value, int len) const;

        /**
         * @brief 获取SE芯片信息
         *
         * @param propertyId 需要获取SE芯片的指令
         * @param info 填充获取SE芯片的buffer
         * @return 是否成功获取SE芯片信息，0：成功，其他值：失败
         */
        int getChipSeInfo(AngPropertyID propertyId, char **info) const;

        /**
        * @brief 设置SE芯片信息
        *
        * @param propertyId 需要获取SE芯片的指令
        * @param value 需要设置SE芯片的信息
        * @param len 需要设置SE芯片的信息长度
        * @return 是否成功设置SE芯片信息，0：成功，其他值：失败
        */
        int setChipSeInfo(AngPropertyID propertyId, const char* value, int len) const;

        int upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback);

        int cancelUpgradeCamera();

        int angReboot();

        /**
         * @brief 获取设备内保存的相机标定的原始参数列表，列表内参数不与当前开流配置相对应，
         * 需要自行根据实际情况选用参数并可能需要做缩放、镜像等处理。非专业用户建议使用Pipeline::getCameraParam()接口。
         *
         * @return std::shared_ptr<CameraParamList> 相机参数列表
         */
        std::shared_ptr<CameraParamList> getCalibrationCameraParamList() const;

    private:
        std::shared_ptr<AngDescriptor> usb_descriptor_{nullptr};
        std::shared_ptr<SensorList> sensor_list_{nullptr};
        std::map<int, std::shared_ptr<Driver>> driver_map_;//interface:driver

        std::shared_ptr<AngDevInfo> devInfo_{nullptr};

        std::unique_ptr<Messenger> usb_messenger_{nullptr};

        AngDriverType driver_type_;

        std::atomic<bool> opened_{false};
    };

ANG_NAMESPACE_IMPLEMENTATION_END


#endif //_ANG_DEVICEIMPL_H_
