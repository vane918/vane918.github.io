/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <vector>
#include "AngCameraSession.h"
#include "AngCameraSessionImpl.h"
#include "AngStreamConfig.h"
#include "AngLog.hpp"
#include "AngUtil.h"

using namespace ang;

CameraSession::CameraSession(std::shared_ptr<Device> device) :
        impl_(std::make_unique<CameraSessionImpl>(device)) {
}

CameraSession::~CameraSession() {
}

AngStatus CameraSession::start(int uvcFd, int mcuFd, int width, int height, AngFormat format, long clientHandle, FrameCallback callback) {
    if (!this) {
        ANG_LOGE("CameraSession::start failed, CameraSession already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->start(uvcFd, mcuFd, width, height, format, clientHandle, callback);
}

AngStatus CameraSession::stop() {
    if (!this) {
        ANG_LOGE("CameraSession::stop failed, CameraSession already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->stop();
}

AngStatus CameraSession::restart(std::shared_ptr<AngDescriptor> usb_descriptor) {
    if (!this) {
        ANG_LOGE("CameraSession::restart failed, CameraSession already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->restart(usb_descriptor);
}

std::string CameraSession::getDevPath() {
    if (!this) {
        ANG_LOGE("CameraSession::getDevPath failed, CameraSession already release");
        return "";
    }
    return impl_->getDevPath();
}

CameraSessionImpl::CameraSessionImpl(std::shared_ptr<Device> device) :
    device_(device),
    sensor_(nullptr),
    session_info_(nullptr),
    running_(false),
    dev_path_(device->getDeviceInfo()->getDeviceDevPath()){
}

AngStatus
CameraSessionImpl::start(int uvcFd, int mcuFd, int width, int height, AngFormat format, long clientHandle, FrameCallback callback) {
    int rc = ANG_STATUS_FAILED;
    rc = device_->angOpen(uvcFd);
    if (rc) {
        ANG_LOGE("CameraSessionImpl start failed!, device open failed");
        return ANG_STATUS_FAILED;
    }
    if (checkNuwaDev(device_->getDeviceInfo()->getDeviceUid())) {
        device_->angOpenMcu(mcuFd);
        char* value = static_cast<char *>(malloc(60));
        memset(value, 0, 60);
        memcpy(value, "ARG WRITE:S=3", 60);
        int len = 60;
        int rc = device_->communicateWithMcu(&value, len);
        free(value);
    }
    auto sensorLists = device_->getSensorList();
    auto sensor = sensorLists->getSensor(0);
    auto streamConfigs = sensor->getStreamConfigList();
    bool found = false;
    for (int i = 0; i < streamConfigs.size(); ++i) {
        auto stream_config = reinterpret_cast<StreamConfig *>(streamConfigs[i]);
        if (stream_config->getWidth() == width && stream_config->getHeight() == height &&
            stream_config->getStreamFormat() == format) {
            sensor_ = sensor;
            found = true;
            rc = sensor_->start(clientHandle, streamConfigs[i], callback);
            break;
        }
    }

    if (!found) {
        ANG_LOGE("CameraSessionImpl start failed!, not found streamConfig[width:%d,height:%d,format:%d]",
                 width, height, format);
        return ANG_STATUS_FAILED;
    }

    if (!session_info_)
        session_info_ = std::make_shared<AngSessionInfo>();

    session_info_->fd = uvcFd;
    session_info_->width = width;
    session_info_->height = height;
    session_info_->format = format;
    session_info_->clientHandle = clientHandle;
    session_info_->callback = callback;
    running_ = true;
    return static_cast<AngStatus>(rc);
}

AngStatus CameraSessionImpl::stop() {

    if (!sensor_) {
        ANG_LOGE("CameraSessionImpl stop failed, sensor_ is null");
        return ANG_STATUS_FAILED;
    }
    int rc = ANG_STATUS_FAILED;
    rc = sensor_->stop();
    sensor_.reset();
    sensor_ = nullptr;
    if (checkNuwaDev(device_->getDeviceInfo()->getDeviceUid())) {
        char* value = static_cast<char *>(malloc(60));
        memset(value, 0, 60);
        memcpy(value, "ARG WRITE:S=0", 60);
        int len = 60;
        int rc = device_->communicateWithMcu(&value, len);
        free(value);
    }
    rc = device_->angClose();
    running_ = false;
    return static_cast<AngStatus>(rc);
}

AngStatus CameraSessionImpl::restart(std::shared_ptr<AngDescriptor> usb_descriptor) {
    ANG_LOGI("CameraSessionImpl restart");
    if (!running_) {
        ANG_LOGE("CameraSessionImpl restart failed, running_ is false");
        return ANG_STATUS_FAILED;
    }
    if (!sensor_) {
        ANG_LOGE("CameraSessionImpl restart failed, sensor_ is null");
        return ANG_STATUS_FAILED;
    }
    int rc = ANG_STATUS_FAILED;
    rc = sensor_->stop();
    rc = device_->angClose();
    usleep(10 * 1000);

    //更新设备信息
    auto devices = usb_descriptor->getUsbDeviceDescriptors();
    for (auto &it : *devices) {
        auto info = it->getAngDevInfo();
        if (info->usb.devpath == dev_path_) {
            device_->updateDeviceInfo(info);
        }
    }

    rc = device_->angOpen(0);
    if (checkNuwaDev(device_->getDeviceInfo()->getDeviceUid())) {
        device_->angOpenMcu(0);
        char* value = static_cast<char *>(malloc(60));
        memset(value, 0, 60);
        memcpy(value, "ARG WRITE:S=3", 60);
        int len = 60;
        int rc = device_->communicateWithMcu(&value, len);
        free(value);
    }

    auto streamConfigs = sensor_->getStreamConfigList();
    for (int i = 0; i < streamConfigs.size(); ++i) {
        auto stream_config = reinterpret_cast<StreamConfig *>(streamConfigs[i]);
        if (stream_config->getWidth() == session_info_->width && stream_config->getHeight() == session_info_->height &&
            stream_config->getStreamFormat() == session_info_->format) {
            rc = sensor_->start(session_info_->clientHandle, streamConfigs[i], session_info_->callback);
            break;
        }
    }
    return static_cast<AngStatus>(rc);
}
std::string CameraSessionImpl::getDevPath() {
    return dev_path_;
}