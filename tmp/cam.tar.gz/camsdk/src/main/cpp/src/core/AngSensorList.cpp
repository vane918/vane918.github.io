/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/
#include <memory>

#include "AngSensorListImpl.h"
#include "AngDescriptors.h"
#include "AngLog.hpp"

using namespace ang;

SensorList::SensorList(std::map<int, std::shared_ptr<Driver>> &driver_map,
                       std::shared_ptr<AngDescriptor> descriptor,
                       std::shared_ptr<AngDevInfo> devInfo) :
        impl_(std::make_unique<SensorListImpl>(driver_map, descriptor, devInfo)) {
}

SensorList::~SensorList() {
}

uint8_t SensorList::getSensorCount() const {
    if (!this) {
        ANG_LOGE("SensorList::getSensorCount failed, SensorList already release");
        return 0;
    }
    return impl_->getSensorCount();
}

AngSensorType SensorList::getSensorType(uint8_t index) const {
    if (!this) {
        ANG_LOGE("SensorList::getSensorType failed, SensorList already release");
        return ANG_SENSOR_UNKNOWN;
    }
    return impl_->getSensorType(index);
}

std::shared_ptr<Sensor> SensorList::getSensor(uint8_t index) const {
    if (!this) {
        ANG_LOGE("SensorList::getSensor failed, SensorList already release");
        return nullptr;
    }
    return impl_->getSensor(index);
}

std::shared_ptr<Sensor> SensorList::getSensor(AngSensorType sensorType) const {
    if (!this) {
        ANG_LOGE("SensorList::getSensor failed, SensorList already release");
        return nullptr;
    }
    return impl_->getSensor(sensorType);
}

SensorListImpl::SensorListImpl(std::map<int, std::shared_ptr<Driver>> &driver_map,
                               std::shared_ptr<AngDescriptor> descriptor,
                               std::shared_ptr<AngDevInfo> devInfo) :
        usb_descriptor_(descriptor), dev_info_(devInfo),
        sensor_list_(std::make_shared<AngSensorList>()) {
    auto device_descriptors = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *device_descriptors) {
        auto info = dev->getAngDevInfo();
        if (devInfo->type == USB_DEV) {
            if (info->usb.uid == devInfo->usb.uid) {
                auto config = dev->getConfigurationDescriptor();
                auto interfaces = config->getInterfaceDescriptorList();
                for (auto &interface : *interfaces) {
                    if ((interface->getInterfaceClass() == 0x0E &&
                         interface->getInterfaceSubClass() == 0x02)//UVC
                        || interface->getInterfaceClass() == 0xFF) {
                        for (auto &it : driver_map) {
                            if (it.first == interface->getInterfaceNumber()) {
                                auto sensor = std::make_shared<Sensor>(it.second, descriptor,
                                                                       devInfo);
                                sensor_list_->emplace_back(sensor);
                            }
                        }
                    }
                }
            }
        } else if (devInfo->type == NET_DEV) {
            if (info->net.ip == devInfo->net.ip) {
                for (auto &it : driver_map) {
                    auto sensor = std::make_shared<Sensor>(it.second, descriptor, devInfo);
                    sensor_list_->emplace_back(sensor);
                }
            }
        }
    }
}

uint8_t SensorListImpl::getSensorCount() const {
    auto device_descriptors = usb_descriptor_->getUsbDeviceDescriptors();
    if (device_descriptors->size() == 0)
        return 0;

    return sensor_list_->size();
}

AngSensorType SensorListImpl::getSensorType(uint8_t index) const {
    if (sensor_list_->size() <= index) {
        return ANG_SENSOR_UNKNOWN;
    }
    return (*sensor_list_)[index]->getSensorType();
}

std::shared_ptr<Sensor> SensorListImpl::getSensor(uint8_t index) const {
    if (sensor_list_->size() <= index) {
        return nullptr;
    }
    return sensor_list_->at(index);
}

std::shared_ptr<Sensor> SensorListImpl::getSensor(AngSensorType sensorType) const {
    for (auto &sensor : *sensor_list_) {
        if (sensor->getSensorType() == sensorType) {
            return sensor;
        }
    }
    return nullptr;
}