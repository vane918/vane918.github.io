/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_STREAMCONFIG_H_
#define _ANG_STREAMCONFIG_H_

#include <stdint.h>
#include <string>
#include <memory>

#include "AngDefines.h"
#include "AngTypes.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class StreamConfig {

    public:

        /**
         * @brief 获取流的格式
         *
         * @return AngFormat 返回流的格式
         */
        AngFormat getStreamFormat() const;

        /**
         * @brief 获取流的类型
         *
         * @return AngStreamType 返回流的类型
         */
        AngStreamType getStreamType() const;

        /**
         * @brief 获取流的帧率
         *
         * @return uint8_t 返回流的帧率
         */
        uint8_t getFps() const;

        /**
         * @brief 获取流的宽
         *
         * @return uint16_t 返回流的宽
         */
        uint16_t getWidth() const;

        /**
         * @brief 获取流的高
         *
         * @return uint16_t 返回流的高
         */
        uint16_t getHeight() const;

        AngFormat format_;
        AngStreamType type_;
        uint8_t fps_;
        uint16_t width_;
        uint16_t height_;
    };


ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_STREAMCONFIG_H_
