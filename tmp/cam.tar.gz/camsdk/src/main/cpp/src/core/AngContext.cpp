/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "AngContext.h"
#include "AngContextImpl.h"
#include "AngLog.hpp"

using namespace ang;

constexpr static const char* SDK_VERSION = "v1.1.3";

Context::Context() : impl_(std::make_unique<ContextImpl>()) {
}

Context::~Context() {
}

std::string Context::getSDKVersion() {
    return SDK_VERSION;
}

AngStatus Context::initialize() {
//    Log::GetInstance().EnableLogToFile(true);
    ANG_LOGI("Context::initialize, current sdk version: %s", SDK_VERSION);
    //获取 android SDK版本,如：27
#ifdef __ANDROID__
    char sdk[16];
    __system_property_get("ro.build.version.sdk", sdk);
    //获取开发板型号，如：Firefly-RK3399
    char model[64] = "0";
    __system_property_get("ro.product.model", model);
    //获取开发板主板，如：rk3399
    char board[64] = "0";
    __system_property_get("ro.board.platform", board);
    //获取产品型号，如：rk3399_firefly_mid
    char product[64] = "0";
    __system_property_get("ro.product.device", product);
    ANG_LOGI("sdk:%s, model:%s, board:%s, product:%s", sdk, model, board, product);
#endif
    if (!this) {
        ANG_LOGE("Context::initialize failed, Context already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->initialize();
}

AngStatus Context::shutdown() {
    if (!this) {
        ANG_LOGE("Context::shutdown failed, Context already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->shutdown();
}

std::shared_ptr<DeviceList> Context::enumerateDevices() const {
    if (!this) {
        ANG_LOGE("Context::enumerateDevices failed, Context already release");
        return nullptr;
    }
    return enumerateDevices(nullptr);
}

std::shared_ptr<DeviceList> Context::enumerateDevices(std::map<std::string, unsigned char *>* rawDescriptors) const {
    if (!this) {
        ANG_LOGE("Context::enumerateDevices failed, Context already release");
        return nullptr;
    }
    return impl_->enumerateDevices(rawDescriptors);
}

std::shared_ptr<DeviceList> Context::getDeviceList() const{
    if (!this) {
        ANG_LOGE("Context::getDeviceList failed, Context already release");
        return nullptr;
    }
    return impl_->getDeviceList();
}

std::shared_ptr<CameraSession> Context::createCameraSession(std::shared_ptr<Device> device) {
    if (!this) {
        ANG_LOGE("Context::createCameraSession failed, Context already release");
        return nullptr;
    }
    return impl_->createCameraSession(device);
}

int Context::registerDeviceChangeCallback(void* ptr, deviceChangedCallback callback) {
    if (!this) {
        ANG_LOGE("Context::registerDeviceChangeCallback failed, Context already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->registerDeviceChangeCallback(ptr, callback);
}

int Context::unregisterDeviceChangeCallback(void* ptr) {
    if (!this) {
        ANG_LOGE("Context::unregisterDeviceChangeCallback failed, Context already release");
        return ANG_STATUS_FAILED;
    }
    return impl_->unregisterDeviceChangeCallback(ptr);
}

int Context::enableLogToFile(bool enable) {
    ang::Log::GetInstance().EnableLogToFile(enable);
    return ANG_STATUS_SUCCESS;
}

int Context::enableAutoReconnect(bool enable) {
    return impl_->enableAutoReconnect(enable);
}