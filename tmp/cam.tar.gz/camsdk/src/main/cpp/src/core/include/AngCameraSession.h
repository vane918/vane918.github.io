/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_CAMERA_SESSION_H_
#define _ANG_CAMERA_SESSION_H_

#include <memory>
#include "AngTypes.h"
#include "AngDefines.h"
#include "AngDevice.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class CameraSessionImpl;

    /**
     * @brief 表示Camera会话，调用start接口可以快速开启camera流，调用stop可以快速停止camera流
     * 调用CameraSession函数不需要调用Device的angOpen和angClose函数
     */
    class CameraSession {

    public:
        explicit CameraSession(std::shared_ptr<Device> device);

        ~CameraSession();

        CameraSession &operator=(const CameraSession &rhs) = delete;

        CameraSession(const CameraSession &context) = delete;

        /**
         * 快速开启camera流，屏蔽底层Device和Sensor细节
         * 不需要操作Device类和Sensor类
         *
         * @param uvcFd: camera设备的句柄，如果是Java层的UsbManager打开设备，则传递fd，如果是由底层SDK打开设备，
         * @param mcuFd: camera设备MCU的句柄，如果是Java层的UsbManager打开设备，则传递fd，如果是由底层SDK打开设备，
         * 则fd设置为0，只要女娲星模组才有
         * @param width: 需要获取帧的宽
         * @param height: 需要获取帧的高
         * @param format: 需要获取帧的格式，ANG_FRAME_FORMAT_YUYV 或 ANG_FRAME_FORMAT_MJPEG
         * @param clientHandle: 调用者的句柄
         * @param callback: camera流的回调函数，流从该函数返回给调用者
         * @return 0：成功，其他值：失败
         */
        AngStatus start(int uvcFd, int mcuFd, int width, int height, AngFormat format, long clientHandle, FrameCallback callback);

        /**
         * 快速关闭camera流，屏蔽底层Device和Sensor细节
         * 不需要操作Device类和Sensor类
         *
         * @param
         * @return 0：成功，其他值：失败
         */
        AngStatus stop();

        /**
         * 重新启动camera，该接口是内部使用，调用者可忽略
         *
         * @param
         * @return 0：成功，其他值：失败
         */
        AngStatus restart(std::shared_ptr<AngDescriptor> usb_descriptor);

        /**
         * 获取camera所在的USB物理端口，该接口是内部使用，调用者可忽略
         *
         * @param
         * @return string：camera所在的USB物理端口
         */
        std::string getDevPath();

    private:
        std::unique_ptr<CameraSessionImpl> impl_{nullptr};
    };

ANG_NAMESPACE_IMPLEMENTATION_END
#endif //_ANG_CAMERA_SESSION_H_
