/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_FRAMEPOOL_H_
#define _ANG_FRAMEPOOL_H_

#include "vector"
#include "AngTypes.h"
#include "AngDefines.h"
#include "AngFrame.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class AngFramePool {
    private:
        int head_, tail_;                             // 头尾指针
        std::vector<std::shared_ptr<Frame>> buffers_; // 缓冲池
        int total_, length_;                          // 缓冲区总个数和以使用个数
        int frame_size_;

    public:
        explicit AngFramePool(int bufferSize);         // 构造函数 count:缓冲区个数  bufferSize:缓冲区大小

        std::shared_ptr<Frame> get_frame_buffer();    // 获取一个缓冲区

        std::shared_ptr<Frame> pop_frame_buffer();    // 取得头缓冲区并弹出

        bool empty() const;                           // 缓冲池是否为空

        bool full() const;                            // 缓冲池是否已满

        int getFrameSize() const;

        ~AngFramePool();
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_FRAMEPOOL_H_
