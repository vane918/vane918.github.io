/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_SENSORLISTIMPL_H_
#define _ANG_SENSORLISTIMPL_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>

#include "AngDefines.h"
#include "AngSensor.h"
#include "AngDescriptors.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    using AngSensorList = std::vector<std::shared_ptr<Sensor>>;

    class SensorListImpl {

    public:
        explicit SensorListImpl(std::map<int, std::shared_ptr<Driver>> &driver_map,
                       std::shared_ptr<AngDescriptor> descriptor,
                       std::shared_ptr<AngDevInfo> devInfo);

        SensorListImpl &operator=(const SensorListImpl &rhs) = delete;

        SensorListImpl(const SensorListImpl &context) = delete;

        /**
         * @brief 获取Sensor数量
         *
         * @return uint8_t 返回Sensor的数量
         */
        uint8_t getSensorCount() const;

        /**
         * @brief 获取指定Sensor的类型
         *
         * @param index Sensor索引
         * @return AngSensorType 返回Sensor类型
         */
        AngSensorType getSensorType(uint8_t index) const;

        /**
         * @brief 通过索引号获取Sensor
         *
         * @param index 要创建设备的索，范围 [0, count-1]，如果index超出范围将抛异常
         * @return std::shared_ptr<Sensor> 返回Sensor对象
         */
        std::shared_ptr<Sensor> getSensor(uint8_t index) const;

        /**
         * @brief 通过Sensor类型获取Sensor
         *
         * @param sensorType 要获取的Sensor类型
         * @return std::shared_ptr<Sensor> 返回Sensor对象，如果指定类型Sensor不存在，将返回空
         */
        std::shared_ptr<Sensor> getSensor(AngSensorType sensorType) const;

    private:
        std::shared_ptr<AngSensorList> sensor_list_{nullptr};
        std::shared_ptr<AngDescriptor> usb_descriptor_{nullptr};
        std::shared_ptr<AngDevInfo> dev_info_{nullptr};
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_SENSORLISTIMPL_H_
