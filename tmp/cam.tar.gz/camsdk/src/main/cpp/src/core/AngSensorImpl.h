/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef ANGCAMSDK_ANGSENSORIMPL_H
#define ANGCAMSDK_ANGSENSORIMPL_H

#include "AngDefines.h"
#include "AngTypes.h"
#include "AngDescriptors.h"
#include "AngDriver.h"
#include "AngFrame.h"
#include "AngStreamConfig.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN


    class SensorImpl {

    public:
        explicit SensorImpl(std::shared_ptr<Driver> driver, std::shared_ptr<AngDescriptor> descriptor,
                   std::shared_ptr<AngDevInfo> devInfo);

        ~SensorImpl();

        SensorImpl &operator=(const SensorImpl &rhs) = delete;

        SensorImpl(const SensorImpl &context) = delete;

        AngSensorType getSensorType() const;

        std::vector<ang_stream_config*> getStreamConfigList() const;

        int start(long sensorHandle, ang_stream_config* streamConfig,
                  FrameCallback callback);

        int stop();

        int switchConfig(ang_stream_config* streamConfig);

    private:
        std::shared_ptr<AngDescriptor> usb_descriptor_{nullptr};
        std::shared_ptr<Driver> driver_{nullptr};
        std::vector<ang_stream_config*> stream_config_list_{nullptr};

        std::shared_ptr<AngDevInfo> dev_info_{nullptr};
        AngSensorType sensor_type_{ANG_SENSOR_UNKNOWN};
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //ANGCAMSDK_ANGSENSORIMPL_H
