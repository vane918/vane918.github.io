/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_DEVICE_H_
#define _ANG_DEVICE_H_

#include <stdint.h>
#include <string>
#include <memory>

#include "AngTypes.h"
#include "AngDefines.h"

#include "AngSensor.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class DeviceImpl;

    class DeviceList;

    class DeviceListImpl;

    class CameraParamList;

    class CameraParamListImpl;

    class DeviceInfo;

    class DeviceInfoImpl;

    class SensorList;

    class AngDescriptor;

    using DeviceOnUpgradeCallback = std::function<void(const AngDeviceUpgradeInfo *pInfo, void *)>;

    class Device {
    private:
        std::unique_ptr<DeviceImpl> impl_;

    public:
        /**
         * @brief 描述RGBD相机的实体，代表一个具体型号的RGBD相机
         */
        explicit Device(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo);

        ~Device();

        /**
         * 打开一个camera模组，如果不需要java层打开camera模组，则fd设为0
         *
         * @param fd：camera模组的文件描述符
         * @return 0：成功；其他值：失败
         */
        int angOpen(int fd);

        /**
         * 如果camera模组有MCU模块，如女娲星模组则需要调用该函数来操作
         *
         * @param fd：camera模组MCU模块的文件描述符
         * @return 0：成功；其他值：失败
         */
        int angOpenMcu(int fd);

        /**
         * 关闭一个camera模组
         *
         * @param
         * @return 0：成功；其他值：失败
         */
        int angClose();

        /**
         * @brief 获取设备信息
         *
         * @return std::shared_ptr<DeviceInfo> 返回设备的信息
         */
        std::shared_ptr<DeviceInfo> getDeviceInfo() const;

        /**
         * @brief 热插拔后更新设备信息，该API仅供内部使用
         * @param: devInfo:需要更新的设备信息
         *
         * @return 0：成功；其他值：失败
         */
        int updateDeviceInfo(std::shared_ptr<AngDevInfo> devInfo);

        /**
         * @brief 获取设备传感器列表
         *
         * @return std::shared_ptr<SensorList> 返回传感器列表
         */
        std::shared_ptr<SensorList> getSensorList() const;

        /**
         * @Description: 发送自定义MCU命令
         * @param: sn:enumerateDevices()函数返回的uvc设备的sn；
         * @param: value：发送自定义命令的buff，也是接收返回结果的buff，如获取SN的命令：下发"ARG READ:SN="，
         * 然后根据len长度来取value的值，value开辟空间建议设为传输的最大值：64 bytes
         * @param: len：value的长度
         * @return: 0: 成功; 其他: 失败
         **/
        int communicateWithMcu(char** value, int& len);

        /**
        * @brief 获取设备属性
        *
        * @param propertyId 属性id
        * @param info 填充获取设备属性的buffer
        * @return 0：成功，其他值：失败
        */
        int getFirmwareInfo(AngPropertyID propertyId, char **info) const;

        /**
        * @brief 设置设备属性
        *
        * @param propertyId 属性id
        * @param value 需要设置设备属性的信息
        * @param len  需要设置设备属性的信息长度
        * @return 0：成功，其他值：失败
        */
        int setFirmwareInfo(AngPropertyID propertyId, const char* value, int len) const;

        /**
         * @brief 获取SE芯片信息
         *
         * @param propertyId 需要获取SE芯片的指令
         * @param info 填充获取SE芯片的buffer
         * @return 0：成功，其他值：失败
         */
        int getChipSeInfo(AngPropertyID propertyId, char **info) const;

        /**
        * @brief 设置SE芯片信息
        *
        * @param propertyId 需要获取SE芯片的指令
        * @param value 需要设置SE芯片的信息
        * @param len 需要设置SE芯片的信息长度
        * @return 0：成功，其他值：失败
        */
        int setChipSeInfo(AngPropertyID propertyId, const char* value, int len) const;

        /**
         * 升级camera模组
         *
         * @param cmd：需要升级的选项
         * @param upgradeFile：升级文件
         * @param callback：升级过程中的回调函数
         * @return 0：成功，其他值：失败
         */
        int upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback);

        /**
         * 取消camera模组升级，目前不支持中途打断camera模组升级
         *
         * @param
         * @return 0：成功，其他值：失败
         */
        int cancelUpgradeCamera();

        /**
         * 重启camera模组，目前不支持
         *
         * @param
         * @return 0：成功，其他值：失败
         */

        int angReboot();

        /**
         * @brief 获取设备内保存的相机标定的原始参数列表，目前不支持
         *
         * @return std::shared_ptr<CameraParamList> : nullptr：失败
         */
        std::shared_ptr<CameraParamList> getCalibrationCameraParamList() const;

    };

    class DeviceInfo {
    private:
        std::unique_ptr<DeviceInfoImpl> impl_;

    public:
        explicit DeviceInfo(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo);

        ~DeviceInfo();

        /**
         * @brief 获取设备名称
         *
         * @return std::string 返回设备名称
         */
        std::string getDeviceName() const;

        /**
         * @brief 获取设备的bus号
         *
         * @return std::string 返回设备的bus号
         */
        std::string getDeviceBus() const;

        /**
         * @brief 获取设备的dev号
         *
         * @return std::string 返回设备的dev号
         */
        std::string getDeviceDevId() const;

        /**
         * @brief 获取设备的pid
         *
         * @return std::string 返回设备的pid
         */
        std::string getDevicePid() const;

        /**
         * @brief 获取设备的vid
         *
         * @return std::string 返回设备的vid
         */
        std::string getDeviceVid() const;

        /**
         * @brief 获取设备的uid，该uid标识设备接入os操作系统时，给当前设备分派的唯一id，用来区分不同的设备
         *
         * @return std::string 返回设备的uid
         */
        std::string getDeviceUid() const;

        /**
         * @brief 获取设备的devpath，devpath可以看做是物理端口
         *
         * @return std::string 返回设备的devpath
         */
        std::string getDeviceDevPath() const;

        /**
         * @brief 获取设备的mcu uid，该uid标识设备接入os操作系统时，给当前设备分派的唯一id，用来区分不同的设备
         *
         * @return std::string 返回mcu设备的uid
         */
        std::string getDeviceMcuUid() const;

        /**
         * @brief 获取设备的序列号
         *
         * @return std::string 返回设备的序列号
         */
        std::string getDeviceSerialNumber() const;

        /**
         * @brief 获取固件的版本号
         *
         * @return std::string 返回固件的版本号
         */
        std::string getDeviceFirmwareVersion() const;

        /**
         * @brief 获取硬件的版本号
         *
         * @return std::string 返回硬件的版本号
         */
        std::string getDeviceHardwareVersion() const;

    };

    class DeviceList {
    private:
        std::unique_ptr<DeviceListImpl> impl_;

    public:
        explicit DeviceList(std::shared_ptr<AngDescriptor> descriptor, std::map<std::string, unsigned char *>* rawDescriptors);

        ~DeviceList();

        /**
          * @brief 获取设备数量
          * @return uint8_t 返回设备的数量
          */
        uint8_t getDeviceCount() const;

        /**
         * @brief 获取指定设备的名称
         *
         * @param index 设备索引
         * @return std::string 返回设备的名称
         */
        std::string getDeviceName(uint8_t index) const;

        /**
         * @brief 获取指定设备的bus号
         *
         * @param index 设备索引
         * @return std::string 返回设备的bus号
         */
        std::string getDeviceBus(uint8_t index) const;

        /**
         * @brief 获取指定设备的dev号
         *
         * @param index 设备索引
         * @return std::string 返回设备的dev号
         */
        std::string getDeviceDevId(uint8_t index) const;

        /**
         * @brief 获取指定设备的pid
         *
         * @param index 设备索引
         * @return std::string 返回设备的pid
         */
        std::string getDevicePid(uint8_t index) const;

        /**
         * @brief 获取指定设备的vid
         *
         * @param index 设备索引
         * @return std::string 返回设备的vid
         */
        std::string getDeviceVid(uint8_t index) const;

        /**
         * @brief 获取指定设备的uid
         *
         * @param index 设备索引
         * @return std::string 返回设备的uid
         */
        std::string getDeviceUid(uint8_t index) const;

        /**
         * @brief 获取指定设备的序列号
         *
         * @param index 设备索引
         * @return std::string 返回设备的序列号
         */
        std::string getDeviceSerialNumber(uint8_t index) const;

        /**
         * @brief 从设备列表中获取指定设备对象,
         * @attention 如果设备有在其他地方被获取创建，重复获取将会抛异常
         * @param index 要创建设备的索引
         * @return std::shared_ptr<Device> 返回设备对象
         */
        std::shared_ptr<Device> getDevice(uint8_t index) const;

        /**
         * @brief 从设备列表中获取指定设备对象
         * @attention 如果设备有在其他地方被获取创建，重复获取将会抛异常
         * @param serialNumber 要创建设备的序列号
         * @return std::shared_ptr<Device> 返回设备对象
         */
        std::shared_ptr<Device> getDeviceBySN(const char *serialNumber) const;

        /**
         * @brief 从设备列表中获取指定设备对象
         * @attention 如果设备有在其他地方被获取创建，重复获取将会抛异常
         * @param uid 要创建设备的uid
         * @return std::shared_ptr<Device> 返回设备对象
         */
        std::shared_ptr<Device> getDeviceByUid(const char *uid) const;
    };

    class CameraParamList {
    private:
        std::unique_ptr<CameraParamListImpl> impl_;

    public:
        explicit CameraParamList(std::unique_ptr<CameraParamListImpl> impl);

        ~CameraParamList();

        /**
         * @brief 相机参数组数
         *
         * @return uint8_t 返回相机参数组数
         */
        uint8_t getCameraParamCount() const;

        /**
         * @brief 获取相机参数
         *
         * @param index 参数索引
         * @return AngCameraParam 返回对应组参数
         */
        AngCameraParam getCameraParam(uint8_t index) const;
    };

ANG_NAMESPACE_IMPLEMENTATION_END
#endif //_ANG_DEVICE_H_
