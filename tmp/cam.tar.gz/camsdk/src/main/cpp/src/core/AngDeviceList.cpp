/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <memory>

#include "AngDeviceListImpl.h"
#include "AngLog.hpp"
#include "AngUsbUtil.h"

using namespace ang;

DeviceList::DeviceList(std::shared_ptr<AngDescriptor> descriptor, std::map<std::string, unsigned char *>* rawDescriptors) :
    impl_(std::make_unique<DeviceListImpl>(descriptor, rawDescriptors)) {
}

DeviceList::~DeviceList() {
}

uint8_t DeviceList::getDeviceCount() const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceCount failed, DeviceList already release");
        return 0;
    }
    return impl_->getDeviceCount();
}

std::string DeviceList::getDeviceName(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceName failed, DeviceList already release");
        return "";
    }
    return impl_->getDeviceName(index);
}

std::string DeviceList::getDeviceBus(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceBus failed, DeviceList already release");
        return "";
    }
    return impl_->getDeviceBus(index);
}

std::string DeviceList::getDeviceDevId(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceDevId failed, DeviceList already release");
        return "";
    }
    return impl_->getDeviceDevId(index);
}

std::string DeviceList::getDevicePid(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDevicePid failed, DeviceList already release");
        return "";
    }
    return impl_->getDevicePid(index);
}

std::string DeviceList::getDeviceVid(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceVid failed, DeviceList already release");
        return "";
    }
    return impl_->getDeviceVid(index);
}

std::string DeviceList::getDeviceUid(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceUid failed, DeviceList already release");
        return "";
    }
    return impl_->getDeviceUid(index);
}

std::string DeviceList::getDeviceSerialNumber(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceSerialNumber failed, DeviceList already release");
        return "";
    }
    return impl_->getDeviceSerialNumber(index);
}

std::shared_ptr<Device> DeviceList::getDevice(uint8_t index) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDevice failed, DeviceList already release");
        return nullptr;
    }
    return impl_->getDevice(index);
}

std::shared_ptr<Device> DeviceList::getDeviceBySN(const char *serialNumber) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceBySN failed, DeviceList already release");
        return nullptr;
    }
    return impl_->getDeviceBySN(serialNumber);
}

std::shared_ptr<Device> DeviceList::getDeviceByUid(const char *uid) const {
    if (!this) {
        ANG_LOGE("DeviceList::getDeviceByUid failed, DeviceList already release");
        return nullptr;
    }
    return impl_->getDeviceByUid(uid);
}


DeviceListImpl::DeviceListImpl(std::shared_ptr<AngDescriptor> descriptor, std::map<std::string, unsigned char *>* rawDescriptors) {
    if (descriptor) {
        device_list_ = std::make_shared<AngDeviceList>();
        auto device_descriptors = descriptor->getUsbDeviceDescriptors();
        for (auto &dev : *device_descriptors) {
            ANG_LOGI("device:%s", dev->dump().c_str());
            auto angDevInfo = dev->getAngDevInfo();
            if (angDevInfo->type == UNKNOWN_DEV) {
                ANG_LOGE("device:%s is unknown type device", dev->dump().c_str());
                continue;
            }
            if (angDevInfo->type == USB_DEV) {
                //MCU设备特殊处理：
                //1.如果MCU设备没有找到对应的UVC设备，则认为设备已变砖（设备变砖, 使用自研的boot, MCU设备(4348:5537)存在, ISP不在）
                //这种情况需要创建一个device供上层升级使用(即使该device已变砖)
                //2.如果MCU设备找到对应的UVC设备，则跳过该设备，因为device是UVC出流的设备
                if (checkAngMcuDev(dev->getAngDevInfo()->usb.uid)) {
                    auto uvc_devpath = getDevPath(dev->getAngDevInfo()->usb.devpath, descriptor);
                    ANG_LOGI("getDevPath:%s", uvc_devpath.c_str());
                    if (!uvc_devpath.empty())
                        continue;
                }
                auto device = std::make_shared<Device>(descriptor, angDevInfo);
                device_list_->emplace_back(device);
                auto config = dev->getConfigurationDescriptor();
                ANG_LOGI("config:%s", config->dump().c_str());
                auto interfaces = config->getInterfaceDescriptorList();
                for (auto &interface : *interfaces) {
                    ANG_LOGI("interface:%s", interface->dump().c_str());
                    auto endpoints = interface->getEndpointDescriptorList();
                    for (auto &endpoint : *endpoints) {
                        ANG_LOGI("endpoint:%s", endpoint->dump().c_str());
                    }
                }
                auto formats = config->getFormatTypeDescriptorList();
                for (auto &format : *formats) {
                    ANG_LOGI("format:%s", format->dump().c_str());
                    auto frames = format->getFrameTypeDescriptorList();
                    for (auto &frame : *frames) {
                        ANG_LOGI("frame:%s", frame->dump().c_str());
                    }
                }
            }
            else {
                auto device = std::make_shared<Device>(descriptor, angDevInfo);
                device_list_->emplace_back(device);
            }
        }
    }
}

uint8_t DeviceListImpl::getDeviceCount() const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return 0;
    }
    return device_list_->size();
}

std::string DeviceListImpl::getDeviceName(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDeviceName();
}

std::string DeviceListImpl::getDeviceBus(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDeviceBus();

}

std::string DeviceListImpl::getDeviceDevId(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDeviceDevId();

}

std::string DeviceListImpl::getDevicePid(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDevicePid();
}

std::string DeviceListImpl::getDeviceVid(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDeviceVid();
}

std::string DeviceListImpl::getDeviceUid(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDeviceUid();
}

std::string DeviceListImpl::getDeviceSerialNumber(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return "";
    }
    if (device_list_->size() <= index)
        return "";

    return device_list_->at(index)->getDeviceInfo()->getDeviceSerialNumber();
}

std::shared_ptr<Device> DeviceListImpl::getDevice(uint8_t index) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return nullptr;
    }
    if (device_list_->size() <= index)
        return nullptr;

    return device_list_->at(index);
}

std::shared_ptr<Device> DeviceListImpl::getDeviceBySN(const char *serialNumber) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return nullptr;
    }
    for (auto &it : *device_list_) {
        auto sn = it->getDeviceInfo()->getDeviceSerialNumber();
        if (sn == std::string(serialNumber))
            return it;
    }

    return nullptr;
}

std::shared_ptr<Device> DeviceListImpl::getDeviceByUid(const char *uid) const {
    if (!device_list_) {
        ANG_LOGE("device_list_ is null");
        return nullptr;
    }
    for (auto &it : *device_list_) {
        auto uid = it->getDeviceInfo()->getDeviceUid();
        if (uid == std::string(uid))
            return it;
    }

    return nullptr;
}