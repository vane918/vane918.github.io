/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_CONTEXTIMPL_H_
#define _ANG_CONTEXTIMPL_H_

#include <memory>
#include <atomic>

#include "Mutex.h"
#include "AngDefines.h"
#include "AngTypes.h"
#include "AngDevice.h"
#include "AngDescriptors.h"
#include "AngCameraSession.h"
#include "Backend.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class ContextImpl {

    public:
        explicit ContextImpl();

        ~ContextImpl();

        ContextImpl &operator=(const ContextImpl &rhs) = delete;

        ContextImpl(const ContextImpl &context) = delete;

        AngStatus initialize();

        AngStatus shutdown();

        std::shared_ptr<DeviceList> enumerateDevices(std::map<std::string, unsigned char *>* rawDescriptors);

        std::shared_ptr<DeviceList> getDeviceList() const;

        std::shared_ptr<CameraSession> createCameraSession(std::shared_ptr<Device> device);

        int registerDeviceChangeCallback(void* ptr, deviceChangedCallback callback);

        int unregisterDeviceChangeCallback(void* ptr);

        static void onDeviceChangedCallback(void* ptr, std::string action, AngDevInfo devInfo);

        int enableAutoReconnect(bool enable);

    private:
        std::atomic<bool> initialized_{false};
        bool auto_reconnect_{false};
        std::shared_ptr<AngDescriptor> usb_descriptor_{nullptr};
        std::shared_ptr<DeviceList> device_list_{nullptr};
        Mutex mutex_;
        std::vector<std::shared_ptr<CameraSession>> camera_session_list_;
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_CONTEXTIMPL_H_
