/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "AngFramePool.h"

using namespace ang;

AngFramePool::AngFramePool(int bufferSize) : frame_size_(bufferSize) {
    this->head_ = 0;
    this->tail_ = 0;
    this->length_ = 0;
    this->total_ = 3;
    this->buffers_.reserve(3);
    for (int i = 0; i < 3; ++i) {
        this->buffers_.emplace_back(std::make_shared<Frame>());
        this->buffers_[i]->data_ = static_cast<uint8_t *>(malloc(bufferSize));
    }
}

AngFramePool::~AngFramePool() {
    for (int i = 0; i < this->total_; i++) {
        free(this->buffers_[i]->data_);
        this->buffers_[i]->data_ = nullptr;
    }
}

/**
* 获取一个缓冲区 当缓冲池已满时，覆盖旧数据
*/
std::shared_ptr<Frame> AngFramePool::get_frame_buffer() {
    auto buffer = this->buffers_[this->tail_];
    // tail指针指向下一个缓冲区，如果当前缓冲池已满，头指针下移
    this->tail_ = (this->tail_ + 1) % this->total_;
    this->length_++;
    if (this->length_ > this->total_) {
        this->head_ = (this->head_ + 1) % this->total_;
        this->length_ = this->total_;
    }
    return buffer;
}

/**
* 获取头缓冲区并弹出
*/
std::shared_ptr<Frame> AngFramePool::pop_frame_buffer() {
    if (this->length_ == 0) {
        return nullptr;
    }
    auto buffer = this->buffers_[this->head_];
    this->head_ = (this->head_ + 1) % this->total_;
    this->length_--;
    return buffer;
}

bool AngFramePool::empty() const {
    return this->length_ == 0;
}

bool AngFramePool::full() const {
    return this->length_ == this->total_;
}

int AngFramePool::getFrameSize() const {
    return frame_size_;
}