/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_DEVICEIMPL_H_
#define _ANG_DEVICEIMPL_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>

#include "AngDefines.h"
#include "AngDevice.h"
#include "AngDescriptors.h"
#include "AngTypes.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class DeviceInfoImpl {

    public:
        explicit DeviceInfoImpl(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo);

        DeviceInfoImpl &operator=(const DeviceInfoImpl &rhs) = delete;

        DeviceInfoImpl(const DeviceInfoImpl &context) = delete;

        /**
         * @brief 获取设备名称
         *
         * @return std::string 返回设备名称
         */
        std::string getDeviceName() const;

        /**
        * @brief 获取设备的bus号
        *
        * @return std::string 返回设备的bus号
        */
        std::string getDeviceBus() const;

        /**
         * @brief 获取设备的dev号
         *
         * @return std::string 返回设备的dev号
         */
        std::string getDeviceDevId() const;

        /**
         * @brief 获取设备的pid
         *
         * @return std::string 返回设备的pid
         */
        std::string getDevicePid() const;

        /**
         * @brief 获取设备的vid
         *
         * @return std::string 返回设备的vid
         */
        std::string getDeviceVid() const;

        /**
         * @brief 获取设备的uid，该uid标识设备接入os操作系统时，给当前设备分派的唯一id，用来区分不同的设备
         *
         * @return std::string 返回设备的uid
         */
        std::string getDeviceUid() const;

        /**
         * @brief 获取设备的devpath，devpath可以看做是物理端口
         *
         * @return std::string 返回设备的devpath
         */
        std::string getDeviceDevPath() const;

        /**
         * @brief 获取设备的mcu uid，该uid标识设备接入os操作系统时，给当前设备分派的唯一id，用来区分不同的设备
         *
         * @return std::string 返回mcu设备的uid
         */
        std::string getDeviceMcuUid() const;

        /**
         * @brief 获取设备的序列号
         *
         * @return std::string 返回设备的序列号
         */
        std::string getDeviceSerialNumber() const;

        /**
         * @brief 获取固件的版本号
         *
         * @return std::string 返回固件的版本号
         */
        std::string getDeviceFirmwareVersion() const;

        /**
         * @brief 获取硬件的版本号
         *
         * @return std::string 返回硬件的版本号
         */
        std::string getDeviceHardwareVersion() const;

    private:
        std::shared_ptr<AngDescriptor> usb_descriptor_{nullptr};
        std::shared_ptr<AngDevInfo> dev_info_;
    };

ANG_NAMESPACE_IMPLEMENTATION_END


#endif //_ANG_DEVICEIMPL_H_
