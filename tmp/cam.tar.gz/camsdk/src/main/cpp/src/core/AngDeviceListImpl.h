/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_DEVICELISTIMPL_H_
#define _ANG_DEVICELISTIMPL_H_

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>

#include "AngDefines.h"
#include "AngDevice.h"
#include "AngDescriptors.h"
#include "AngDeviceImpl.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    using AngDeviceList = std::vector<std::shared_ptr<Device>>;

    class DeviceListImpl {

    public:
        explicit DeviceListImpl(std::shared_ptr<AngDescriptor> descriptor, std::map<std::string, unsigned char *>* rawDescriptors);

        DeviceListImpl &operator=(const DeviceListImpl &rhs) = delete;

        DeviceListImpl(const DeviceListImpl &context) = delete;

        /**
         * @brief 获取设备数量
         * @return uint8_t 返回设备的数量
         */
        uint8_t getDeviceCount() const;

        /**
         * @brief 获取指定设备的名称
         *
         * @param index 设备索引
         * @return int 返回设备的名称
         */
        std::string getDeviceName(uint8_t index) const;

        /**
         * @brief 获取指定设备的bus号
         *
         * @param index 设备索引
         * @return int 返回设备的bus号
         */
        std::string getDeviceBus(uint8_t index) const;

        /**
         * @brief 获取指定设备的dev号
         *
         * @param index 设备索引
         * @return int 返回设备的dev号
         */
        std::string getDeviceDevId(uint8_t index) const;

        /**
         * @brief 获取指定设备的pid
         *
         * @param index 设备索引
         * @return std::string 返回设备的pid
         */
        std::string getDevicePid(uint8_t index) const;

        /**
         * @brief 获取指定设备的vid
         *
         * @param index 设备索引
         * @return std::string 返回设备的vid
         */
        std::string getDeviceVid(uint8_t index) const;

        /**
         * @brief 获取指定设备的uid
         *
         * @param index 设备索引
         * @return std::string 返回设备的uid
         */
        std::string getDeviceUid(uint8_t index) const;

        /**
         * @brief 获取指定设备的序列号
         *
         * @param index 设备索引
         * @return std::string 返回设备的序列号
         */
        std::string getDeviceSerialNumber(uint8_t index) const;

        /**
         * @brief 从设备列表中获取指定设备对象,
         * @attention 如果设备有在其他地方被获取创建，重复获取将会抛异常
         * @param index 要创建设备的索引
         * @return std::shared_ptr<Device> 返回设备对象
         */
        std::shared_ptr<Device> getDevice(uint8_t index) const;

        /**
         * @brief 从设备列表中获取指定设备对象
         * @attention 如果设备有在其他地方被获取创建，重复获取将会抛异常
         * @param serialNumber 要创建设备的序列号
         * @return std::shared_ptr<Device> 返回设备对象
         */
        std::shared_ptr<Device> getDeviceBySN(const char *serialNumber) const;

        /**
         * @brief 从设备列表中获取指定设备对象
         * @attention 如果设备有在其他地方被获取创建，重复获取将会抛异常
         * @param uid 要创建设备的uid
         * @return std::shared_ptr<Device> 返回设备对象
         */
        std::shared_ptr<Device> getDeviceByUid(const char *uid) const;

    private:
        std::shared_ptr<AngDeviceList> device_list_;
    };

ANG_NAMESPACE_IMPLEMENTATION_END


#endif //_ANG_DEVICELISTIMPL_H_
