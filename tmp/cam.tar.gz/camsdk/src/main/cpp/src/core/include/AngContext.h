/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_CONTEXT_H_
#define _ANG_CONTEXT_H_

#include <atomic>
#include <memory>

#include "AngDevice.h"
#include "AngCameraSession.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    /**
     * camera模组热插拔回调函数，camera模组插入或拔出都会触发该回调函数
     *
     * @param ptr：注册监听热插拔的调用者的指针，可以设置为调用方类的实例
     * @param action：camera模组插入时"add"，拔出是"remove"
     * @param devInfo：camera模组信息
     * @return
     */
    typedef std::function<void(void* ptr, std::string action, AngDevInfo devInfo)> deviceChangedCallback;

    class ContextImpl;
    /**
     * @brief 表示SDK上下文，使用SDK功能前需要调用Context的initialize，销毁SDK前需要调用shutdown
     */
    class Context {
    public:
        explicit Context();

        ~Context();

        Context &operator=(const Context &rhs) = delete;

        Context(const Context &context) = delete;

        /**
         * SDK初始化，使用SDK前需要调用该函数
         *
         * @param
         * @return 0：成功；其他值：失败
         */
        AngStatus initialize();

        /**
         * SDK反初始化
         *
         * @param
         * @return 0：成功；其他值：失败
         */
        AngStatus shutdown();

        /**
         * 遍历设备, initialize()之后只需要调用一次enumerateDevices()函数
         * 后续获取std::shared_ptr<DeviceList>请调用getDeviceList()
         *
         * @param
         * @return std::shared_ptr<DeviceList>：返回DeviceList智能指针对象
         */
        std::shared_ptr<DeviceList> enumerateDevices() const;

        /**
         * 遍历设备
         * 该接口是适配没有root权限或开启SELinux权限的设备
         * 有root权限和关闭了SELinux权限的设备请调用enumerateDevices()
         *
         * @param rawDescriptors：java层传递下来的描述符
         * @return std::shared_ptr<DeviceList>：返回DeviceList智能指针对象
         */
        std::shared_ptr<DeviceList> enumerateDevices(std::map<std::string, unsigned char *>* rawDescriptors) const;

        /**
         * 返回遍历阶段遍历到的设备，该函数不做遍历操作
         *
         * @param
         * @return std::shared_ptr<DeviceList>：返回DeviceList智能指针对象
         */
        std::shared_ptr<DeviceList> getDeviceList() const;

        /**
         * SDK版本号
         *
         * @param
         * @return std::string：SDK版本号
         */
        static std::string getSDKVersion();

        /**
         * 构建camera session，屏蔽底层api细节，只关注开流和关流
         *
         * @param device：device智能指针
         * @return std::shared_ptr<CameraSession>：CameraSession的智能指针
         */
        std::shared_ptr<CameraSession> createCameraSession(std::shared_ptr<Device> device);

        /**
         * 注册监控USB设备热插拔事件
         *
         * @param ptr：注册监听热插拔的调用者的指针，可以设置为调用方类的实例，通过callback返回
         * @param callback：USB设备热插拔回调函数
         * @return 0：成功；其他值：失败
         */
        int registerDeviceChangeCallback(void* ptr, deviceChangedCallback callback);

        /**
         * 反注册监控USB设备热插拔事件
         *
         * @param ptr：注册监听热插拔的调用者的指针，可以设置为调用方类的实例
         * @return 0：成功；其他值：失败
         */
        int unregisterDeviceChangeCallback(void* ptr);

        /**
         * 开启保存日志到文件的功能，默认是关闭
         * 日志默认保存在/sdcard/ang_log目录下，需要调用者开启sdcard读写权限
         *
         * @param enable: true:开启保存日志功能；false: 关闭保存日志功能
         * @return 0:成功；其他值：失败
         */
        static int enableLogToFile(bool enable);

        /**
         * 开启camera断线自动重连功能，默认是关闭
         * 目前只针对使用CameraSession开关camera的情况使用断线自动重连
         * 目前版本只针对单个camera的情况使用断线自动重连功能，后续支持多个camera断线自动重连功能
         *
         * @param enable: true:开启camera断线自动重连功能；false: 关闭camera断线自动重连功能
         * @return 0:成功；其他值：失败
         */
        int enableAutoReconnect(bool enable);

    private:
        std::unique_ptr<ContextImpl> impl_{nullptr};

    };

ANG_NAMESPACE_IMPLEMENTATION_END
#endif //_ANG_CONTEXT_H_
