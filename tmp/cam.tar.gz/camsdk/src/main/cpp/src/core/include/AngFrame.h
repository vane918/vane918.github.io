/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_FRAME_H_
#define _ANG_FRAME_H_

#include <memory>
#include <typeinfo>
#include <stdint.h>
#include <functional>

#include "AngTypes.h"
#include "AngDefines.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    class Frame {
        friend class Driver;

        friend class AngFramePool;

    public:

        /**
         * @brief 获取帧的类型
         *
         * @return AngFrameType 返回帧的类型
         */
        AngFrameType getType();

        /**
         * @brief 获取帧的格式
         *
         * @return AngFormat 返回帧的格式
         */
        AngFormat getFormat();

        /**
         * @brief 获取帧的序号
         *
         * @return uint64_t 返回帧的序号
         */
        uint64_t getIndex();

        /**
         * @brief 获取帧数据
         *
         * @return void* 返回帧数据
         */
        void *getData();

        /**
         * @brief 获取帧数据大小
         *
         * @return uint32_t 返回帧数据的大小
         * 如果是点云数据返回的是所有点集合占的字节数，若需要求出点的个数需要将dataSize除以对应的点类型的结构体大小
         */
        uint32_t getDataSize();

        /**
         * @brief 获取帧的硬件时间戳
         *
         * @return uint64_t 返回帧硬件的时间戳
         */
        uint64_t getTimeStamp();

        /**
         * @brief 获取帧的宽
         *
         * @return uint64_t 返回帧的宽
         */
        uint16_t getWidth();

        /**
         * @brief 获取帧的高
         *
         * @return uint64_t 返回帧的高
         */
        uint16_t getHeight();

    private:
        AngFrameType type_;
        AngFormat format_;
        uint64_t index_;
        void *data_;
        uint32_t size_;
        uint64_t timeStamp_;
        uint16_t width_;
        uint16_t height_;
    };

    using FrameCallback = std::function<void(long sensorHandle, std::shared_ptr<Frame> frame)>;

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_FRAME_H_
