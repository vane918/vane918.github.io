/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _MCU_DEV_BASE_H_
#define _MCU_DEV_BASE_H_

#include "AngMcuUtil.h"
#include "AngDefines.h"
#include "AngDescriptors.h"
#include "AngUsbUtil.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

const static std::string UNKNOWN_STATUS = "unknown";

class McuDevBase {

public:
    McuDevBase(std::shared_ptr<AngDescriptor> descriptor, std::string uid, AngBurnType burn_type) :
            mcu_descriptor_(descriptor), mcu_uid_(uid), burn_type_(burn_type){
        //旧的变砖设备没有MCU，只有ISP，因此传过来的uid是ISP的
        std::string uvc_devpath = "";
        auto deviceDescriptors = descriptor->getUsbDeviceDescriptors();
        for (auto &dev : *deviceDescriptors) {
            if (dev->getAngDevInfo()->usb.uid == uid) {
                mcu_dev_info_ = dev->getAngDevInfo();
                if (!checkAngMcuDev(uid)) {
                    uvc_devpath = dev->getAngDevInfo()->usb.devpath;
                } else {
                    uvc_devpath = getDevPath(mcu_dev_info_->usb.devpath, descriptor);
                }
                break;
            }
        }

        std::vector<std::string> videoNames;
        findDevVideo(videoNames);
        for (auto video_path : videoNames) {
            if (uvc_devpath.empty())
                break;

            if (uvc_devpath.find(getUvcDevpath(video_path)) != std::string::npos) {
                video_path_ = video_path;
                break;
            }
        }

        ANG_LOGI("video_path_:%s", video_path_.c_str());

    }

    virtual ~McuDevBase() {
    }

    virtual int communicateWithDevice(char **value, int &len) = 0;

    virtual int openDevice(int fd) = 0;

    virtual int closeDevice() = 0;

    /**
    * @Description: 固件升级，如himax、标定文件等
    * @param:upgradeFile：升级文件绝对路径
    * info：需要升级的指令，表示升级的类型，如himax；
    * @return: 0: 成功; 其他: 失败
    **/
    virtual int upgradeFirmware(const std::string &upgradeFile, const std::string &info) = 0;

    /**
     * @Description: MCU升级，耗时操作，需要调用方在子线程调用该接口进行MCU升级。
     * upgradeFilePath：MCU升级文件的绝对路径； mcuDriverPath：MCU沁恒驱动的绝对路径
     * @return: 0: 成功; 其他: 失败，具体失败值见本头文件上面的相关的失败项说明
     **/
    virtual int upgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath) = 0;

    virtual std::string getMcuVersion() = 0;

    virtual std::string getHiMaxVersion() = 0;

    virtual int setInsideOutsideParam() = 0;

protected:
    std::shared_ptr<AngDescriptor> mcu_descriptor_;
    std::string mcu_uid_;

    std::vector<float> gParams;

    std::shared_ptr<AngDevInfo> mcu_dev_info_;

    AngBurnType burn_type_;

    std::string video_path_{""};// /dev/video*

    virtual int enterMcuLoaderMode() = 0;

    int doUpgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath) {
        int rc = ANG_STATUS_SUCCESS;
        ANG_LOGI("upgradeMcuDevice: %s", upgradeFilePath.c_str());
        //1. 动态加载MCU升级驱动
        rc = insmodMCUDriver(mcuDriverPath.c_str());
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("upgradeMcuDevice: insmodMCUDriver failed");
            rmmodMCUDriver();
            return STATUS_FAILED_INSMOD_MCU_DRIVER;
        }
        rc = doMCUDownLoad(const_cast<char *>(upgradeFilePath.c_str()));
        ANG_LOGI("upgradeMcuDevice: doMCUDownLoad rc:%d", rc);
        rmmodMCUDriver();
        return rc;
    }
};


ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_MCU_DEV_BASE_H_