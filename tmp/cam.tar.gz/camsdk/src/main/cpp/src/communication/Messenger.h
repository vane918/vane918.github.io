/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_USB_MESSENGER_H_
#define _ANG_USB_MESSENGER_H_

#include <sys/prctl.h>

#include "AngDefines.h"
#include "AngTypes.h"
#include "AngLog.hpp"
#include "AngUtil.h"
#include "AngDevice.h"
#include "AngDescriptors.h"
#include "AngDriver.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    typedef struct AngUpgradeInfo {
        std::string m_upgradeFile;
        int m_upgradeCmd;
    } AngUpgradeInfo;

    class Messenger {
        public:
            Messenger(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> uvc_info, long usbHandle,
                      std::shared_ptr<Driver> driver) : descriptor_(descriptor), uvc_dev_info_(uvc_info), driver_(driver){
            };

        virtual ~Messenger() {};

        virtual int getFirmwareInfo(AngPropertyID propertyId, char **info) = 0;

        virtual int setFirmwareInfo(AngPropertyID propertyId, const char *value, int len) = 0;

        virtual int getChipSeInfo(AngPropertyID propertyId, char **info) = 0;

        virtual int setChipSeInfo(AngPropertyID propertyId, const char *value, int len) = 0;

        virtual int upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) = 0;

        virtual int cancelUpgradeCamera() = 0;

        virtual int communicateWithDevice(char **value, int &len) = 0;

    protected:
        std::shared_ptr<AngDescriptor> descriptor_;
        std::shared_ptr<AngDevInfo> uvc_dev_info_;
        std::shared_ptr<Driver> driver_;
    };


ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_USB_MESSENGER_H_
