/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _VEGA_MESSENGER_H_
#define _VEGA_MESSENGER_H_

#include <string>
#include "Messenger.h"
#include "libusbi.h"
#include "AngThread.hpp"
#include "AngDevice.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN


class VegaMessenger : public Messenger{
public:
    VegaMessenger(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> uvc_info, long usbHandle,
                  std::shared_ptr<Driver> driver);

    virtual int getFirmwareInfo(AngPropertyID propertyId, char **info) override;

    virtual int setFirmwareInfo(AngPropertyID propertyId, const char *value, int len) override;

    virtual int getChipSeInfo(AngPropertyID propertyId, char **info) override;

    virtual int setChipSeInfo(AngPropertyID propertyId, const char *value, int len) override;

    virtual int upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) override;

    virtual int cancelUpgradeCamera() override;

    virtual int communicateWithDevice(char **value, int &len) {return ANG_STATUS_NOT_SUPPORT;}

    std::atomic<bool> upgrade_running_{false};

    inline AngUpgradeInfo getAngUpgradeInfo() const { return upgrade_info_; }

private:
    libusb_device_handle *dev_handle_;

    int doSendControl(uint8_t nRequest, uint8_t * pBuffer, uint32_t nBufferSize, uint32_t nTimeOut);

    int doReceiveControl(uint8_t nRequest, uint8_t * pBuffer, uint32_t nBufferSize,
                         uint32_t& pnBytesReceived, uint32_t nTimeOut);

    int angGetLongSeInfo(AngPropertyID cmd, char **info);
    int angSetLongSeInfo(AngPropertyID cmd, const char* value, int len);

    int angHostSeInfoSend(int cmd, const char* value, uint32_t nOffset,
                      uint32_t nPacketSize, uint32_t& nNextOffset);

    void angCallbackUpgradeFailed(int result);

    int angHostProtocolInitUpload(uint32_t nFileSize);

    int angHostProtocolWriteUpload(int &FileToUpload, uint32_t nOffset, uint32_t nFileSize, uint32_t & nNextOffset);

    int angHostProtocolFinishUpload(u_char* versionNo, int32_t& pUpgradeResult);

    DeviceOnUpgradeCallback upgrade_callback_{nullptr};

    std::shared_ptr<AngThread> upgrade_thread_{nullptr};

    static ANG_THREAD_PROC upgradeThread(ANG_THREAD_PARAM pThreadParam);

    AngUpgradeInfo upgrade_info_;

};


ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_VEGA_MESSENGER_H_