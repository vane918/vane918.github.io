/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "UsbMcuDev.h"

using namespace ang;

UsbMcuDev::UsbMcuDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid, AngBurnType burn_type) :
        McuDevBase(descriptor, uid, burn_type),
        UsbDevBase(descriptor, uid) {
}

UsbMcuDev::~UsbMcuDev() {
}

int UsbMcuDev::openDevice(int fd) {
    ANG_LOGI("UsbMcuDev openDevice fd:%d", fd);
    int rc = ANG_STATUS_SUCCESS;
    rc = UsbDevBase::openDevice(fd);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("UsbMcuDev openDevice failed:%d", rc);
        return rc;
    }
    std::string value = "ARG READ:SN=";
    std::string readOk = "READ OK";
    char *value_c = static_cast<char *>(malloc(32));
    memset(value_c, 0, 32);
    int len = value.size();
    memcpy(value_c, value.c_str(), value.size());
    rc = communicateWithDevice(&value_c, len);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("communicateWithDevice failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }

    std::string readData = value_c;
    if (readData.find(readOk) != std::string::npos) {
        //没写SN
        if (len == 8) {
            ang_dev_info_->usb.serialNumber = ang_dev_info_->usb.devpath + ":"+"noSN";
        } else if ( len == 29) {
            char *pSN = value_c + 16;
            ang_dev_info_->usb.serialNumber = pSN;
        } else {
            char *pSN = value_c + 8;
            ang_dev_info_->usb.serialNumber = pSN;
        }
    } else {
        ang_dev_info_->usb.serialNumber = ang_dev_info_->usb.devpath + ":"+"failed";
        rc = ANG_STATUS_FAILED;
    }
    free(value_c);
    ANG_LOGI("sn: %s", ang_dev_info_->usb.serialNumber.c_str());
    return rc;
}

int UsbMcuDev::closeDevice() {
    return UsbDevBase::closeDevice();
}

int UsbMcuDev::communicateWithDevice(char **value, int &len) {
    ANG_LOGI("[%s]communicateWithDevice, value:%s", mcu_uid_.c_str(), *value);
    Mutex::Autolock _l(ang_mutex_);
    if (len <= 0 || len > MAX_PACKET_SIZE) {
        ANG_LOGE("len is error, len:%d", len);
        return ANG_STATUS_FAILED;
    }
    uint32_t pnBytesReceived = 0;
    int rc = angHostProtocolUSBSend((u_char *) *value, len, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("communicateWithDevice write failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }

    u_char *receiveBuf = static_cast<u_char *>(malloc(MAX_BUFF_SIZE));
    memset(receiveBuf, 0, MAX_BUFF_SIZE);
    rc = angHostProtocolUSBReceive(receiveBuf, MAX_BUFF_SIZE, &pnBytesReceived, 2500);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("communicateWithDevice read failed, rc:%d", rc);
        free(receiveBuf);
        return ANG_STATUS_FAILED;
    }

    uint32_t receiveCount = 100;
    uint32_t temp_index = pnBytesReceived;
    ANG_LOGI("communicateWithDevice pnBytesReceived:%d", pnBytesReceived);
    while (--receiveCount != 0 && pnBytesReceived != 0) {
        rc = angHostProtocolUSBReceive(&receiveBuf[temp_index], MAX_BUFF_SIZE, &pnBytesReceived,
                                       100);
        temp_index = temp_index + pnBytesReceived;
        if (rc == ANG_STATUS_USB_TRANSFER_TIMEOUT) {
            break;
        }
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("AngCommunicateWithDevice read failed2, rc:%d", rc);
            free(receiveBuf);
            return ANG_STATUS_FAILED;
        }
    }
    len = temp_index;
    memset(*value, 0, len+1);
    memcpy(*value, receiveBuf, len);
    ANG_LOGI("AngCommunicateWithDevice end, len:%d, info:%s", len, *value);
    free(receiveBuf);
    return ANG_STATUS_SUCCESS;
}

static uint8_t ANG_PACKET_NO = 1;   // 数据包序号
static uint8_t ANG_RETRY_COUNT = 3; // 产生发送SE数据包的次数
int UsbMcuDev::upgradeFirmware(const std::string &upgradeFile, const std::string &info) {
    ANG_LOGI("AngDeviceUpgradeFirmware start, info:%s", info.c_str());
    Mutex::Autolock _l(ang_mutex_);
    int nRetVal = ANG_STATUS_SUCCESS;
    //0.允许升级
    ANG_LOGI("allow himax upgrade");
    std::string allowBuff = "DB6=1";
    nRetVal = angHostProtocolUSBSend((u_char *) allowBuff.c_str(), allowBuff.size(), 1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("allow himax upgrade failed, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    u_char receiveBuf[MAX_UPGRADE_PACKET_SIZE];
    uint32_t pnBytesReceived = 0;
    memset(receiveBuf, 0, MAX_UPGRADE_PACKET_SIZE);
    nRetVal = angHostProtocolUSBReceive(receiveBuf, MAX_UPGRADE_PACKET_SIZE, &pnBytesReceived,1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("enter the upgrade state failed2, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    std::string allowResult = reinterpret_cast<const char *>(receiveBuf);
    std::string resultFlag = "update enable";
    if (allowResult.find(resultFlag) == std::string::npos) {
        ANG_LOGE("upgradeFirmware failed, receive is :%s", receiveBuf);
        return ANG_STATUS_FAILED;
    }

    //1. 进入升级状态
    ANG_LOGI("Enter the upgrade state: %s", upgradeFile.c_str());
    std::string initBuff = "HimaxBoot\\r\\n";
    nRetVal = angHostProtocolUSBSend((u_char *) initBuff.c_str(), initBuff.size(), 1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("enter the upgrade state failed, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    pnBytesReceived = 0;
    memset(receiveBuf, 0, MAX_UPGRADE_PACKET_SIZE);
    nRetVal = angHostProtocolUSBReceive(receiveBuf, MAX_UPGRADE_PACKET_SIZE, &pnBytesReceived,
                                        1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("enter the upgrade state failed2, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    std::string initResult = reinterpret_cast<const char *>(receiveBuf);
    std::string targetResult = "HimaxBoot OK";
    if (initResult.find(targetResult) == std::string::npos) {
        ANG_LOGE("AngDeviceUpgradeFirmware failed, receive is 'HimaxBoot OK':%s", receiveBuf);
        return ANG_STATUS_FAILED;
    }
    //2. 开始升级文件
    ANG_LOGI("Start upgrading files");
    nRetVal = angHostProtocolUSBSend((u_char *) info.c_str(), info.size(), 1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("Start upgrading files failed, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    memset(receiveBuf, 0, MAX_UPGRADE_PACKET_SIZE);
    pnBytesReceived = 0;
    nRetVal = angHostProtocolUSBReceive(receiveBuf, MAX_UPGRADE_PACKET_SIZE, &pnBytesReceived,
                                        1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("enter the upgrade state failed2, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    if (receiveBuf[0] != 0x16) {
        ANG_LOGE("Start upgrading files failed, receiveBuf[0]:%x", receiveBuf[0]);
        return ANG_STATUS_FAILED;
    }

    //3. 发送数据包
    ANG_LOGI("Start to send data packet");
    uint64_t nFileSize;
    int UploadFile;
    nRetVal = angOSGetFileSize64(upgradeFile.c_str(), &nFileSize);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angHostProtocolFileUpload angOSGetFileSize64 failed, ret :%d, file:%s", nRetVal,upgradeFile.c_str());
        return ANG_STATUS_FAILED;
    }
    nRetVal = angOSOpenFile(upgradeFile.c_str(), ANG_OS_FILE_READ, &UploadFile);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angHostProtocolFileUpload angOSOpenFile failed, ret :%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    uint32_t nNextOffset = 0;
    ANG_PACKET_NO = 1;
    ANG_RETRY_COUNT = 3;
    uint8_t tempNO = 1;

    while (nNextOffset < nFileSize) {
        nRetVal = angHostProtocolWriteUpload(UploadFile, nNextOffset, (uint32_t) nFileSize,
                                             nNextOffset, ANG_PACKET_NO);
        // 表示这一升级包模组已收到
        if (tempNO < ANG_PACKET_NO || (tempNO == 255 && ANG_PACKET_NO == 0)) {
            tempNO = ANG_PACKET_NO;
            ANG_RETRY_COUNT = 3;
        } else {
            ANG_LOGE("tempNO=%d, ANG_PACKET_NO=%d", tempNO, ANG_PACKET_NO);
            ANG_RETRY_COUNT--;
        }
        // 同一包发送失败三次，不再尝试发送，升级失败
        if (ANG_RETRY_COUNT == 0) {
            ANG_LOGE("The upgrade packet was sent 3 times and failed, ret :%d", nRetVal);
            angOSCloseFile(&UploadFile);
            return ANG_STATUS_FAILED;
        }
    }
    angOSCloseFile(&UploadFile);
    ANG_LOGI("Uploaded %llu bytes done", nFileSize);

    //4. 发送升级结束包
    ANG_LOGI("End to send data packet");
    u_char finalCmd[1] = {0x04};
    nRetVal = angHostProtocolUSBSend(finalCmd, 1, 1000);
    if (nRetVal != ANG_STATUS_SUCCESS) {
        ANG_LOGE("Start upgrading files failed, rc:%d", nRetVal);
        return ANG_STATUS_FAILED;
    }
    ANG_LOGI("AngDeviceUpgradeFirmware end");
    return ANG_STATUS_SUCCESS;
}

std::string UsbMcuDev::getMcuVersion() {
    std::string cmd = "ARG READ:V=";
    int length = cmd.length();
    size_t len = 64;
    char *buffer = static_cast<char *>(malloc(len));
    memset(buffer, 0, len);
    memcpy(buffer, cmd.c_str(), length);
    int ret = communicateWithDevice(&buffer, length);
    std::string readDataOk = "READ OK";
    std::string readData = buffer;
    if (readData.find(readDataOk) != std::string::npos) {
        char *ver = buffer + 8;
        std::string pS(ver);
        ANG_LOGI("getMcuVersion:%s", ver);
        free(buffer);
        return pS;
    }
    free(buffer);
    return "none";
}

std::string UsbMcuDev::getHiMaxVersion() {
    std::string cmd = "ARG READ:HF=";
    int length = cmd.length();
    size_t len = 64;
    char *buffer = static_cast<char *>(malloc(len));
    memset(buffer, 0, len);
    memcpy(buffer, cmd.c_str(), length);
    int ret = communicateWithDevice(&buffer, length);
    std::string readDataOk = "READ OK";
    std::string readData = buffer;
    if (readData.find(readDataOk) != std::string::npos) {
        char *ver = buffer + 8;
        std::string pS(ver);
        ANG_LOGI("getMcuVersion:%s", ver);
        free(buffer);
        return pS;
    }
    free(buffer);
    return "none";
}

int UsbMcuDev::enterMcuLoaderMode() {
    ANG_LOGI("enterMcuLoaderMode");
    std::string value = "ARG WRITE:I=1";
    char *value_c = static_cast<char *>(malloc(32));
    memset(value_c, 0, 32);
    int len = value.size();
    memcpy(value_c, value.c_str(), value.size());
    communicateWithDevice(&value_c, len);
    std::string result = value_c;
    ANG_LOGI("ARG WRITE result: %s", result.c_str());
    if (result.find("iap_boot") != std::string::npos) {
        free(value_c);
        return ANG_STATUS_SUCCESS;
    } else {
        free(value_c);
        return ANG_STATUS_FAILED;
    }
}

int UsbMcuDev::upgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath) {
    getMcuVersion();
    Mutex::Autolock _l(ang_mutex_);
    int rc = ANG_STATUS_SUCCESS;
    ANG_LOGI("upgradeMcuDevice:%s", upgradeFilePath.c_str());
    //1.如果有升级失败的设备(vid:pid=4348:55e0),先升级
    auto deviceDescriptors = mcu_descriptor_->getUsbDeviceDescriptors();
    int num = 0;
    for (auto &dev : *deviceDescriptors) {
        if (checkBurnModeDev(dev->getAngDevInfo()->usb.uid))
            num++;
    }
    ANG_LOGI("checkBurnModeDev num:%d", num);
    for (int i = 0; i < num; i++) {
        //1. 动态加载MCU升级驱动
        rc = insmodMCUDriver(mcuDriverPath.c_str());
        if (rc == ANG_STATUS_FAILED) {
            ANG_LOGE("insmodMCUDriver failed");
            rmmodMCUDriver();
            return STATUS_FAILED_INSMOD_MCU_DRIVER;
        }
        rc = doMCUDownLoad(const_cast<char *>(upgradeFilePath.c_str()));
        ANG_LOGI("checkIfunUpgradeDev doMCUDownLoad rc:%d", rc);
        rmmodMCUDriver();
    }

    //2.进入升级模式
    rc = enterMcuLoaderMode();
    sleep(1);

    //3.判断升级方法
    //由于MCU进入升级模式会改变vid和pid，因此需要重新更新mcu_descriptor_
    mcu_descriptor_->parseDescriptor(nullptr);

    bool burnMode_new = false;

    auto descriptors = mcu_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *descriptors) {
        if (getDevBurnMode(dev->getAngDevInfo()->usb.uid) == BURN_TYPE_BROKEN_BOOT_NEW) {
            mcu_dev_info_ = dev->getAngDevInfo();
            mcu_uid_ = mcu_dev_info_->usb.uid;
            burnMode_new = true;
            break;
        }
    }

    //4.进入升级
    if (burnMode_new == true) { //使用新的升级方式
        rc = doUpgradeMcuDevice_new(upgradeFilePath);
    } else { // 使用旧的升级方式
        //(1). 动态加载MCU升级驱动
        rc = insmodMCUDriver(mcuDriverPath.c_str());
        if (rc == ANG_STATUS_FAILED) {
            ANG_LOGE("insmodMCUDriver failed");
            return STATUS_FAILED_INSMOD_MCU_DRIVER;
        }
        //(2). 升级
        rc = doMCUDownLoad(const_cast<char *>(upgradeFilePath.c_str()));
        if (rc == ANG_STATUS_FAILED) {
            ANG_LOGE("doMCUDownLoad failed, rc:%d", rc);
            sleep(1);
            rc = doMCUDownLoad(const_cast<char *>(upgradeFilePath.c_str()));
            if (rc == ANG_STATUS_FAILED) {
                ANG_LOGE("doMCUDownLoad failed again, rc:%d", rc);
                rmmodMCUDriver();
                return rc;
            }
        }
        //(3). 动态卸载MCU升级驱动
        rmmodMCUDriver();
        //升级完成后MCU设备会重启，延时2s确保MCU设备启动成功
        if (ANG_STATUS_SUCCESS == rc) sleep(2);
    }

    //升级完后再次更新mcu_descriptor_
    mcu_descriptor_->parseDescriptor(nullptr);
    auto descriptors2 = mcu_descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *descriptors2) {
        if (dev->getAngDevInfo()->usb.devpath == mcu_dev_info_->usb.devpath) {
            mcu_dev_info_ = dev->getAngDevInfo();
            mcu_uid_ = mcu_dev_info_->usb.uid;
            break;
        }
    }

    ANG_LOGI("====>upgradeMcuDevice, rc:%d", rc);
    return rc;
}

int UsbMcuDev::setInsideOutsideParam() {
    std::string cmd = "ARG READ:PA=";
    int length = cmd.length();
    std::string readDataOk = "READ OK";
    size_t bufferLength = 1024;
    char *comBuffer = (char *) malloc(bufferLength);
    memset(comBuffer, 0, bufferLength);
    memcpy(comBuffer, cmd.c_str(), length);
    int ret = communicateWithDevice(&comBuffer, length);
    if (ret != 0) {
        ANG_LOGE("setInsideOutsideParam fail,rc:%d", ret);
        free(comBuffer);
    } else {
        ANG_LOGI("setInsideOutsideParam success");
        char *cali = (comBuffer + 8);
        uint32_t fxirshi = str2hex(&cali[0]) * 16;
        uint32_t fxirge = str2hex(&cali[1]) * 1;
        uint32_t fxirqian = str2hex(&cali[3]) * 16 * 16 * 16;
        uint32_t fxirbai = str2hex(&cali[4]) * 16 * 16;
        uint32_t fxir = fxirshi + fxirge + fxirqian + fxirbai;

        uint32_t cxirshi = str2hex(&cali[6]) * 16;
        uint32_t cxirge = str2hex(&cali[7]) * 1;
        uint32_t cxirqian = str2hex(&cali[9]) * 16 * 16 * 16;
        uint32_t cxirbai = str2hex(&cali[10]) * 16 * 16;
        uint32_t cxir = cxirshi + cxirge + cxirqian + cxirbai;

        uint32_t fyirshi = str2hex(&cali[12]) * 16;
        uint32_t fyirge = str2hex(&cali[13]) * 1;
        uint32_t fyirqian = str2hex(&cali[15]) * 16 * 16 * 16;
        uint32_t fyirbai = str2hex(&cali[16]) * 16 * 16;
        uint32_t fyir = fyirshi + fyirge + fyirqian + fyirbai;

        uint32_t cyirshi = str2hex(&cali[18]) * 16;
        uint32_t cyirge = str2hex(&cali[19]) * 1;
        uint32_t cyirqian = str2hex(&cali[21]) * 16 * 16 * 16;
        uint32_t cyirbai = str2hex(&cali[22]) * 16 * 16;
        uint32_t cyir = cyirshi + cyirge + cyirqian + cyirbai;

        //添加内外参解析存值
        if (fxir > 100 && fxir < 1000){ // Nuwa
            gParams.push_back(fxir);
            gParams.push_back(fyir);
            gParams.push_back(cxir);
            gParams.push_back(cyir);
            ANG_LOGI("[getParams] %d, %d, %d, %d", fxir, fyir, cxir, cyir);
        } else if(isX100(mcu_dev_info_->usb.pid)){   //x100
            gParams.push_back(265);
            gParams.push_back(265);
            gParams.push_back(320);
            gParams.push_back(270);
            ANG_LOGI("[getParams] x100 default");
        } else if(isHP60_73(mcu_dev_info_->usb.pid)){ //hp60-73, hp60c
            gParams.push_back(425);
            gParams.push_back(425);
            gParams.push_back(320);
            gParams.push_back(270);
            ANG_LOGI("[getParams] hp60-73 default");
        } else if(isHP60_58(mcu_dev_info_->usb.pid)){ //hp60-58
            gParams.push_back(850);
            gParams.push_back(850);
            gParams.push_back(480);
            gParams.push_back(640);
            ANG_LOGI("[getParams] hp60-58 default");
        } else {                       //xb40
            gParams.push_back(850);
            gParams.push_back(850);
            gParams.push_back(640);
            gParams.push_back(400);
            ANG_LOGI("[getParams] xb40 default");
        }
        free(comBuffer);
    }
    return ANG_STATUS_SUCCESS;
}