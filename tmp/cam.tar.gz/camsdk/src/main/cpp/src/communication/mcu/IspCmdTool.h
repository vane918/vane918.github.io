//
// Created by Angstrong on 2022/8/10.
//

#ifndef ANGSTRONGSDKLIB_ISPCMDTOOL_H
#define ANGSTRONGSDKLIB_ISPCMDTOOL_H

int startMcuUpgrade(char *mcuFile);

#endif //ANGSTRONGSDKLIB_ISPCMDTOOL_H