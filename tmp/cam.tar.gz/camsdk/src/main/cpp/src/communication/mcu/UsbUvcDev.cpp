/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "UsbUvcDev.h"
#include "libusbSonixCamera.h"

using namespace ang;

UsbUvcDev::UsbUvcDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid) :
        UsbDevBase(descriptor, uid) {
}

UsbUvcDev::~UsbUvcDev() {
}

int UsbUvcDev::openUvcDevice(int fd) {
    return UsbDevBase::openDevice(fd);
}

int UsbUvcDev::closeUvcDevice() {
    return UsbDevBase::closeDevice();
}

int UsbUvcDev::ispUpgrade(std::string mcuPid, char *upgradeFilePath, usb_isp_upgrade_process_fn callback) {
    ANG_LOGI("ispUpgrade");
    int rc = ANG_STATUS_SUCCESS;
    FILE *fileHandle;
    if (!(fileHandle = fopen(upgradeFilePath, "rb"))) {
        ANG_LOGE("open isp file fail");
        return ANG_STATUS_FAILED;
    }
    struct stat fileInfo{};
    stat(upgradeFilePath, &fileInfo);
    auto *pFW = (uint8_t *)(malloc(fileInfo.st_size + 1));
    ANG_LOGI("fileInfo.st_size = %d", (uint32_t) fileInfo.st_size);
    fread(pFW, 1, fileInfo.st_size, fileHandle);
    fclose(fileHandle);

    libusb_SERIAL_FLASH_TYPE sft;

    if (isHP60(mcuPid)) {
        sft = libusb_SFT_FENTECH;
    } else {
        rc = libusb_SonixCam_GetSerialFlashType(usb_devh, &sft, libusb_true);
        ANG_LOGI("libusb_SonixCam_GetSerialFlashType:%d", sft);
        if (!rc) {
            ANG_LOGE("libusb_SonixCam_GetSerialFlashType failed");
            free(pFW);
            return ANG_STATUS_FAILED;
        }
    }
    ANG_LOGI("start to isp upgrade, please wait...");
    rc = libusb_SonixCam_BurnerFW(usb_devh, pFW, fileInfo.st_size,
                                  (libusb_SonixCam_SetProgress)(callback), this, sft, libusb_TRUE);

    if (rc) {
        ANG_LOGI("burner fw success!");
        libusb_SonixCam_RestartDevice(usb_devh);
        sleep(10);
        rc = ANG_STATUS_FAILED;
    } else {
        ANG_LOGE("burner fw fail!");
        rc = ANG_STATUS_FAILED;
    }
    free(pFW);
    pFW = nullptr;
    return rc;
}