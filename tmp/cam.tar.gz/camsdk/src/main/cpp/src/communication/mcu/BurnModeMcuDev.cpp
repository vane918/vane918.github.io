/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "BurnModeMcuDev.h"

using namespace ang;

BurnModeMcuDev::BurnModeMcuDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid, AngBurnType burn_type) :
        McuDevBase(descriptor, uid, burn_type),
        UsbDevBase(descriptor, uid){
}

BurnModeMcuDev::~BurnModeMcuDev() {
}

int BurnModeMcuDev::upgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath){
    ANG_LOGI("BurnModeMcuDev upgradeMcuDevice");
    int rc = ANG_STATUS_SUCCESS;
    Mutex::Autolock _l(ang_mutex_);
    ANG_LOGI("upgradeMcuDevice:%s", upgradeFilePath.c_str());

    //使用新的升级方式
    if (burn_type_ == BURN_TYPE_BROKEN_BOOT_NEW) {
        rc = doUpgradeMcuDevice_new(upgradeFilePath);
    } else { // 使用旧的升级方式
        rc = doUpgradeMcuDevice(upgradeFilePath, mcuDriverPath);
    }

    ANG_LOGI("====>upgradeMcuDevice, rc:%d", rc);
    return rc;
}