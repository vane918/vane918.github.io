/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "UsbDevBase.h"

using namespace ang;

//MCU升级
static const int MAX_UPGRADE_MCU_PACKET_SIZE = 64;
static const int MCU_MAX_FILE_SIZE = 512 * 1024; //最大长度512K

/*以下为IAP下载命令定义*/
static const int CMD_IAP_PROM = 0x80;// ISP编程命令
static const int CMD_IAP_ERASE = 0x81;// ISP擦除命令
static const int CMD_IAP_VERIFY = 0x82;// ISP校验命令
static const int CMD_IAP_END = 0x83;// ISP结束标志
static const int CMD_IAP_SUCCESS = 0x84;// ISP success flag
static const int CMD_IAP_RUNAPP = 0x85;// 运行app程序

int UsbDevBase::openDevice(int fd) {
    ANG_LOGI("openDevice fd: %d", fd);
    int rc = ANG_STATUS_SUCCESS;
    unsigned short nVendorID = 0;
    unsigned short nProductID = 0;
    unsigned char nBus = 0;
    unsigned char nAddress = 0;

    sscanf(ang_dev_info_->usb.vid.c_str(), "%hx", &nVendorID);
    sscanf(ang_dev_info_->usb.pid.c_str(), "%hx", &nProductID);
    sscanf(ang_dev_info_->usb.bus.c_str(), "%hhu", &nBus);
    sscanf(ang_dev_info_->usb.dev.c_str(), "%hhu", &nAddress);
    ANG_LOGI("openDevice %x,%x,%d,%d", nVendorID, nProductID, nBus, nAddress);

    if (fd > 0) {
#ifdef _USE_MAIN_LIBUVC_AND_LIBUSB
        // 4是debug级别, 3是info级别
        rc = libusb_set_option(NULL, LIBUSB_OPTION_LOG_LEVEL, 3);
        rc = libusb_set_option(NULL, LIBUSB_OPTION_NO_DEVICE_DISCOVERY, NULL);
        if (rc != LIBUSB_SUCCESS) {
            ANG_LOGI("libusb_set_option failed: %d", rc);
            return -1;
        }
        rc = libusb_init(&gContext);
        if (rc != 0) {
            ANG_LOGI("libusb_init failed:%d, errno:%d", rc, errno);
            return ANG_STATUS_FAILED;
        }
        rc = libusb_wrap_sys_device(gContext, (intptr_t) fd, &usb_devh);
        if (rc < 0) {
            ANG_LOGE("libusb_wrap_sys_device failed: %d", rc);
            return rc;
        } else if (usb_devh == NULL) {
            ANG_LOGE("libusb_wrap_sys_device returned invalid handle");
            return rc;
        }
        usb_dev = usb_devh->dev;
#else
        rc = libusb_init2(&gContext, std::to_string(fd).c_str());
        if (rc != 0) {
            ANG_LOGI("libusb_init2 failed:%d, errno:%d", rc, errno);
            return ANG_STATUS_FAILED;
        }
        usb_dev = libusb_get_device_with_fd(gContext, nVendorID, nProductID,
                                                       nullptr, fd, nBus, nAddress);
        rc = libusb_set_device_fd(usb_dev, fd);
        rc = libusb_open(usb_dev, &usb_devh);
#endif
        ANG_LOGI("libusb_open usb_dev:%p, usb_devh:%p, gContext:%p", usb_dev, usb_devh, gContext);
    } else {
        rc = libusb_init(&gContext);
        if (rc != 0) {
            ANG_LOGI("libusb_init failed:%d, errno:%d", rc, errno);
            return ANG_STATUS_FAILED;
        }
        if (nVendorID == 0 || nProductID == 0 || nBus == 0 || nAddress == 0) {
            ANG_LOGE("Invalid connection gVid: %s, gPid: %s", ang_dev_info_->usb.vid.c_str(),
                     ang_dev_info_->usb.pid.c_str());
            return ANG_STATUS_FAILED;
        }

        libusb_device **devs;
        ssize_t cnt;
        cnt = libusb_get_device_list(gContext, &devs);
        if (cnt < 0) {
            ANG_LOGE("failed to libusb_get_device_list");
            return ANG_STATUS_FAILED;
        }

        libusb_device *dev;
        int i = 0;
        while ((dev = devs[i++]) != NULL) {
            struct libusb_device_descriptor desc;
            int r = libusb_get_device_descriptor(dev, &desc);
            if (r < 0) {
                ANG_LOGE("failed to get device descriptor");
                return ANG_STATUS_FAILED;
            }
            if (desc.idVendor == nVendorID && desc.idProduct == nProductID &&
                    libusb_get_bus_number(dev) == nBus && libusb_get_device_address(dev) == nAddress) {
                usb_dev = dev;
                break;
            }
        }
        libusb_free_device_list(devs, 1);

        if (!usb_dev) {
            ANG_LOGE("failed to get usb_dev");
            return ANG_STATUS_FAILED;
        }

        rc = libusb_open(usb_dev, &usb_devh);
    }

    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGI("libusb_open failed, rc:%d", rc);
    }

    rc = libusb_set_auto_detach_kernel_driver(usb_devh, 1);
    ANG_LOGI("auto_detach rc:%d", rc);

    rc = libusb_claim_interface(usb_devh, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGI("claim_interface failed, rc:%d", rc);
        libusb_close(usb_devh);
        return rc;
    }

    //ISP设备升级不需要打开端点，调用松瀚的so进行升级操作
    if (!checkAngMcuDev(ang_dev_info_->usb.uid)) {
        return ANG_STATUS_SUCCESS;
    }

    rc = openEndPoint(endpoint_id_in_, USB_EP_BULK, USB_DIRECTION_IN, pEPInHandle);
    ANG_LOGI("openEndPoint pEPInHandle:%p", pEPInHandle);
    if (rc != 0) {
        closeDevice();
    }
    rc = openEndPoint(endpoint_id_out_, USB_EP_BULK, USB_DIRECTION_OUT, pEPOutHandle);
    ANG_LOGI("openEndPoint pEPOutHandle:%p", pEPOutHandle);
    if (rc != 0) {
        closeDevice();
        closeEndPoint(pEPInHandle);
    }

    return rc;
}

int UsbDevBase::closeDevice() {
    ANG_LOGI("closeDevice");
    if (usb_devh == NULL) {
        ANG_LOGI("usb_devh is NULL");
        return ANG_STATUS_SUCCESS;
    }

    if (pEPInHandle)
        closeEndPoint(pEPInHandle);

    if (pEPOutHandle)
        closeEndPoint(pEPOutHandle);

    int rc = libusb_release_interface(usb_devh, 0);
    ANG_LOGI("libusb_release_interface:%d", rc);

    libusb_close(usb_devh);

    ANG_LOGI("libusb_close end");

#ifndef _USE_MAIN_LIBUVC_AND_LIBUSB
    libusb_set_device_fd(usb_dev, 0);
#endif

    //注释该行可能会内存泄漏，不注释的话saki版本的so会卡在libusb_exit
//    if (usb_dev) {
//        libusb_unref_device(usb_dev);
//    }

    libusb_exit(gContext);
    ANG_LOGI("libusb_exit end");
    usb_dev = NULL;
    usb_devh = NULL;
    gContext = NULL;
    return ANG_STATUS_SUCCESS;
}

int UsbDevBase::openEndPoint(int nEndPointID, USBEndPointType nEPType,
                             USBDirectionType nDirType, USB_EP_HANDLE &pEPHandlePtr) {
    ANG_LOGI("openEndPoint endPointID:%x", nEndPointID);
    libusb_config_descriptor *pConfig;
    int rc = libusb_get_config_descriptor(usb_devh->dev, 0, &pConfig);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("get_config_descriptor failed:%d", rc);
        return rc;
    }

    const libusb_interface *pInterface = &pConfig->interface[0];
    const libusb_interface_descriptor *pInterfaceDesc = &pInterface->altsetting[0];
    const libusb_endpoint_descriptor *pEndpointDesc = NULL;
    for (uint8_t i = 0; i < pInterfaceDesc->bNumEndpoints; ++i) {
        ANG_LOGI("bEndpointAddress: 0x%x,wMaxPacketSize: 0x%x",
                 pInterfaceDesc->endpoint[i].bEndpointAddress,
                 pInterfaceDesc->endpoint[i].wMaxPacketSize);
        if (pInterfaceDesc->endpoint[i].bEndpointAddress == nEndPointID) {
            pEndpointDesc = &pInterfaceDesc->endpoint[i];
            break;
        }
    }
    if (pEndpointDesc == NULL) {
        libusb_free_config_descriptor(pConfig);
        ANG_LOGE("USB_ENDPOINT_NOT_FOUND");
        return ANG_STATUS_FAILED;
    }
    ANG_LOGI("pEndpointDesc:%p", pEndpointDesc);
    libusb_transfer_type transfer_type = (libusb_transfer_type) (pEndpointDesc->bmAttributes &
                                                                 0x3); // lower 2-bits
    unsigned int nMaxPacketSize = 0;
    nMaxPacketSize = pEndpointDesc->wMaxPacketSize;
    libusb_free_config_descriptor(pConfig);
    pConfig = NULL;
    ANG_LOGI("nMaxPacketSize:%d", nMaxPacketSize);
    if (nEPType == USB_EP_BULK) {
        if (transfer_type != LIBUSB_TRANSFER_TYPE_BULK) {
            ANG_LOGE("STATUS_USB_WRONG_ENDPOINT_TYPE");
            return ANG_STATUS_FAILED;
        }
    } else {
        ANG_LOGE("STATUS_USB_UNKNOWN_ENDPOINT_TYPE");
        return ANG_STATUS_FAILED;
    }

    libusb_endpoint_direction direction = (libusb_endpoint_direction) (nEndPointID &
                                                                       0x80); // 8th bit
    if (nDirType == USB_DIRECTION_IN) {
        if (direction != LIBUSB_ENDPOINT_IN) {
            ANG_LOGE("STATUS_USB_WRONG_ENDPOINT_DIRECTION4");
            return ANG_STATUS_FAILED;
        }
    } else if (nDirType == USB_DIRECTION_OUT) {
        if (direction != LIBUSB_ENDPOINT_OUT) {
            ANG_LOGE("STATUS_USB_WRONG_ENDPOINT_DIRECTION");
            return ANG_STATUS_FAILED;
        }
    } else {
        ANG_LOGE("STATUS_USB_UNKNOWN_ENDPOINT_DIRECTION");
        return ANG_STATUS_FAILED;
    }
    // allocate handle
    USB_EP_HANDLE epHandle = static_cast<USB_EP_HANDLE>(malloc(sizeof(USBEPHandle)));
    pEPHandlePtr = epHandle;
    epHandle->nAddress = nEndPointID;
    epHandle->nType = nEPType;
    epHandle->nDirection = nDirType;
    epHandle->nMaxPacketSize = nMaxPacketSize;
    return ANG_STATUS_SUCCESS;
}

int UsbDevBase::closeEndPoint(USB_EP_HANDLE &pEPHandle) {
    ANG_LOGI("closeEndPoint pEPHandle:%p", pEPHandle);
    free(pEPHandle);
    pEPHandle = NULL;
    return ANG_STATUS_SUCCESS;
}

int UsbDevBase::angHostProtocolUSBSend(u_char *pBuffer, uint32_t nBufferSize, uint32_t nTimeOut) {
    if (!pEPOutHandle) {
        ANG_LOGE("angHostProtocolUSBSend failed, pEPOutHandle is null");
        return ANG_STATUS_FAILED;
    }
    int nRetVal = ANG_STATUS_SUCCESS;
    uint32_t nCounter = ANG_USB_HOST_PROTOCOL_SEND_RETRIES;
    while (nCounter-- != 0) {
        nRetVal = angUSBWriteEndPoint(pEPOutHandle, pBuffer, nBufferSize, nTimeOut);
        if (nRetVal != ANG_STATUS_USB_TRANSFER_TIMEOUT && nRetVal != ANG_STATUS_USB_TRANSFER_STALL)
            break;

        usleep(100 * 1000);
    }
    return nRetVal;
}

int UsbDevBase::angHostProtocolUSBReceive(u_char *pBuffer, uint32_t nBufferSize,
                                          uint32_t *pnBytesReceived, uint32_t nTimeOut) {
    if (!pEPInHandle) {
        ANG_LOGE("angHostProtocolUSBReceive failed, pEPInHandle is null");
        return ANG_STATUS_FAILED;
    }
    return angUSBReadEndPoint(pEPInHandle, pBuffer, nBufferSize, pnBytesReceived, nTimeOut);
}

int UsbDevBase::angUSBWriteEndPoint(USB_EP_HANDLE pEPHandle, u_char *pBuffer, uint32_t nBufferSize,
                                    uint32_t nTimeOut) {

    if (pEPHandle->nDirection != USB_DIRECTION_OUT) {
        ANG_LOGE("angUSBWriteEndPoint pEPHandle->nDirection != USB_DIRECTION_OUT");
        return ANG_STATUS_FAILED;
    }

    if (nBufferSize == 0) {
        return ANG_STATUS_FAILED;
    }

// send (according to EP type)
    int nBytesSent = 0;
    int rc = 0;

    if (pEPHandle->nType == USB_EP_BULK) {
        rc = libusb_bulk_transfer(usb_devh, pEPHandle->nAddress, pBuffer, nBufferSize, &nBytesSent,
                                  nTimeOut);
        if (rc != 0) {
            ANG_LOGE("libusb_bulk_transfer failed, rc:%d", rc);
        }
    } else {
        ANG_LOGE("angUSBWriteEndPoint pEPHandle->nType not USB_EP_BULK");
        return ANG_STATUS_FAILED;
    }

// check result
    if (rc == LIBUSB_ERROR_TIMEOUT) {
        return ANG_STATUS_USB_TRANSFER_TIMEOUT;
    } else if (rc != 0) {
        return ANG_STATUS_FAILED;
    }

    if ((uint32_t) nBytesSent != nBufferSize) {
        return ANG_STATUS_USB_GOT_UNEXPECTED_BYTES;
    }

    return ANG_STATUS_SUCCESS;
}

int UsbDevBase::angUSBReadEndPoint(USB_EP_HANDLE pEPHandle, u_char *pBuffer, uint32_t nBufferSize,
                                   uint32_t *pnBytesReceived, uint32_t nTimeOut) {
    if (pEPHandle->nDirection != USB_DIRECTION_IN) {
        return ANG_STATUS_FAILED;
    }

    if (nBufferSize == 0) {
        return ANG_STATUS_FAILED;
    }

    // receive (according to EP type)
    *pnBytesReceived = 0;

    int nBytesReceived = 0;
    int rc = 0;

    if (pEPHandle->nType == USB_EP_BULK) {
        rc = libusb_bulk_transfer(usb_devh, pEPHandle->nAddress, pBuffer, nBufferSize,
                                  &nBytesReceived, nTimeOut);
    } else {
        return ANG_STATUS_FAILED;
    }

    // check result
    if (rc == LIBUSB_ERROR_TIMEOUT) {
        return ANG_STATUS_USB_TRANSFER_TIMEOUT;
    } else if (rc != 0) {
        return ANG_STATUS_FAILED;
    }

    if (nBytesReceived == 0) {
        return ANG_STATUS_USB_NOT_ENOUGH_DATA;
    }

    *pnBytesReceived = nBytesReceived;
    return ANG_STATUS_SUCCESS;
}

static uint8_t PACKET_NO = 1;   // 数据包序号
static uint8_t RETRY_COUNT = 3; // 产生发送SE数据包的次数
int UsbDevBase::angHostProtocolWriteUpload(int &FileToUpload, uint32_t nOffset,
                                           uint32_t nFileSize, uint32_t &nNextOffset,
                                           uint8_t &packetNo) {
    uint32_t nExtraSize = 4;
    uint32_t nChunkSize = MAX_UPGRADE_PACKET_SIZE - nExtraSize;
    //Hsj: Fix upgrade failed after upgrade failed at last
    if (packetNo == 1) PACKET_NO = 1;

    //最后一包不满最大发送包大小的情况
    if (nFileSize - nOffset < nChunkSize) {
        nChunkSize = nFileSize - nOffset;
    } else {
        nChunkSize = MAX_UPGRADE_PACKET_SIZE - nExtraSize;
    }

    uint32_t nBufferSize = nChunkSize + nExtraSize;

    //1字节02 + 1字节包序号 + 1字节包序号的按位取反 + 最后一字节是校验和
    u_char buffer[MAX_UPGRADE_PACKET_SIZE] = {0};
    u_int8_t checkSum = 0;

    //升级包第一个字节是0x02
    buffer[0] = 0x02;
    //升级包第二个字节是包序号
    buffer[1] = PACKET_NO;
    //升级包第二个字节是包序号的按位取反
    buffer[2] = ~PACKET_NO;
    int rc = angOSSeekFile64(FileToUpload, ANG_OS_SEEK_SET, nNextOffset);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angOSSeekFile fail");
        return rc;
    }
    rc = angOSReadFile(FileToUpload, buffer + 3, &nChunkSize);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angOSReadFile fail");
        return rc;
    }

    // 有效数据校验和
    for (int i = 3; i < nBufferSize - 1; i++) {
        checkSum = checkSum + buffer[i];
    }
    buffer[nBufferSize - 1] = checkSum;

    u_char *pDataBuf = (u_char *) malloc(sizeof(u_char) * nBufferSize);
    memcpy(pDataBuf, buffer, nBufferSize);

    rc = angHostProtocolUSBSend(pDataBuf, nBufferSize, 1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("send the upgrade ending package failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }
    u_char receiveBuf[8];
    uint32_t pnBytesReceived = 0;
    memset(receiveBuf, 0, 8);
    pnBytesReceived = 0;
    rc = angHostProtocolUSBReceive(receiveBuf, 8, &pnBytesReceived, 1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("send the upgrade ending package failed2, rc:%d", rc);
        free(pDataBuf);
        return ANG_STATUS_FAILED;
    }
    if (receiveBuf[0] != 0x06) {
        ANG_LOGE("send the upgrade ending package failed, receiveBuf[0]:%x", receiveBuf[0]);
        free(pDataBuf);
        return ANG_STATUS_FAILED;
    }
    free(pDataBuf);
    nNextOffset = nNextOffset + nChunkSize;
    PACKET_NO++;
    packetNo = PACKET_NO;
    return ANG_STATUS_SUCCESS;
}

static uint8_t PACKET_NO2 = 1;   // 数据包序号
static uint8_t RETRY_COUNT2 = 3; // 产生发送SE数据包的次数
int UsbDevBase::angMcuUpload(u_char *dataBuffer, uint32_t nOffset,
                             uint32_t nFileSize, uint32_t &nNextOffset, uint32_t type) {
    int rc = ANG_STATUS_SUCCESS;
    uint32_t nExtraSize = 4;
    uint32_t nChunkSize = MAX_UPGRADE_MCU_PACKET_SIZE - nExtraSize;

    //最后一包不满最大发送包大小的情况
    if (nFileSize - nOffset < nChunkSize) {
        nChunkSize = nFileSize - nOffset;
    } else {
        nChunkSize = MAX_UPGRADE_MCU_PACKET_SIZE - nExtraSize;
    }

    uint32_t nBufferSize = nChunkSize + nExtraSize;

    //CMD_IAP_PROM + 1字节数据长度 + 2字节数据地址 + 后续数据.注意此命令发下来的数据个数必须为4字节的整数倍
    u_char buffer[MAX_UPGRADE_MCU_PACKET_SIZE] = {0};
    uint8_t checkSum = 0;

    //从缓冲区拷贝升级文件数据到临时buffer中
    memcpy(&buffer[4], &dataBuffer[nNextOffset], nChunkSize);

    //CMD_IAP_PROM or CMD_IAP_VERIFY
    buffer[0] = type;
    //1字节数据长度
    buffer[1] = nChunkSize;
    //2字节数据地址
    SHORT_TO_SW(nNextOffset, &buffer[2]);

    u_char *pDataBuf = (u_char *) malloc(sizeof(u_char) * nBufferSize);
    memcpy(pDataBuf, buffer, nBufferSize);

    rc = angHostProtocolUSBSend(pDataBuf, nBufferSize, 1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("send the upgrade ending package failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }
    u_char receiveBuf[2];
    uint32_t pnBytesReceived = 0;
    memset(receiveBuf, 0, 2);
    pnBytesReceived = 0;
    rc = angHostProtocolUSBReceive(receiveBuf, 2, &pnBytesReceived, 1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("send the upgrade ending package failed2, rc:%d", rc);
        free(pDataBuf);
        return ANG_STATUS_FAILED;
    }
    int16_t result = SW_TO_SHORT(receiveBuf);
    if (result != 0x00) {
        ANG_LOGE("send the upgrade mcu package failed, result:%x", result);
        free(pDataBuf);
        return ANG_STATUS_FAILED;
    }
    free(pDataBuf);
    nNextOffset = nNextOffset + nChunkSize;
    return ANG_STATUS_SUCCESS;
}

int UsbDevBase::doUpgradeMcuDevice_new(const std::string &upgradeFilePath) {
    ANG_LOGI("upgradeMcuDevice use new way");
    int rc = ANG_STATUS_SUCCESS;
    //释放之前正常的MCU设备资源
    closeDevice();

    chmodPermission();

    //TODO fd由Java层传下来
    rc = UsbDevBase::openDevice(0);
    if (rc == ANG_STATUS_FAILED) {
        ANG_LOGE("upgradeMcuDevice openDevice failed :%d", rc);
        return ANG_STATUS_FAILED;
    }

    //1.擦除FLASH
    uint32_t len = 8;
    u_char value[len];
    memset(value, 0, len);
    value[0] = CMD_IAP_ERASE;
    value[1] = 0x04;
    SHORT_TO_SW(0X00, &value[2]);

    rc = angHostProtocolUSBSend(value, len, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("erase send failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }

    uint32_t pnBytesReceived = 0;
    uint32_t pnBytesLen = 2;
    u_char receiveBuf[pnBytesLen];
    memset(receiveBuf, 0, pnBytesLen);
    rc = angHostProtocolUSBReceive(receiveBuf, pnBytesLen, &pnBytesReceived, 1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("erase receive failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }
    int16_t result = SW_TO_SHORT(receiveBuf);
    if (result != 0x00) {
        ANG_LOGE("erase receive failed, result:%d", result);
        return ANG_STATUS_FAILED;
    }
    ANG_LOGI(">>>>erase success<<<<");

    //2.写FLASH
    uint64_t nFileSize;
    int UploadFile;
    rc = angOSGetFileSize64(upgradeFilePath.c_str(), &nFileSize);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angOSGetFileSize64 failed, ret :%d, file:%s", rc, upgradeFilePath.c_str());
        return ANG_STATUS_FAILED;
    }
    rc = angOSOpenFile(upgradeFilePath.c_str(), ANG_OS_FILE_READ, &UploadFile);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angOSOpenFile failed, ret :%d", rc);
        return ANG_STATUS_FAILED;
    }

    //读取原始升级文件到缓冲区
    u_char *fileBuff = static_cast<u_char *>(malloc(MCU_MAX_FILE_SIZE));
    u_char *binBuff = static_cast<u_char *>(malloc(MCU_MAX_FILE_SIZE));
    memset(fileBuff, 0, MCU_MAX_FILE_SIZE);
    memset(binBuff, 0, MCU_MAX_FILE_SIZE);
    u_int64_t iBinLen = 0;
    rc = angOSReadFile(UploadFile, fileBuff, reinterpret_cast<uint32_t *>(&nFileSize));
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angOSReadFile fail");
    }

    angOSCloseFile(&UploadFile);

    bool isHex = true;
    //hex文件需要转为bin文件
    if (upgradeFilePath.find(".hex") != std::string::npos ||
        upgradeFilePath.find(".HEX") != std::string::npos) {
        isHex = false;
        bool isOk = hexToBin(fileBuff, nFileSize, binBuff, iBinLen);
        if (isOk == false) {
            ANG_LOGE("hexToBin fail");
            free(fileBuff);
            free(binBuff);
            return ANG_STATUS_FAILED;
        }
    }

    if (isHex == false) {
        memset(fileBuff, 0, MCU_MAX_FILE_SIZE);
        memcpy(fileBuff, binBuff, MCU_MAX_FILE_SIZE);
    } else {
        iBinLen = nFileSize;
    }

    ANG_LOGI("nFileSize:%llu, iBinLen:%llu", nFileSize, iBinLen);

    uint32_t nNextOffset = 0;

    ANG_LOGI("%x %x %x %x", fileBuff[0], fileBuff[1], fileBuff[2], fileBuff[3]);

    while (nNextOffset < iBinLen) {
        rc = angMcuUpload(fileBuff, nNextOffset, (uint32_t) iBinLen, nNextOffset, CMD_IAP_PROM);
        // 升级失败
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("angMcuUpload write flash failed, ret :%d", rc);
            free(fileBuff);
            free(binBuff);
            return ANG_STATUS_FAILED;
        }
    }

    ANG_LOGI(">>>>write flash %llu bytes done<<<<", iBinLen);

    //2.发送校验命令
    nNextOffset = 0;

    while (nNextOffset < iBinLen) {
        rc = angMcuUpload(fileBuff, nNextOffset, (uint32_t) iBinLen, nNextOffset, CMD_IAP_VERIFY);
        // 校验失败
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("angMcuUpload check flash failed, ret :%d", rc);
            free(fileBuff);
            free(binBuff);
            return ANG_STATUS_FAILED;
        }
    }
    ANG_LOGI(">>>>check data %llu bytes done<<<<", iBinLen);
    free(fileBuff);
    free(binBuff);

    //3.结束标志
    len = 4;
    memset(value, 0, len);
    value[0] = CMD_IAP_END;
    value[1] = 0x02;
    SHORT_TO_SW(0X00, &value[2]);

    rc = angHostProtocolUSBSend(value, len, 1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("end flag send failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }
    ANG_LOGI(">>>>end flag send success<<<<");

    //3.成功标志
    len = 3;
    memset(value, 0, len);
    value[0] = CMD_IAP_SUCCESS;
    value[1] = 0x01;
    value[2] = 0x01;

    rc = angHostProtocolUSBSend(value, len, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("success flag send failed, rc:%d", rc);

        return ANG_STATUS_FAILED;
    }
    pnBytesReceived = 0;
    pnBytesLen = 2;
    memset(receiveBuf, 0, pnBytesLen);
    rc = angHostProtocolUSBReceive(receiveBuf, pnBytesLen, &pnBytesReceived,
                                   1000);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("success flag receive failed, rc:%d", rc);
        return ANG_STATUS_FAILED;
    }
    result = SW_TO_SHORT(receiveBuf);
    if (result != 0x00) {
        ANG_LOGE("success flag failed, result:%d", result);
        return ANG_STATUS_FAILED;
    }
    ANG_LOGI(">>>>success flag success<<<<");
    //升级完成后MCU设备会重启，延时10s确保MCU设备启动成功
    sleep(10);
    return rc;
}
