/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "UartMcuDev.h"

using namespace ang;

UartMcuDev::UartMcuDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid, AngBurnType burn_type) :
        McuDevBase(descriptor, uid, burn_type) {

}

UartMcuDev::~UartMcuDev() {
    gParams.clear();
}

int UartMcuDev::upgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath){
    int rc = enterMcuLoaderMode();
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("UartMcuDev enterMcuLoaderMode failed");
        return ANG_STATUS_FAILED;
    }
    rc = doUpgradeMcuDevice(upgradeFilePath, mcuDriverPath);
    return rc;
}

int UartMcuDev::enterMcuLoaderMode() {
    std::vector<std::string> devs;
    findttyACMDev(devs);
    std::string ttyACM = getttyACMPath(devs, mcu_dev_info_->usb.devpath);
    ANG_LOGI("UartMcuDev enterMcuLoaderMode ttyACM:%s", ttyACM.c_str());

    if (access(ttyACM.c_str(), W_OK) != 0) {
        ANG_LOGE("%s has no write and read permission, sdk try to chmod", ttyACM.c_str());
        int ret = ang_system("su -c \"chmod 777 /dev/ttyACM*\"");
        if (ret != 0) {
            ANG_LOGE("ang_system failed");
            return ANG_STATUS_FAILED;
        }
    }

    std::ofstream output;
    output.open(ttyACM);
    std::string value = "ARG WRITE:I=1";
    output << value << std::endl;
    output.close();
    return ANG_STATUS_SUCCESS;
}

int UartMcuDev::setInsideOutsideParam() {
    auto *ps = (uint16_t *) (mcu_dev_info_->usb.product.c_str());
    float fxir = ps[0];
    float fyir = ps[1];
    float cyir = (ps[2] / 2.6f) * 2.0f;
    float cxir = (ps[2] - cyir / 2) * 2.0f;
    if (ANG_ABS(fxir - 850) > 5) fxir = 850;
    if (ANG_ABS(fyir - 850) > 5) fyir = 850;
    if (ANG_ABS(cxir - 640) > 5) cxir = 640;
    if (ANG_ABS(cyir - 400) > 5) cyir = 400;
    gParams.push_back(fxir);
    gParams.push_back(fyir);
    gParams.push_back(cxir);
    gParams.push_back(cyir);
    ANG_LOGI("setInsideOutsideParam: %x, %x, %x, %x,  [Intrinsic]fx: %f, fy: %f,cx: %f, cy: %f",
             ps[0], ps[1], ps[2], ps[3], fxir, fyir, cxir, cyir);
    return ANG_STATUS_SUCCESS;
}
