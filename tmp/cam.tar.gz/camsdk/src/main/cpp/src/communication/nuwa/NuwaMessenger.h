/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _NUWA_MESSENGER_H_
#define _NUWA_MESSENGER_H_

#include <string>
#include "Messenger.h"
#include "libusbi.h"
#include "AngThread.hpp"
#include "AngDevice.h"
#include "McuDevBase.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN


class NuwaMessenger : public Messenger{
public:
    NuwaMessenger(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> uvc_info, long usbHandle,
                  std::shared_ptr<Driver> driver);

    virtual ~NuwaMessenger();

    virtual int getFirmwareInfo(AngPropertyID propertyId, char **info) override;

    virtual int setFirmwareInfo(AngPropertyID propertyId, const char *value, int len) override;

    virtual int getChipSeInfo(AngPropertyID propertyId, char **info) override;

    virtual int setChipSeInfo(AngPropertyID propertyId, const char *value, int len) override;

    virtual int upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) override;

    virtual int cancelUpgradeCamera() override;

    virtual int communicateWithDevice(char **value, int &len);

    std::atomic<bool> upgrade_running_{false};

    inline AngUpgradeInfo getAngUpgradeInfo() const { return upgrade_info_; }

private:


    std::unique_ptr<McuDevBase> mcu_dev_base_;

    DeviceOnUpgradeCallback upgrade_callback_{nullptr};

    std::shared_ptr<AngThread> upgrade_thread_{nullptr};

    static ANG_THREAD_PROC upgradeThread(ANG_THREAD_PARAM pThreadParam);

    AngUpgradeInfo upgrade_info_;

    int fd_;

};


ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_NUWA_MESSENGER_H_