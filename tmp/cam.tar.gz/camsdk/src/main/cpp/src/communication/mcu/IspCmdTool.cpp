#include <stdio.h>
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "LinuxTypes.H"
#include "WCH55XISPDLL.H"
#include "LinuxAPI.H"
#include "Utils.H"
#include "IspCmdTool.h"
#include "AngLog.hpp"

#define VERSION "V1.10"

#define DEV_MAX_NUMBER 16
#define BIN_MAX_BUFLEN 1024 * 1024

#pragma pack(1)

typedef struct _CMDPARA
{
    char  PortName[16];            /* usb or uart device name */
    int   PortBaud;                /* uart baudrate */
    bool  bPrtVer;                 /* print BOOT version */
    bool  bFlashOpt;               /* whether to program or verify */
    char  EraseType;               /* erase type, 0: user-area, 1: all-area */
    char  CfgFile[MAX_PATH];       /* configuration file path */
    char  OptType;                 /* operation type, 0: download, 1: verfiy */
    char  FlashFile[MAX_PATH];     /* download file path */
} CMDPARA;

#pragma pack()

/* devices array */
Isp55xDevInforS AfxDnDev[DEV_MAX_NUMBER] = {0};
/* download option, must be set before operation */
CH55xIspOptionS IspOption = {0};
/* device index */
unsigned int uDevIndex = 0;
/* command parameter */
CMDPARA cmdPara = {0};

int SetIspCfg(bool bFlashOpt, UCHAR IspMcuSeries, UCHAR IspMcuType)
{
    int iRet = 0;
    static char SectionName[128] = "CH55xUICfg";
    char KeyName[100] = "";
    char RetStr[260] = "";

    if (IspMcuSeries == 0x11) {
        IspMcuSeries = 0x00;
    } else if (IspMcuSeries == 0x10) {
        IspMcuSeries = 0x01;
    } else {
        if (IspMcuSeries < 0x20)
            IspMcuSeries = IspMcuSeries - 0x10;
        else
            IspMcuSeries = IspMcuSeries - 0x20 + 0x0a;
    }

    IspOption.IspMcuSeries = IspMcuSeries;
    IspOption.IspMcuType = IspMcuType;
    IspOption.IsCodeProtect = 1;
    if (strstr(cmdPara.PortName, "ttyIAP"))
        IspOption.IspInterface = 1;
    else
        IspOption.IspInterface = 0;
    IspOption.IsBootLoader = 1;

    if (bFlashOpt) {
        if (memcmp(SectionName, "CH58xUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blAfterDownRest");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsMcuResetAfterIsp = 0;
                else
                    IspOption.IsMcuResetAfterIsp = 1;
            } else {
                IspOption.IsMcuResetAfterIsp = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bBootPinNum");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.BootPinNum = 0;
                else
                    IspOption.BootPinNum = 1;
            } else {
                IspOption.BootPinNum = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blClearDataFlash");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsClearDataFlash = 0;
                else
                    IspOption.IsClearDataFlash = 1;
            } else {
                IspOption.IsClearDataFlash = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bRSTReset");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsEnableResetPin = 0;
                else
                    IspOption.IsEnableResetPin = 1;
            } else {
                IspOption.IsEnableResetPin = 0;
            }
        } else if (memcmp(SectionName, "CH55xUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blAfterDownRest");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsMcuResetAfterIsp = 0;
                else
                    IspOption.IsMcuResetAfterIsp = 1;
            } else {
                IspOption.IsMcuResetAfterIsp = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bBootPinNum");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.BootPinNum = 0;
                else
                    IspOption.BootPinNum = 1;
            } else {
                IspOption.BootPinNum = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blClearDataFlash");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsClearDataFlash = 0;
                else
                    IspOption.IsClearDataFlash = 1;
            } else {
                IspOption.IsClearDataFlash = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bRSTReset");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsEnableResetPin = 0;
                else
                    IspOption.IsEnableResetPin = 1;
            } else {
                IspOption.IsEnableResetPin = 0;
            }
        } else if (memcmp(SectionName, "CH57xUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blAfterDownRest");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsMcuResetAfterIsp = 0;
                else
                    IspOption.IsMcuResetAfterIsp = 1;
            } else {
                IspOption.IsMcuResetAfterIsp = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bBootPinNum");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.BootPinNum = 0;
                else
                    IspOption.BootPinNum = 1;
            } else {
                IspOption.BootPinNum = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blClearDataFlash");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsClearDataFlash = 0;
                else
                    IspOption.IsClearDataFlash = 1;
            } else {
                IspOption.IsClearDataFlash = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bRSTReset");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsEnableResetPin = 0;
                else
                    IspOption.IsEnableResetPin = 1;
            } else {
                IspOption.IsEnableResetPin = 0;
            }
        } else if (memcmp(SectionName, "CH54xUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blAfterDownRest");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsMcuResetAfterIsp = 0;
                else
                    IspOption.IsMcuResetAfterIsp = 1;
            } else {
                IspOption.IsMcuResetAfterIsp = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bBootPinNum");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.BootPinNum = 0;
                else
                    IspOption.BootPinNum = 1;
            } else {
                IspOption.BootPinNum = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blClearDataFlash");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsClearDataFlash = 0;
                else
                    IspOption.IsClearDataFlash = 1;
            } else {
                IspOption.IsClearDataFlash = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bRSTReset");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsEnableResetPin = 0;
                else
                    IspOption.IsEnableResetPin = 1;
            } else {
                IspOption.IsEnableResetPin = 0;
            }
        } else if (memcmp(SectionName, "CH56xUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blAfterDownRest");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsMcuResetAfterIsp = 0;
                else
                    IspOption.IsMcuResetAfterIsp = 1;
            } else {
                IspOption.IsMcuResetAfterIsp = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "blClearDataFlash");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsClearDataFlash = 0;
                else
                    IspOption.IsClearDataFlash = 1;
            } else {
                IspOption.IsClearDataFlash = 0;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "bRSTReset");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsEnableResetPin = 0;
                else
                    IspOption.IsEnableResetPin = 1;
            } else {
                IspOption.IsEnableResetPin = 0;
            }
        } else if (memcmp(SectionName, "CH32FUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "IsIwdgSw");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsIwdgSw = 0;
                else
                    IspOption.IsIwdgSw = 1;
            } else {
                IspOption.IsIwdgSw = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "IsStandbyRst");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsStandbyRst = 0;
                else
                    IspOption.IsStandbyRst = 1;
            } else {
                IspOption.IsStandbyRst = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "IsStopRst");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsStopRst = 0;
                else
                    IspOption.IsStopRst = 1;
            } else {
                IspOption.IsStopRst = 1;
            }

            IspOption.WPR_DATA[0] = 0x00;
            IspOption.WPR_DATA[1] = 0x00;
            IspOption.WPR_DATA[2] = 0x00;
            IspOption.WPR_DATA[3] = 0x00;
            IspOption.WPR_DATA[4] = 0xff;
            IspOption.WPR_DATA[5] = 0xff;
            IspOption.WPR_DATA[6] = 0xff;
            IspOption.WPR_DATA[7] = 0xff;
        } else if (memcmp(SectionName, "CH32VUICfg", strlen(SectionName)) == 0) {
            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "IsIwdgSw");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsIwdgSw = 0;
                else
                    IspOption.IsIwdgSw = 1;
            } else {
                IspOption.IsIwdgSw = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "IsStandbyRst");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if (strcmp(RetStr, "0") == 0)
                    IspOption.IsStandbyRst = 0;
                else
                    IspOption.IsStandbyRst = 1;
            } else {
                IspOption.IsStandbyRst = 1;
            }

            memset(KeyName, 0, sizeof(KeyName));
            sprintf(KeyName, "%s", "IsStopRst");
            memset(RetStr, 0, sizeof(RetStr));
            if (GetProfileString(cmdPara.CfgFile, SectionName, KeyName, RetStr) == 0) {
                if(strcmp(RetStr,"0") == 0)
                    IspOption.IsStopRst = 0;
                else
                    IspOption.IsStopRst = 1;
            } else {
                IspOption.IsStopRst = 1;
            }

            IspOption.WPR_DATA[0] = 0x00;
            IspOption.WPR_DATA[1] = 0x00;
            IspOption.WPR_DATA[2] = 0x00;
            IspOption.WPR_DATA[3] = 0x00;
            IspOption.WPR_DATA[4] = 0xff;
            IspOption.WPR_DATA[5] = 0xff;
            IspOption.WPR_DATA[6] = 0xff;
            IspOption.WPR_DATA[7] = 0xff;
        }

        if (cmdPara.EraseType == 1)
            IspOption.IsEraseAllCFlash = 1;
    }

    if (WCH55x_SetIspOption(&IspOption))
        iRet = 0;
    else {
        iRet = 2;
        goto _END;
    }
    _END:
    return iRet;
}

int GetDevIndex()
{
    int iRet = 1,iDevCnt = 0,i = 0;
    UCHAR BtChipSeries;
    UCHAR BtChipType;
    BOOL IsPreBTV230;
    CHAR  szStr[20] = "";

    if(strlen(cmdPara.PortName) < 3) {
        iRet = 2;
        goto _END;
    }
    sprintf(szStr,"%s",cmdPara.PortName);
    iDevCnt = WCH55x_EnumDevices(AfxDnDev, DEV_MAX_NUMBER, &BtChipSeries, &BtChipType, &IsPreBTV230);
    if (iDevCnt == 0) {
        iRet = 3;
        goto _END;
    }

    for (i = 0; i < iDevCnt; i++) {
        if (strcmp(AfxDnDev[i].PortName, szStr) == 0) {
            uDevIndex = i;
            iRet = 0;
            goto _END;
        }
    }

    _END:
    return iRet;
}

int DoOption(bool bFlashOpt)
{
    int iRet = 1;
    char szStr[200] = "";
    int hFile;
    unsigned long uFileLen = 0, uBinLen = 0, uWrRdLen = 0;
    char *pFileBuf = NULL, *pBinBuf = NULL;

    if (!WCH55x_GetIspDeviceInfor(uDevIndex, &AfxDnDev[uDevIndex])) {
        iRet = 2;
        goto _END;
    }

    if (cmdPara.bPrtVer) {
        memset(szStr,0,sizeof(szStr));
        sprintf(szStr,"BOOT VERSION: V%X.%X%X\r\n", AfxDnDev[uDevIndex].IspVer[1], AfxDnDev[uDevIndex].IspVer[2], AfxDnDev[uDevIndex].IspVer[3]);
        ANG_LOGI("startMcuUpgrade: %s", szStr);
        iRet = 0;
    }

    if (bFlashOpt) {
        memset(szStr, 0, sizeof(szStr));
        sprintf(szStr, "{\"Device\":\"%s\",\"Status\":\"Ready\"}", cmdPara.PortName);
        ANG_LOGI("startMcuUpgrade: %s", szStr);

        if (strlen(cmdPara.FlashFile) < 1) {
            iRet = 3;
            goto _END;
        }

        hFile = open(cmdPara.FlashFile, O_RDONLY);
        if (hFile < 0) {
            iRet = 4;
            goto _END;
        }

        uFileLen = get_file_size(cmdPara.FlashFile);
        if (uFileLen < 1) {
            iRet = 4;
            goto _END;
        }

        pFileBuf = (char*)malloc(uFileLen + 1);
        memset(pFileBuf, 0, uFileLen + 1);

        pBinBuf = (char*)malloc(BIN_MAX_BUFLEN);
        memset(pBinBuf, 0, BIN_MAX_BUFLEN);

        uWrRdLen = read(hFile, pFileBuf, uFileLen);
        if (uWrRdLen != uFileLen) {
            iRet = 5;
            goto _END;
        }

        close(hFile);

        if (strstr(cmdPara.FlashFile,".hex") || strstr(cmdPara.FlashFile,".HEX")) {
            if (!HexToBin_W(0, pFileBuf, uFileLen, pBinBuf, &uBinLen)) {
                iRet = 6;
                goto _END;
            }
        } else {
            memcpy(pBinBuf, pFileBuf, uFileLen);
            uBinLen = uFileLen;
        }

        uWrRdLen = 800 * 1024;
        if (IspOption.IsClearDataFlash) {
            if (!WCH55x_WriteDataFlash(AfxDnDev[uDevIndex].Index, 0, &uWrRdLen, (unsigned char*)"CLEAR", true)) {
                iRet = 7;
                goto _END;
            }
        }

        if (cmdPara.OptType == 0) {
            memset(szStr,0,sizeof(szStr));
            if (!WCH55x_FlashProgramB(AfxDnDev[uDevIndex].Index, (unsigned char*)pBinBuf, uBinLen, 1, NULL, 0, 0)) {
                iRet = 8;
                goto _END;
            } else {
                usleep(10 * 1000);
                memset(szStr, 0, sizeof(szStr));
                sprintf(szStr, "{\"Device\":\"%s\", \"Status\":\"Programming\", \"Progress\":100%%} ", cmdPara.PortName);
                ANG_LOGI("startMcuUpgrade: %s", szStr);
                iRet = 0;
                goto _END;
            }
        } else {
            if (!WCH55x_FlashVerifyB(AfxDnDev[uDevIndex].Index, (unsigned char*)pBinBuf, uBinLen, 1, NULL, 0, 0)) {
                iRet = 9;
                goto _END;
            } else {
                usleep(10 * 1000);
                memset(szStr, 0, sizeof(szStr));
                sprintf(szStr, "{\"Device\":\"%s\", \"Status\":\"Verifing\", \"Progress\":100%%} ", cmdPara.PortName);
                ANG_LOGI("startMcuUpgrade: %s", szStr);
                iRet = 0;
                goto _END;
            }
        }
    }

    _END:
    if (hFile < 0) {
        close(hFile);
    }
    if (pFileBuf != NULL) {
        free(pFileBuf);
        pFileBuf = NULL;
    }
    if (pBinBuf != NULL) {
        free(pBinBuf);
        pBinBuf = NULL;
    }

    return iRet;
}

static const struct option lopts[] = {
        { "device", required_argument, 0, 'p' },
        { "speed", optional_argument, 0, 'b' },
        { "version", required_argument, 0, 'v' },
        { "erase", required_argument, 0, 'e' },
        { "configure", required_argument, 0, 'c' },
        { "operation", required_argument, 0, 'o' },
        { "flash", required_argument, 0, 'f' },
        { NULL, 0, 0, 0 },
};

static void print_usage(const char *prog)
{
    printf("Usage: %s [-pbvecofh]\n", prog);
    puts("  -p --device    device to operate\n"
         "  -b --speed     uart speed\n"
         "  -v --version   boot/tool version\n"
         "  -e --erase	   erase type\n"
         "  -c --configure configure file path\n"
         "  -o --operation operation type\n"
         "  -f --flash	   flash file path\n"
    );
    exit(1);
}

static void parse_opts(int argc, char *argv[])
{
    int c;
    // -p /dev/ch37x0 -v boot -e mass -c config.ini -o program -f /sdcard/mcu.hex
    while (1) {
        c = getopt_long(argc, argv, "p:b:v:e:c:o:f:h", lopts, NULL);
        if (c == -1) {
            break;
        }
        switch (c) {
            case 'p':
                if (optarg != NULL)
                    strcpy(cmdPara.PortName, optarg);
                break;
            case 'b':
                if (optarg != NULL)
                    cmdPara.PortBaud = atoi(optarg);
                break;
            case 'v':
                if (strcmp(optarg, "boot")==0)
                    cmdPara.bPrtVer = true;
                break;
            case 'e':
                if (strcmp(optarg, "mass") == 0)
                    cmdPara.EraseType = 1;
                else
                    cmdPara.EraseType = 0;
                break;
            case 'c':
                if (optarg != NULL)
                    strcpy(cmdPara.CfgFile, optarg);
                break;
            case 'o':
                cmdPara.bFlashOpt = true;
                if (strcmp(optarg, "verify") == 0)
                    cmdPara.OptType = 1;
                else if (strcmp(optarg, "program") == 0)
                    cmdPara.OptType = 0;
                break;
            case 'f':
                if (optarg)
                    strcpy(cmdPara.FlashFile, optarg);
                break;
            case 'h':
            default:
                print_usage(argv[0]);
                break;
        }
    }
}

int _main(int argc, char *argv[])
{
    int i = 0, iRet = 0;
    char TextBufferTmp[2000] = "";
    BOOL bRemove = FALSE;
    UCHAR ChipSeries = 0x00, ChipType = 0x00;

    ANG_LOGI("\r\n=====ISP_Flash_Tool=====\r\n" );
    ANG_LOGI("TOOL VERSION:  %s", VERSION );

    parse_opts(argc, argv);

    if (!cmdPara.bPrtVer && !cmdPara.bFlashOpt)
        return 0;

    sprintf(TextBufferTmp, "p:%s\r\nb:%d\r\nv:%d\r\ne:%d\r\nc:%s\r\no:%d\r\nf:%s\r\n",
            cmdPara.PortName, cmdPara.PortBaud, cmdPara.bPrtVer, cmdPara.EraseType,
            cmdPara.CfgFile, cmdPara.OptType, cmdPara.FlashFile);
    ANG_LOGI("%s", TextBufferTmp);

    /* disable debug messages */
    setDebug(0);

    LoadChipCfg();

    iRet = ISPMcuTypeRead(cmdPara.PortName, &ChipType, &ChipSeries);
    if (iRet == 0) {
        memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
        sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":4, \"Message\":\"Fail to find the specified isp device\"}\r\n",cmdPara.PortName);
        ANG_LOGI("%s", TextBufferTmp);
        return 4;
    }

    iRet = SetIspCfg(cmdPara.bFlashOpt, ChipSeries, ChipType);
    if (iRet) {
        if (iRet == 1) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":2, \"Message\":\"Fail to get parameters from cfg file\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 2;
        } else if(iRet == 2) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":3, \"Message\":\"Fail to set isp parameters\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 3;
        } else {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":100, \"Message\":\"Unknow error\"}\r\n", cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 100;
        }
    }

retry:

    iRet = GetDevIndex();
    if (iRet) {
        if (iRet == 1) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":4, \"Message\":\"Fail to find the specified isp device\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 4;
        } else if(iRet == 2) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":5, \"Message\":\"The specified isp device name is invalid\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 5;
        } else if(iRet == 3) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":6, \"Message\":\"Fail to find any valid isp device\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 6;
        } else {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":100, \"Message\":\"Unknow error\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 100;
        }

    }
    if (cmdPara.OptType == 0 && iRet == 0) {
        if (WCH55x_IspRemoveProtect(uDevIndex)) {
            Sleep(2000);
            if (bRemove == FALSE) {
                bRemove = TRUE;
                goto retry;
            }
        }

    }

    iRet = DoOption(cmdPara.bFlashOpt);
    if (iRet) {
        if(iRet == 2) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":7, \"Message\":\"Fail to get device info\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 7;
        } else if(iRet == 3) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":8, \"Message\":\"The path of the flash file is invalid\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 8;
        } else if(iRet == 4) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":9,\"Message\":\"The length of the flash file is invalid\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 9;
        } else if(iRet == 5) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":10, \"Message\":\"Fail to read the flash file\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 10;
        } else if(iRet == 6) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\",\"Code\":11, \"Message\":\"Fail to convert the flash file from HEX to BIN\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 11;
        } else if(iRet == 7) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":12, \"Message\":\"Fail to clear dataflsh\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 12;
        } else if(iRet == 8) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":13, \"Message\":\"Fail to download\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 13;
        } else if(iRet == 9) {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":14, \"Message\":\"Fail to verify\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 14;
        } else {
            memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
            sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":100, \"Message\":\"Unknow error\"}\r\n",cmdPara.PortName);
            ANG_LOGI("%s", TextBufferTmp);
            return 100;
        }
    }

    memset(TextBufferTmp, 0, sizeof(TextBufferTmp));
    sprintf(TextBufferTmp, "{\"Device\":\"%s\", \"Status\":\"Finished\", \"Code\":0,\"Message\":\"Succeed\"}\r\n",cmdPara.PortName);
    ANG_LOGI("%s", TextBufferTmp);

    return 0;
}

int startMcuUpgrade(char *mcuFile){
    ANG_LOGI("startMcuUpgrade: ======ISP_Flash_Tool======");
    ANG_LOGI("startMcuUpgrade: TOOL VERSION: %s", VERSION);
    ANG_LOGI("startMcuUpgrade: Fw=%s", mcuFile);

	int ret = 0;
	char msg[2000] = "";
	BOOL bRemove = FALSE;

    memset(AfxDnDev, 0, sizeof(AfxDnDev));
    IspOption = {0};
    uDevIndex = 0;
    cmdPara = {0};

	//1.load
	setDebug(1);
	if (!LoadChipCfg()){
		ANG_LOGE("startMcuUpgrade: LoadChipCfg() failed.");
		ret = -1;
		return ret;
	}

	//2.init
	cmdPara.bPrtVer = true;
    cmdPara.bFlashOpt = true;
    cmdPara.OptType = 0;
    cmdPara.EraseType = 0;
	strcpy(cmdPara.FlashFile, mcuFile);
	strcpy(cmdPara.PortName, "/dev/ch37x0");

    //3.config
	UCHAR ChipSeries = 0x00, ChipType = 0x00;
	ret = ISPMcuTypeRead(cmdPara.PortName, &ChipType, &ChipSeries);
	if (ret == 0) {
		memset(msg, 0, sizeof(msg));
		sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":4, \"Message\":\"Fail to find the specified isp device\"}\r\n", cmdPara.PortName);
		ANG_LOGE("startMcuUpgrade: ISPMcuTypeRead: %s", msg);
		return 4;
	}
    ANG_LOGI("startMcuUpgrade: ISPMcuTypeRead: ChipType=%x, ChipSeries=%x", ChipType, ChipSeries);

	if (ChipSeries == 0x11) {
		IspOption.IspMcuSeries = 0x00;
	} else if (ChipSeries == 0x10) {
		IspOption.IspMcuSeries = 0x01;
	} else {
		if (ChipSeries < 0x20){
			IspOption.IspMcuSeries = ChipSeries - 0x10;
		} else{
			IspOption.IspMcuSeries = ChipSeries - 0x20 + 0x0a;
		}
	}
	IspOption.IspMcuType         = ChipType;
    IspOption.IsCodeProtect      = 1;
    IspOption.IsEnableResetPin   = 1;
    IspOption.IsMcuResetAfterIsp = 1;
    IspOption.BootPinNum         = 1;
    IspOption.IspInterface       = 0;
    IspOption.IsClearDataFlash   = 0;
    IspOption.IsEraseAllCFlash   = 0;
	if (!WCH55x_SetIspOption(&IspOption)){
		ANG_LOGE("startMcuUpgrade: WCH55x_SetIspOption() failed.");
        return 101;
	}

    //4.program
retry:
    ret = GetDevIndex();
    if (ret) {
        memset(msg, 0, sizeof(msg));
        if (ret == 1) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":4, \"Message\":\"Fail to find the specified isp device\"}\r\n", cmdPara.PortName);
            ret = 4;
        } else if(ret == 2) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":5, \"Message\":\"The specified isp device name is invalid\"}\r\n", cmdPara.PortName);
            ret = 5;
        } else if(ret == 3) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":6, \"Message\":\"Fail to find any valid isp device\"}\r\n", cmdPara.PortName);
            ret = 6;
        } else {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":100, \"Message\":\"Unknow error\"}\r\n", cmdPara.PortName);
            ret = 100;
        }
        ANG_LOGI("startMcuUpgrade: GetDevIndex(): %s", msg);
        return ret;
    }
    if (cmdPara.OptType == 0 && WCH55x_IspRemoveProtect(uDevIndex)) {
        ANG_LOGI("startMcuUpgrade: WCH55x_IspRemoveProtect()");
        Sleep(2000);
        if (!bRemove) {
            bRemove = TRUE;
            goto retry;
        }
    }

    ret = DoOption(cmdPara.bFlashOpt);
    if (ret) {
        memset(msg, 0, sizeof(msg));
        if(ret == 2) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":7, \"Message\":\"Fail to get device info\"}\r\n", cmdPara.PortName);
            ret = 7;
        } else if(ret == 3) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":8, \"Message\":\"The path of the flash file is invalid\"}\r\n", cmdPara.PortName);
            ret = 8;
        } else if(ret == 4) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":9,\"Message\":\"The length of the flash file is invalid\"}\r\n", cmdPara.PortName);
            ret = 9;
        } else if(ret == 5) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":10, \"Message\":\"Fail to read the flash file\"}\r\n", cmdPara.PortName);
            ret = 10;
        } else if(ret == 6) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\",\"Code\":11, \"Message\":\"Fail to convert the flash file from HEX to BIN\"}\r\n", cmdPara.PortName);
            ret = 11;
        } else if(ret == 7) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":12, \"Message\":\"Fail to clear dataflsh\"}\r\n", cmdPara.PortName);
            ret = 12;
        } else if(ret == 8) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":13, \"Message\":\"Fail to download\"}\r\n", cmdPara.PortName);
            ret = 13;
        } else if(ret == 9) {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":14, \"Message\":\"Fail to verify\"}\r\n", cmdPara.PortName);
            ret = 14;
        } else {
            sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Fail\", \"Code\":100, \"Message\":\"Unknow error\"}\r\n", cmdPara.PortName);
            ret = 100;
        }
        ANG_LOGI("startMcuUpgrade: %s", msg);
        return ret;
    }

    memset(msg, 0, sizeof(msg));
    sprintf(msg, "{\"Device\":\"%s\", \"Status\":\"Finished\", \"Code\":0,\"Message\":\"Succeed\"}\r\n", cmdPara.PortName);
    ANG_LOGI("startMcuUpgrade: %s", msg);

    return ret;
}