/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _USB_DEV_BASE_H_
#define _USB_DEV_BASE_H_

#include "AngUtil.h"
#include "AngDefines.h"
#include "AngDescriptors.h"

#include "libusbi.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

static const int MAX_PACKET_SIZE = 64;//一次最多只能传输64字节
static const int MAX_BUFF_SIZE = 1024;
static const int MAX_UPGRADE_PACKET_SIZE = 36; //升级包一次最多只能传输36字节
static const int ANG_USB_HOST_PROTOCOL_SEND_RETRIES = 3;

static const int ANG_STATUS_USB_TRANSFER_TIMEOUT = -100;
static const int ANG_STATUS_USB_TRANSFER_STALL = -101;
static const int ANG_STATUS_USB_GOT_UNEXPECTED_BYTES = -102;
static const int ANG_STATUS_USB_NOT_ENOUGH_DATA = -103;

typedef enum {
    USB_EP_BULK = 0,
    USB_EP_ISOCHRONOUS,
    USB_EP_INTERRUPT,
} USBEndPointType;

typedef enum {
    USB_DIRECTION_IN = 0,
    USB_DIRECTION_OUT,
} USBDirectionType;

typedef enum {
    USB_CONTROL_TYPE_STANDARD = 0,
    USB_CONTROL_TYPE_CLASS,
    USB_CONTROL_TYPE_VENDOR,
} USBControlType;

typedef struct USBEndPointHandle {
    unsigned char nAddress;
    USBEndPointType nType;
    USBDirectionType nDirection;
    int nMaxPacketSize;
} USBEPHandle;

typedef USBEndPointHandle *USB_EP_HANDLE;

class UsbDevBase {

public:
    UsbDevBase(std::shared_ptr<AngDescriptor> descriptor, std::string uid) :
    descriptor_(descriptor), uid_(uid){
        auto deviceDescriptors = descriptor->getUsbDeviceDescriptors();
        for (auto &dev : *deviceDescriptors) {
            if (dev->getAngDevInfo()->usb.uid == uid) {
                ang_dev_info_ = dev->getAngDevInfo();
                auto interfaces = dev->getConfigurationDescriptor()->getInterfaceDescriptorList();
                for (auto &interface : *interfaces) {
                    if (interface->getInterfaceType() == ANG_INTERFACE_MCU ||
                            interface->getInterfaceType() == ANG_INTERFACE_VENDOR ||
                            interface->getInterfaceType() == ANG_INTERFACE_UVC_VIDEO_STREAMING) {
                        auto endpoints = interface->getEndpointDescriptorList();
                        for (auto &endpoint : *endpoints) {
                            if (endpoint->getEndpointTransferType() != ANG_ENDPOINT_TRANSFER_INTERRUPT &&
                                endpoint->getEndpointType() == ANG_ENDPOINT_IN)
                                endpoint_id_in_ = endpoint->getEndpointAddress();
                            else if (endpoint->getEndpointTransferType() != ANG_ENDPOINT_TRANSFER_INTERRUPT &&
                                endpoint->getEndpointType() == ANG_ENDPOINT_OUT)
                                endpoint_id_out_ = endpoint->getEndpointAddress();
                        }
                    }
                }
            }

        }

        if (endpoint_id_in_ == 0 || endpoint_id_out_ == 0) {
            ANG_LOGE("endpoint_id_in_:%x or endpoint_id_out_:%x is wrong!!!", endpoint_id_in_, endpoint_id_out_ );
            assert(0);
        }
    };

    virtual ~UsbDevBase() {};

protected:

    std::shared_ptr<AngDevInfo> ang_dev_info_;

    std::shared_ptr<AngDescriptor> descriptor_;
    std::string uid_;

    libusb_context *gContext{nullptr};
    libusb_device *usb_dev{nullptr};
    struct libusb_device_handle *usb_devh{nullptr};
    USB_EP_HANDLE pEPInHandle;
    USB_EP_HANDLE pEPOutHandle;

    int endpoint_id_in_{0};
    int endpoint_id_out_{0};

    int openDevice(int fd);

    int closeDevice();

    int angHostProtocolUSBSend(u_char *pBuffer, uint32_t nBufferSize, uint32_t nTimeOut);

    int angHostProtocolUSBReceive(u_char *pBuffer, uint32_t nBufferSize,
                                  uint32_t *pnBytesReceived, uint32_t nTimeOut);

    int angHostProtocolWriteUpload(int &FileToUpload, uint32_t nOffset,
                                   uint32_t nFileSize, uint32_t &nNextOffset, uint8_t& packetNo);

    int angMcuUpload(u_char* dataBuffer, uint32_t nOffset,
                     uint32_t nFileSize, uint32_t &nNextOffset, uint32_t type);

    int doUpgradeMcuDevice_new(const std::string &upgradeFilePath);


private:

    int openEndPoint(int nEndPointID, USBEndPointType nEPType,
                     USBDirectionType nDirType, USB_EP_HANDLE &pEPHandlePtr);

    int closeEndPoint(USB_EP_HANDLE &pEPHandle);

    int angUSBWriteEndPoint(USB_EP_HANDLE pEPHandle, u_char *pBuffer, uint32_t nBufferSize,
                            uint32_t nTimeOut);

    int angUSBReadEndPoint(USB_EP_HANDLE pEPHandle, u_char *pBuffer, uint32_t nBufferSize,
                           uint32_t *pnBytesReceived, uint32_t nTimeOut);
};

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_USB_DEV_BASE_H_

