/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _USB_UVC_DEV_H_
#define _USB_UVC_DEV_H_

#include "UsbDevBase.h"
#include "Mutex.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

class UsbUvcDev :
        public UsbDevBase{
public:
    UsbUvcDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid);
    virtual ~UsbUvcDev();

    int openUvcDevice(int fd);

    int closeUvcDevice();

    /**
     * @Description: ISP固件升级
     * @param:sn：准备升级的设备序列号
     * @param:upgradeFilePath：ISP升级文件绝对路径
     * @param:callback：升级过程中升级进度回调函数
     * @return: 0: 成功; 其他: 失败
     **/
    virtual int ispUpgrade(std::string mcuPid, char *upgradeFilePath, usb_isp_upgrade_process_fn callback);

private:
    Mutex ang_mutex_;
};

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_USB_UVC_DEV_H_