/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "VegaMessenger.h"
#include "Mutex.h"
#include "NetTypes.h"

using namespace ang;

//织女星XU指令
#define MAX_PACKET_SIZE 60 //一次最多只能传输60字节
#define ACK		0x06 	//指令正常
#define NAK		0x15	//指令异常
#define WAIT	0x18	//指令正在处理

static int const UDP_MAX_OTA_PACKET_SIZE = 255;

//se指令状态码
#define SE_WAIT	9999	//指令正在处理
#define SE_ACK	0	    //指令正常

const static uint16_t kXuValue = 0x0100;
const static uint16_t kXuIndex = 0x0A00;

const static int CMD_HANDSHAKE = 0x88;
static const int CMD_GET_LONG_SE_INFO = 0x90;//GET       获取长于60字节的SE指令内容的指令
//SE指令错误码
static const int ANG_STATUS_RETURN_DATA_ERROR = -1000;             //SE返回的协议数据错误
static const int ANG_STATUS_RETURN_SE_INNER_ERROR = -1001;         //SE内部数据错误
static const int ANG_STATUS_CMD_PARM_ERROR = -1002;                //SE参数错误
static const int ANG_STATUS_SEND_DATA_PACKET_TIMEOUT = -1003;      //SE发送内容超时

static uint8_t SE_PACKET_NO = 0; // SE数据包序号
static uint8_t SE_RETRY_COUNT = 3; //产生发送SE数据包的次数


//固件升级失败原因
static const int UPGRADE_FILE_NOT_FOUND = -100;
static const int UPGRADE_FILE_OPEN_FAILED = -101;
static const int UPGRADE_BEGIN_PACKET_SEND_FAILED = -102;
static const int UPGRADE_FILE_PACKET_SEND_FAILED = -103;
static const int UPGRADE_FINISH_PACKET_FAILED = -104;
static const int UPGRADE_CAMERA_MODULE_FIRMWARE_FAILED = -105; //camera模组升级固件失败

Mutex usb_control_mutex_;

Mutex ota_mutex_;

static int angErrorReturn(int cmd, uint8_t * receiveBuf, char** info);

static int handleCameraIP(uint8_t* value, uint32_t& receiveDataSize);
static int handleCameraMacAddr(uint8_t* value, uint32_t& receiveDataSize);
static int handleCameraDHCPEnable(uint8_t* value, uint32_t& receiveDataSize);
static int handleCameraTelnetEnable(uint8_t* value, uint32_t& receiveDataSize);

VegaMessenger::VegaMessenger(std::shared_ptr<AngDescriptor> descriptor,
                             std::shared_ptr<AngDevInfo> uvc_info, long usbHandle,
                             std::shared_ptr<Driver> driver) :
        Messenger(descriptor, uvc_info, usbHandle, driver),
        dev_handle_(reinterpret_cast<libusb_device_handle *>(usbHandle)),
        upgrade_thread_(std::make_shared<AngThread>()) {
    ANG_LOGI("VegaMessenger");
}

int VegaMessenger::getFirmwareInfo(AngPropertyID cmd, char **info) {
    ANG_LOGI("getFirmwareInfo cmd:0x%x", cmd);
    uint8_t receiveBuf[MAX_PACKET_SIZE];
    memset(receiveBuf, 0, MAX_PACKET_SIZE);
    uint32_t pnBytesReceived = 0;
    int rc = doReceiveControl(cmd, receiveBuf, MAX_PACKET_SIZE, pnBytesReceived, 1000);
    if (rc != ANG_STATUS_SUCCESS)
        return ANG_STATUS_FAILED;

    if(cmd != receiveBuf[0] && (cmd != CMD_NET_IP && cmd != CMD_NET_MAC && cmd != CMD_NET_DHCP && cmd != CMD_NET_TELNET)) {
        ANG_LOGE("request cmd[%x] is not return cmd[%x]!", cmd, receiveBuf[0]);
        return ANG_STATUS_FAILED;
    }

    if(cmd == CMD_ISP_SN) {
        uint8_t LEN = 48;
        char hex_tmp[LEN*2];
        for(int i=0;i<LEN;i++) {
            sprintf(&hex_tmp[i*2],"%02x", receiveBuf[i+1]);
        }
        ANG_LOGI("getFirmwareInfo info:%s", hex_tmp);
        angOSMemCopy(*info, hex_tmp, LEN*2);
        return ANG_STATUS_SUCCESS;
    }

    if (cmd == CMD_NET_IP) {
        rc = handleCameraIP(receiveBuf, pnBytesReceived);
        if (rc == ANG_STATUS_SUCCESS) {
            angOSMemCopy(*info, receiveBuf, pnBytesReceived);
            return ANG_STATUS_SUCCESS;
        } else
            return ANG_STATUS_FAILED;
    } else if (cmd == CMD_NET_MAC) {
        rc = handleCameraMacAddr(receiveBuf, pnBytesReceived);
        if (rc == ANG_STATUS_SUCCESS) {
            angOSMemCopy(*info, receiveBuf, pnBytesReceived);
            return ANG_STATUS_SUCCESS;
        } else
            return ANG_STATUS_FAILED;
    } else if (cmd == CMD_NET_DHCP) {
        rc = handleCameraDHCPEnable(receiveBuf, pnBytesReceived);
        if (rc == ANG_STATUS_SUCCESS) {
            angOSMemCopy(*info, receiveBuf, pnBytesReceived);
            return ANG_STATUS_SUCCESS;
        } else
            return ANG_STATUS_FAILED;
    } else if (cmd == CMD_NET_TELNET) {
        bool ret = IsUtf8String(reinterpret_cast<char *>(receiveBuf), pnBytesReceived);
        if (ret) {
            angOSMemCopy(*info, receiveBuf, pnBytesReceived);
            return ANG_STATUS_SUCCESS;
        }
        rc = handleCameraTelnetEnable(receiveBuf, pnBytesReceived);
        if (rc == ANG_STATUS_SUCCESS) {
            angOSMemCopy(*info, receiveBuf, pnBytesReceived);
            return ANG_STATUS_SUCCESS;
        } else
            return ANG_STATUS_FAILED;
    }

    bool ret = IsUtf8String(reinterpret_cast<char *>(receiveBuf+1), pnBytesReceived-1);
    if(ret) {
        if(pnBytesReceived-1 > MAX_PACKET_SIZE) {
            ANG_LOGE("pnBytesReceived is exceed the maximum");
            return ANG_STATUS_FAILED;
        }

        if (cmd == CMD_SN) {
            char *temp = "SN=";
            if(strstr(reinterpret_cast<char *>(receiveBuf + 1), temp) != NULL) {
                clearHeadTailSpace(receiveBuf + 1);
                angOSMemCopy(*info, receiveBuf+1+3, pnBytesReceived-1-3);
                return ANG_STATUS_SUCCESS;
            }
        }

        angOSMemCopy(*info, receiveBuf+1, pnBytesReceived-1);
        return ANG_STATUS_SUCCESS;
    } else {
        ANG_LOGE("AngDeviceGetFirmwareInfo request cmd:0x%x, result:%s, length:%d is not UTF-8 string!",
                 cmd, receiveBuf, pnBytesReceived);
        return ANG_STATUS_FAILED;
    }
}

int VegaMessenger::setFirmwareInfo(AngPropertyID cmd, const char *value, int len) {
    ANG_LOGI("setFirmwareInfo 0x%x, %s, len:%d", cmd, value, len);
    if (len <= 0)
        return ANG_STATUS_FAILED;

    uint32_t pnBytesReceived = 0;
    int rc = ANG_STATUS_SUCCESS;

    //需要设置非字符串格式的命令
    if (cmd == CMD_UPGRADE_FALLBACK || cmd == CMD_NET_DHCP || cmd == CMD_NET_TELNET) {
        int nValude = 0;
        sscanf(value, "%x", &nValude);
        ANG_LOGI("setFirmwareInfo nValude = 0x%x", nValude);
        uint8_t temp_value[1];
        temp_value[0] = nValude;
        ANG_LOGI("setFirmwareInfo temp_value[0] = 0x%x", temp_value[0]);
        rc = doSendControl(cmd, temp_value, len, 1000);
    } else {
        rc = doSendControl(cmd, (uint8_t *) value, len, 1000);
    }

    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("setFirmwareInfo 0x%x failed, rc:%d", cmd, rc);
        return ANG_STATUS_FAILED;
    }

    if (cmd == CMD_NET_IP || cmd == CMD_NET_MAC || cmd == CMD_NET_DHCP || cmd == CMD_NET_TELNET) {
        if (len > 0)
            return ANG_STATUS_SUCCESS;
        else
            return ANG_STATUS_FAILED;
    }

    if (cmd == CMD_RESET)
        return ANG_STATUS_SUCCESS;

    uint8_t receiveBuf[MAX_PACKET_SIZE];
    memset(receiveBuf, 0, MAX_PACKET_SIZE);
    int tryCount = 0;
    int sleepTime = 5;//ms
    int tryMaxCount = 200;
    if(cmd == CMD_IMAGE) {
        sleepTime = 200;
        tryMaxCount = 50;
    }
    while (tryCount < tryMaxCount) {
        memset(receiveBuf, 0, MAX_PACKET_SIZE);
        rc = doReceiveControl(CMD_HANDSHAKE, receiveBuf, 0x0C, pnBytesReceived, 1000);
        if (/*rc != XN_STATUS_OK || */receiveBuf[0] == NAK) {
            ANG_LOGE("setFirmwareInfo failed, rc: %d, status:%d", rc, receiveBuf[0]);
            return ANG_STATUS_FAILED;
        }
        if (receiveBuf[0] == ACK) {
            ANG_LOGI("setFirmwareInfo 0x%x OK, tryCount:%d", cmd, tryCount);
            return ANG_STATUS_SUCCESS;
        }

        tryCount++;
        angOSSleep(sleepTime);
    }

    return ANG_STATUS_FAILED;
}

int VegaMessenger::getChipSeInfo(AngPropertyID cmd, char **info) {
    ANG_LOGI("getChipSeInfo 0x%x", cmd);
    uint8_t receiveBuf[MAX_PACKET_SIZE];
    memset(receiveBuf, 0, MAX_PACKET_SIZE);
    uint32_t pnBytesReceived = 0;
    int rc = doReceiveControl(cmd, receiveBuf, MAX_PACKET_SIZE, pnBytesReceived, 1000);
    if (rc != ANG_STATUS_SUCCESS)
        return angErrorReturn(cmd, receiveBuf, info);

    ANG_LOGI("getChipSeInfo request cmd:0x%x, result:%s, length:%d, return cmd:0x%x",
             cmd, receiveBuf+1, pnBytesReceived, receiveBuf[0]);

    if(cmd != receiveBuf[0]) {
        ANG_LOGE("request cmd is not return cmd!");
        return angErrorReturn(cmd, receiveBuf, info);
    }

    if(pnBytesReceived < 5) {
        ANG_LOGE("return buf length is < 5");
        return angErrorReturn(cmd, receiveBuf, info);
    }
    //1-4是请求的状态码，int类型，总共4字节， 为9999时， 代表操作未完成， 为0时代表操作成功， 其它值为错误码
    int result = DW_TO_INT(&receiveBuf[1]);
    if(result != 0) {
        ANG_LOGE("getChipSeInfo 0x%x result:%d failed!", cmd, result);
        return angErrorReturn(cmd, receiveBuf, info);
    }

    //返回的数据超过1包的数据量60字节
    if(cmd == CMD_SE_GET_COS_VER || cmd == CMD_SE_GET_SN || cmd == CMD_SE_GET_UNLOCK_CMD ||
        cmd == CMD_SE_GET_CONFIG_SM3 || cmd == CMD_SE_GET_INSPECT_REQUEST_PARAM || cmd == CMD_SE_GET_SDK_VER ||
       cmd == CMD_SE_GET_AUTH_SIGN || cmd == CMD_SE_UNLOCK) {
        return angGetLongSeInfo(cmd, info);
    }

    //根据模组返回的buff解析
    if(cmd == CMD_SE_GET_TIME) {
        if(pnBytesReceived != 13) {
            ANG_LOGE("return buff length is wrong!");
            return angErrorReturn(cmd, receiveBuf, info);
        }
        uint64_t time_stamp = QW_TO_LONG(&receiveBuf[5]);
        std::string str = std::to_string(time_stamp);
        angOSMemCopy(*info, str.c_str(), str.size());
    }
    else if (cmd == CMD_SE_GET_TAMPER_STATUS) {
        if(pnBytesReceived != 9) {
            ANG_LOGE("return buff length is wrong!");
            return angErrorReturn(cmd, receiveBuf, info);
        }
        int32_t tamper_status = DW_TO_INT(&receiveBuf[5]);
        char temp[11];
        angOSItoA(tamper_status, temp, 10);
        angOSMemCopy(*info, temp, 11);
    }
    else if (cmd == CMD_SE_GET_RUN_MODE || cmd == CMD_SE_GET_COS_TYPE || cmd == CMD_SE_GET_SWITCH) {
        if(pnBytesReceived != 6) {
            ANG_LOGE("return buff length is wrong!");
            return angErrorReturn(cmd, receiveBuf, info);
        }
        uint8_t result = receiveBuf[5];
        char temp[3];
        angOSItoA(result, temp, 10);
        angOSMemCopy(*info, temp, 3);
    }

    ANG_LOGI("AngDeviceGetChipSeInfo info:%s", *info);
    return ANG_STATUS_SUCCESS;
}

int VegaMessenger::setChipSeInfo(AngPropertyID cmd, const char *value, int len) {
    ANG_LOGI("setChipSeInfo 0x%x, %s", cmd, value);
    if (len <= 0) {
        ANG_LOGE("setChipSeInfo 0x%x failed, value is empty", cmd);
    }

    //下发的数据超过1包的数据量60字节
    if(cmd == CMD_SE_UNLOCK || cmd == CMD_SE_WRITE_CONFIG || cmd == CMD_SE_SET_AUTH_SIGN) {
        return angSetLongSeInfo(cmd, value, len);
    }

    if(len <= 0 || len > MAX_PACKET_SIZE) {
        ANG_LOGE("setChipSeInfo 0x%x failed, length is over 60 bytes", cmd);
        return ANG_STATUS_CMD_PARM_ERROR;
    }
    uint32_t pnBytesReceived = 0;
    int rc = ANG_STATUS_SUCCESS;
    if(cmd == CMD_SE_SET_TIME) {
        if(len != 10) {
            ANG_LOGE("setChipSeInfo 0x%x failed, param length is wrong!", cmd);
            return ANG_STATUS_FAILED;
        }
        u_char time[8] = {0};
        LONG_TO_QW(atoll(value), time);
        rc = doSendControl(cmd, time, len, 0);
    }
    else if(cmd == CMD_SE_SET_SWITCH) {
        if(len != 1) {
            ANG_LOGE("setChipSeInfo 0x%x failed, param length is wrong!", cmd);
            return ANG_STATUS_FAILED;
        }
        u_char signature[1] = {0};
        signature[0] = atoi(value);
        rc = doSendControl(cmd, signature, len, 0);
    }
    else {
        rc = doSendControl(cmd, (uint8_t *) value, len, 0);
    }

    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("setChipSeInfo 0x%x failed, rc:%d", cmd, rc);
        return rc;
    }

    uint8_t receiveBuf[MAX_PACKET_SIZE];
    memset(receiveBuf, 0, MAX_PACKET_SIZE);
    int tryCount = 0;
    int sleepTime = 5;//ms
    int tryMaxCount = 200;

    while (tryCount < tryMaxCount) {
        memset(receiveBuf, 0, MAX_PACKET_SIZE);
        pnBytesReceived = 0;
        rc = doReceiveControl(cmd, receiveBuf, 0x3C, pnBytesReceived, 0);
        tryCount++;

        if (receiveBuf[0] != cmd || (pnBytesReceived > 0 && pnBytesReceived < 5) ) {
            ANG_LOGE("setChipSeInfo failed, rc:%d, cmd is error:0x%x", rc, receiveBuf[0]);
            return ANG_STATUS_RETURN_DATA_ERROR;
        }

        int result = DW_TO_INT(&receiveBuf[1]);
        if(result == SE_ACK) {
            ANG_LOGI("setChipSeInfo 0x%x OK, tryCount:%d", cmd, tryCount);
            return ANG_STATUS_SUCCESS;
        }

        if(result != SE_WAIT) {
            ANG_LOGE("setChipSeInfo 0x%x failed, tryCount:%d, result:%d", cmd, tryCount, result);
            return result;
        }
        // 操作未完成,继续等待再次请求
        angOSSleep(sleepTime);
    }
    ANG_LOGI("setChipSeInfo end, rc :%d, tryCount:%d", rc, tryCount);

    return ANG_STATUS_FAILED;

}

int VegaMessenger::upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) {
    ANG_LOGI("upgradeCamera cmd:0x%x", cmd);
    Mutex::Autolock _l(ota_mutex_);
    ANG_LOGI("upgradeCamera cmd:0x%x enter", cmd);
    upgrade_callback_ = callback;
    upgrade_running_ = true;
    upgrade_info_.m_upgradeCmd = cmd;
    upgrade_info_.m_upgradeFile = upgradeFile;
    int rc = upgrade_thread_->create(upgradeThread, this);
    return ANG_STATUS_SUCCESS;
}

int VegaMessenger::cancelUpgradeCamera() {
    //TODO:升级过程中不允许取消升级
    upgrade_running_ = false;
    return ANG_STATUS_NOT_SUPPORT;
}

static uint8_t PACKET_NO = 0; // 升级数据包序号
static uint8_t RETRY_COUNT = 3; //产生发送升级数据包的次数
ANG_THREAD_PROC VegaMessenger::upgradeThread(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("upgradeThread start");
    Mutex::Autolock _l(ota_mutex_);
    ANG_LOGI("upgradeThread enter");
    prctl(PR_SET_NAME, "ang-upgrade");
    auto *messenger = (VegaMessenger *) pThreadParam;
    int rc = ANG_STATUS_SUCCESS;
    uint64_t nFileSize;
    int UploadFile;
    ANG_LOGI("Start to upgrade, cmd:0x%x", messenger->upgrade_info_.m_upgradeCmd);
    ANG_LOGI("Start to upgrade, m_upgradeFile:%s", messenger->upgrade_info_.m_upgradeFile.c_str());
    rc = angOSGetFileSize64(messenger->upgrade_info_.m_upgradeFile.c_str(), &nFileSize);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("upgradeThread angOSGetFileSize64 failed, ret :%d, file:%s", rc,
                 messenger->upgrade_info_.m_upgradeFile.c_str());
        messenger->angCallbackUpgradeFailed(UPGRADE_FILE_NOT_FOUND);
        messenger->upgrade_thread_->detach();
        pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
        ANG_THREAD_PROC_RETURN(ANG_STATUS_SUCCESS);
    }

    rc = angOSOpenFile(messenger->upgrade_info_.m_upgradeFile.c_str(), ANG_OS_FILE_READ,
                       &UploadFile);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("upgradeThread angOSOpenFile failed, ret :%d", rc);
        messenger->angCallbackUpgradeFailed(UPGRADE_FILE_OPEN_FAILED);
        messenger->upgrade_thread_->detach();
        pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
        ANG_THREAD_PROC_RETURN(ANG_STATUS_SUCCESS);
    }

    uint32_t nNextOffset = 0;
    uint64_t nBefore = angOsGetTime();

    rc = messenger->angHostProtocolInitUpload(nFileSize);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angHostProtocolInitUpload failed, ret :%d", rc);
        angOSCloseFile(&UploadFile);
        messenger->angCallbackUpgradeFailed(UPGRADE_BEGIN_PACKET_SEND_FAILED);
        messenger->upgrade_thread_->detach();
        pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
        ANG_THREAD_PROC_RETURN(ANG_STATUS_SUCCESS);
    }

    uint64_t nNow = angOsGetTime();
    ANG_LOGI("Initialized upload of %llu bytes in %llu ms", nFileSize, (nNow - nBefore)/1000);

    nBefore = angOsGetTime();
    PACKET_NO = 0;
    uint8_t newProcess = 0;
    uint8_t tempNO = 0;
    RETRY_COUNT = 3;
    int percent = 0;
    int old_result = percent;
    while (nNextOffset < nFileSize) {
        rc = messenger->angHostProtocolWriteUpload(UploadFile, nNextOffset, (uint32_t) nFileSize,
                                                   nNextOffset);

        // 表示这一升级包模组已收到
        if (tempNO < PACKET_NO || (tempNO == 255 && PACKET_NO == 0)) {
            tempNO = PACKET_NO;
            RETRY_COUNT = 3;
        } else {
            RETRY_COUNT--;
        }

        // 同一包发送失败三次，不再尝试发送，升级失败
        if (RETRY_COUNT == 0) {
            ANG_LOGE("The upgrade packet was sent 3 times and failed, ret :%d", rc);
            angOSCloseFile(&UploadFile);
            messenger->angCallbackUpgradeFailed(UPGRADE_FILE_PACKET_SEND_FAILED);
            messenger->upgrade_thread_->detach();
            pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
            ANG_THREAD_PROC_RETURN(ANG_STATUS_SUCCESS);
        }

        percent = nNextOffset*100/nFileSize;
        if (old_result == percent)
            continue;
        if (percent == 100) {
            continue;
        }

        old_result = percent;
        if (percent != 99 && percent % 5 != 0)
            continue;

        // 将升级结果回调给APP层
        AngDeviceUpgradeInfo upgradeInfo;
        upgradeInfo.type = ANG_DEVICE_UPGRADE_PROGRESS;
        upgradeInfo.value = percent;
        messenger->upgrade_callback_(&upgradeInfo, nullptr);

    }

    angOSCloseFile(&UploadFile);

    nNow = angOsGetTime();
    ANG_LOGI("Uploaded %llu bytes in %llu ms", nFileSize, (nNow - nBefore)/1000);
    nBefore = angOsGetTime();

// 固件版本号的格式：vxxbxx_xxxxx，如v44b02_20210408_h
    u_char versionNO[32];
    versionNO[0] = 'v';
    sscanf(messenger->upgrade_info_.m_upgradeFile.c_str(), "%*[^v]v%[^.]", versionNO + 1);
    u_char versionNO2[16];

    angOSMemSet(versionNO2, 0, 16);
    angOSMemCopy(versionNO2, versionNO, 15);
    versionNO2[15] = '\0';
//    ANG_LOGI("versionNO2:%s", versionNO2);

    int32_t result = ANG_STATUS_SUCCESS;
    rc = messenger->angHostProtocolFinishUpload(versionNO2, result);

    // 将升级结果回调给APP层
    AngDeviceUpgradeInfo upgradeInfo;
    upgradeInfo.type = ANG_DEVICE_UPGRADE_RESULT;
    upgradeInfo.value = result;
    messenger->upgrade_callback_(&upgradeInfo, nullptr);

    nNow = angOsGetTime();
    ANG_LOGI("Finish upload of %llu bytes in %llu ms, status:%d", nFileSize, (nNow - nBefore)/1000,
             result);

    ANG_LOGI("upgradeThread end");
    messenger->upgrade_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_THREAD_PROC_RETURN(ANG_STATUS_SUCCESS);
}

int VegaMessenger::doSendControl(uint8_t nRequest, uint8_t * pBuffer, uint32_t nBufferSize, uint32_t nTimeOut) {
    Mutex::Autolock _l(usb_control_mutex_);
    if (uvc_dev_info_->type == USB_DEV) {
        uint8_t bmRequestType;
        bmRequestType = LIBUSB_REQUEST_TYPE_CLASS;
        // Out: host-to-device
        bmRequestType |= LIBUSB_ENDPOINT_OUT | LIBUSB_RECIPIENT_INTERFACE;
        int nBytesSent = libusb_control_transfer(dev_handle_, bmRequestType, nRequest, kXuValue,
                                                 kXuIndex, pBuffer, nBufferSize, nTimeOut);
        if (nBytesSent < 0)
            return ANG_STATUS_FAILED;
        return ANG_STATUS_SUCCESS;
    } else if (uvc_dev_info_->type == NET_DEV) {
        int rc = driver_->sendCmdMessage(CMD_SET, nRequest, pBuffer, nBufferSize);
        if(rc < 0) {
            return ANG_STATUS_FAILED;
        }
        return ANG_STATUS_SUCCESS;
    }
    return ANG_STATUS_FAILED;
}

int VegaMessenger::doReceiveControl(uint8_t nRequest, uint8_t * pBuffer, uint32_t nBufferSize,
                                    uint32_t& pnBytesReceived, uint32_t nTimeOut) {
    Mutex::Autolock _l(usb_control_mutex_);
    if (uvc_dev_info_->type == USB_DEV) {
        pnBytesReceived = 0;
        uint8_t bmRequestType;
        bmRequestType = LIBUSB_REQUEST_TYPE_CLASS;
        //In: device-to-host
        bmRequestType |= LIBUSB_ENDPOINT_IN | LIBUSB_RECIPIENT_INTERFACE;
        pnBytesReceived = libusb_control_transfer(dev_handle_, bmRequestType, nRequest, kXuValue,
                                                  kXuIndex, pBuffer, nBufferSize, nTimeOut);
        if(pnBytesReceived == 0) {
            ANG_LOGE("pnBytesReceived is 0");
            return ANG_STATUS_FAILED;
        }
        return ANG_STATUS_SUCCESS;
    } else if (uvc_dev_info_->type == NET_DEV) {
        pnBytesReceived = 0;
        int rc = driver_->sendCmdMessage(CMD_GET, nRequest, pBuffer, nBufferSize);
        if(rc > 0) {
            pnBytesReceived = rc;
            return ANG_STATUS_SUCCESS;
        }
        return ANG_STATUS_FAILED;
    }
    return ANG_STATUS_FAILED;
}

static int angErrorReturn(int cmd, uint8_t * receiveBuf, char **info) {
    /* 下面的cmd是返回byte[]类型，byte[]的0-3位填充模组返回的有效数据的长度，
     * 执行到该函数说明获取有效数据失败，因此len设置为0。
     * byte[]的4-7位填充错误码
     */
    if(cmd == CMD_SE_GET_UNLOCK_CMD || cmd == CMD_SE_GET_CONFIG_SM3 || cmd == CMD_SE_GET_AUTH_SIGN) {
        int len = 0;
        char len_c[4];
        INT_TO_DW(len, len_c);
        angOSMemCopy(*info, len_c, 4);
        angOSMemCopy(*info + 4, &receiveBuf[1], 4);
    }
    else {
        int result = DW_TO_INT(&receiveBuf[1]);
        char temp[17] = {'e','r','r','o','r',':'};
        angOSItoA(result, &temp[6], 10);
        angOSMemCopy(*info, temp, 17);
    }
    return ANG_STATUS_SUCCESS;
}

void VegaMessenger::angCallbackUpgradeFailed(int value) {
    // 将升级结果回调给APP层
    AngDeviceUpgradeInfo upgradeInfo;
    upgradeInfo.type = ANG_DEVICE_UPGRADE_RESULT;
    upgradeInfo.value = value;
    upgrade_callback_(&upgradeInfo, nullptr);
}


/**
 * @Description: 长数据接收接口，当返回的数据大于60字节时，会使用这个接口来获取返回数据
 * 流程：
 * 开始接收数据时, 下发req = 0x90, data[0] = 0xff , 回复 data[0] = 0x85, data[1] = 包数量(char) , data[2~6]总数据长度(int)
 * 而后 下发req = 0x90, data[0] =包序号（char)  回复 data[0] = 0x86, data[1] = 包长度(长度)， data[2~2+data[1]]
 * 为真实数据 data[2+data[1]~6+data[1]]为真实数据的校验和和 作为校验当包序号超出时，回复 data[0]=0xff
 * @param: cmd:请求的指令
 * @return: 0: 成功; 其他: 失败
 **/
int VegaMessenger::angGetLongSeInfo(AngPropertyID cmd, char **info) {

    int rc = -1;
    uint8_t data[MAX_PACKET_SIZE];
    memset(data, 0, MAX_PACKET_SIZE);
    uint32_t pnBytesReceived = 0;
    //1、下发req = 0x90, data[0] = 0xff
    data[0] = 0xff;

    rc = doSendControl(CMD_GET_LONG_SE_INFO, data, MAX_PACKET_SIZE, 0);
    if(rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("AngGetLongSeInfo doSendControl cmd 0x%x, rc:%d failed!", cmd, rc);
        return angErrorReturn(cmd, data, info);
    }

    memset(data, 0, MAX_PACKET_SIZE);
    rc = doReceiveControl(CMD_GET_LONG_SE_INFO, data, MAX_PACKET_SIZE, pnBytesReceived, 0);

    ANG_LOGI("AngGetLongSeInfo cmd 0x%x, rc:%d", cmd, rc);

    //2、回复 data[0] = 0x85, data[1] = 包数量(char) , data[2~6]总数据长度(int)
    if(data[0] != 0x85) {
        ANG_LOGE("AngGetLongSeInfo cmd 0x%x failed, data[0]:0x%x is not 0x85", cmd, data[0]);
        return angErrorReturn(cmd, data, info);
    }
    int packetCount = data[1];
    int dataTotalLen = 0;
    dataTotalLen = DW_TO_INT(&data[2]);
    ANG_LOGI("AngGetLongSeInfo get 0x%x packetCount:%d, dataTotalLen:%d", cmd, packetCount, dataTotalLen);

    //临时的接收数据buff
    u_char * content = (u_char*)angOSMalloc(sizeof(u_char)*dataTotalLen+1);
    memset(content, 0, sizeof(u_char)*dataTotalLen+1);
    for(int i=0; i< packetCount; i++) {
        memset(data, 0, MAX_PACKET_SIZE);
        pnBytesReceived = 0;

        //3、发req = 0x90, data[0] =包序号（char)
        data[0] = i;
        rc = doSendControl(CMD_GET_LONG_SE_INFO, data, MAX_PACKET_SIZE, 0);
        if(rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("doSendControl cmd 0x%x failed! rc:%d", cmd, rc);
            return angErrorReturn(cmd, data, info);
        }

        memset(data, 0, MAX_PACKET_SIZE);
        rc = doReceiveControl(CMD_GET_LONG_SE_INFO, data, MAX_PACKET_SIZE, pnBytesReceived, 0);
        ANG_LOGI("AngGetLongSeInfo get 0x%x, rc:%d", cmd, rc);
        //4、回复 data[0] = 0x86, data[1] = 包长度(长度)， data[2~2+data[1]]
        if(data[0] != 0x86) {
            ANG_LOGE("AngGetLongSeInfo cmd 0x%x, data[0]:0x%x is not 0x86", cmd, data[0]);
            return angErrorReturn(cmd, data, info);
        }

        int packetLen = data[1];
        int checkSum = DW_TO_INT(&data[2 + packetLen]);
        int checkSumbyCal = 0;
        // 有效数据校验和
        for(int i = 2; i < packetLen+2; i++) {
            checkSumbyCal = checkSumbyCal + data[i];
        }
        if(checkSum != checkSumbyCal) {
            ANG_LOGE("AngGetLongSeInfo get 0x%x, checkSum:%d and checkSumbyCal:%d is not the same", cmd, checkSum, checkSumbyCal);
            return angErrorReturn(cmd, data, info);
        }
        angOSMemCopy(content, &data[2], packetLen);
        content = content + packetLen;
    }
    content = content - dataTotalLen;
    ANG_LOGI("AngGetLongSeInfo get 0x%x success!", cmd);

    //16进制转字符串
    if(cmd == CMD_SE_GET_UNLOCK_CMD || cmd == CMD_SE_GET_CONFIG_SM3 || cmd == CMD_SE_GET_AUTH_SIGN) {
        for(int i=0;i<dataTotalLen;i++) {
            ANG_LOGD("content[%i]:%x", i, content[i]);
        }

        uint8_t len[4];
        INT_TO_DW(dataTotalLen, len);
        angOSMemCopy(info, len, 4);
        uint8_t result[4];
        INT_TO_DW(ANG_STATUS_SUCCESS, result);
        angOSMemCopy(*info + 4, result, 4);
        angOSMemCopy(*info + 8, content, dataTotalLen);
        angOSFree(content);
        return ANG_STATUS_SUCCESS;
    }
    //模组返回的是char数组
    else {
        rc = IsUtf8String(reinterpret_cast<char *>(content), sizeof(u_char)*dataTotalLen);
        if(rc != 1) {
            ANG_LOGE("AngGetLongSeInfo request cmd:0x%x, result:%s, length:%d is not UTF-8 string!", cmd, content, pnBytesReceived);
            char temp[17] = {'e','r','r','o','r',':'};
            angOSItoA(ANG_STATUS_RETURN_DATA_ERROR, &temp[6], 10);
            angOSMemCopy(*info, temp, 17);
            angOSFree(content);
            return ANG_STATUS_SUCCESS;
        }
    }

    angOSMemCopy(*info, content, dataTotalLen);
    angOSFree(content);
    return ANG_STATUS_SUCCESS;
}

/**
 * @Description: 下发Se指令内容场数据接口，下发的内容超过usb一包传输的大小60字节，采用类似升级的分包下发方案
 * @param: cmd:se指令; value:下发的内容; len: 下发内容的长度
 * @return: 0: 成功; 其他: 失败
 **/
int VegaMessenger::angSetLongSeInfo(AngPropertyID cmd, const char* value, int len) {
    SE_PACKET_NO = 0;
    uint8_t tempNO = 0;
    SE_RETRY_COUNT = 3;
    uint32_t nNextOffset = 0;
    int rc = ANG_STATUS_SUCCESS;

    ANG_LOGI("======>>>start to send init packet<<<======");
    //1、发送起始包
    uint8_t buf_init[8];
    memset(buf_init, 0, 8);
    ANG_LOGI("AngSetLongSeInfo len:%d", len);
    //起始包4字节标志位
    buf_init[0] = 0x0a;
    buf_init[1] = 0x1b;
    buf_init[2] = 0x2c;
    buf_init[3] = 0x3d;

    //起始包4字节value大小(高位在前)
    buf_init[4] = len >> 24;
    buf_init[5] = len >> 16;
    buf_init[6] = len >> 8;
    buf_init[7] = len;

    int ret = doSendControl(cmd, buf_init, 8, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("AngSetLongSeInfo send start packet failed!");
        return ret;
    }

    uint8_t receiveBuf_init[12];
    angOSMemSet(receiveBuf_init, 0, 12);

    uint32_t pnBytesReceived = 0;
    ret = doReceiveControl(CMD_HANDSHAKE, receiveBuf_init, 12, pnBytesReceived, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("AngSetLongSeInfo start packet failed to send！rc:%d", rc);
        return rc;
    }

    if(pnBytesReceived == 0) {
        ANG_LOGE("Initiation packet failed to process, pnBytesReceived == 0");
        return ANG_STATUS_FAILED;
    }

    if(receiveBuf_init[0] != ACK) {
        ANG_LOGE("Initiation packet failed to process, rc:%d", ANG_STATUS_RETURN_SE_INNER_ERROR);
        return receiveBuf_init[0];
    }

    ANG_LOGI("======>>>start to send data packet<<<======");
    //2、分包发送
    while (nNextOffset < len)
    {
        rc = angHostSeInfoSend(cmd, value, nNextOffset, (uint32_t)len, nNextOffset);

        // 表示这一升级包模组已收到
        if (tempNO < SE_PACKET_NO || (tempNO == 255 && SE_PACKET_NO == 0) ) {
            tempNO = SE_PACKET_NO;
            SE_RETRY_COUNT = 3;
        } else {
            SE_RETRY_COUNT--;
        }

        // 同一包发送失败三次，不再尝试发送，升级失败
        if(SE_RETRY_COUNT == 0) {
            ANG_LOGE("se packet was sent 3 times and failed, ret :%d", rc);
            return ANG_STATUS_SEND_DATA_PACKET_TIMEOUT;
        }
    }
    ANG_LOGI("======>>>start to send finish packet<<<======");
    //3、发送完成后发送结束包，结束包格式：结束包：4字节标志（0x0d1c2b3a）+ 1字节状态(如0x06)
    pnBytesReceived = 0;
    uint8_t buf_finish[5];
    memset(buf_finish, 0, 5);
    // 起始包4字节标志位
    buf_finish[0] = 0x0d;
    buf_finish[1] = 0x1c;
    buf_finish[2] = 0x2b;
    buf_finish[3] = 0x3a;
    // 状态码
    buf_finish[4] = ACK;

    rc = doSendControl(cmd, buf_finish, 5, 0);
    if(rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("AngSetLongSeInfo finish packet failed to send！,rc:%d",rc);
        return rc;
    }

    uint8_t receiveBuf_finish[12];
    memset(receiveBuf_finish, 0, 12);

    rc = doReceiveControl(CMD_HANDSHAKE, receiveBuf_finish, 12, pnBytesReceived, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("AngSetLongSeInfo finish packet failed to process！rc:%d", rc);
        return rc;
    }

    if(receiveBuf_finish[0] != ACK && receiveBuf_finish[0] != WAIT) {
        ANG_LOGE("AngSetLongSeInfo finish packet failed, receiveBuf[0] :%d", receiveBuf_finish[0]);
        for(int i=0; i < pnBytesReceived; i++)
            ANG_LOGE("AngSetLongSeInfo finish packet failed,receiveBuf[%d]:0x%hhx", i, receiveBuf_finish[i]);

        return receiveBuf_finish[0];
    }

    ANG_LOGI("======>>>start to check cmd status<<<======");
    //4、查询模组是否执行完指令
    int tryCount = 0;
    int sleepTime = 5;//ms
    int tryMaxCount = 200;
    uint8_t receiveBuf_check[MAX_PACKET_SIZE];
    while (tryCount < tryMaxCount) {
        memset(receiveBuf_check, 0, MAX_PACKET_SIZE);
        pnBytesReceived = 0;

        rc = doReceiveControl(cmd, receiveBuf_check, MAX_PACKET_SIZE, pnBytesReceived, 0);
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("receiveBuf_check cmd 0x%x failed, rc:%d", cmd, rc);
            return rc;
        }

        if(cmd != receiveBuf_check[0]) {
            ANG_LOGE("request cmd is not return cmd!");
            return ANG_STATUS_RETURN_DATA_ERROR;
        }

        if(pnBytesReceived < 5) {
            ANG_LOGE("return buf length is < 5");
            return ANG_STATUS_RETURN_DATA_ERROR;
        }
        //1-4是请求的状态码，int类型，总共4字节， 为9999时， 代表操作未完成， 为0时代表操作成功， 其它值为错误码
        int result = DW_TO_INT(&receiveBuf_check[1]);
        if(result == SE_ACK) {
            ANG_LOGI("AngSetLongSeInfo succeed");
            return ANG_STATUS_SUCCESS;
        }
        if(result != SE_WAIT) {
            ANG_LOGE("receiveBuf_check inner error :%d",result );
            return result;
        }
        tryCount++;
        angOSSleep(sleepTime);
    }
    ANG_LOGE("receiveBuf_check timeout 1s");
    return ANG_STATUS_FAILED;
}

int VegaMessenger::angHostSeInfoSend(int cmd, const char* value, uint32_t nOffset,
                                     uint32_t nPacketSize, uint32_t& nNextOffset)
{
    ANG_LOGI("AngHostSeInfoSend nOffset:%d,nPacketSize:%d", nOffset, nPacketSize);
    int rc = ANG_STATUS_SUCCESS;
    // 1字节包序号 + 1字节数据长度 + 1字节效验和
    uint32_t nExtraSize = 3;
    uint32_t nChunkSize = MAX_PACKET_SIZE - nExtraSize;

    //最后一包不满最大发送包大小的情况
    if(nPacketSize - nOffset < nChunkSize) {
        nChunkSize = nPacketSize - nOffset;
    } else {
        nChunkSize = MAX_PACKET_SIZE - nExtraSize;
    }

    uint32_t nBufferSize = nChunkSize + nExtraSize;

    //1字节包序号 + 1字节数据长度 + 有效数据 + 1字节效验和
    u_char buffer[MAX_PACKET_SIZE] = {0};
    uint8_t checkSum = 0;

    //升级包第一个字节是包序号：0~255，大于255再从0开始
    buffer[0] = SE_PACKET_NO;
    //升级包第二个字节是有效数据字节和校验和字节的和
    buffer[1] = nChunkSize + 1;
    angOSMemCopy(buffer+2, value+nOffset, nChunkSize);

    // 有效数据校验和
    for(int i = 2; i < nBufferSize-1; i++) {
        checkSum = checkSum + buffer[i];
    }
    buffer[nBufferSize-1] = checkSum;

    u_char * pDataBuf = (u_char*)angOSMalloc(sizeof(u_char)*nBufferSize);
    angOSMemCopy(pDataBuf, buffer, nBufferSize);

    int ret = doSendControl(cmd, pDataBuf, nBufferSize, 0);

    angOSFree(pDataBuf);

    uint8_t receiveBuf[12];
    angOSMemSet(receiveBuf, 0, 12);

    uint32_t pnBytesReceived = 0;

    ret = doReceiveControl(CMD_HANDSHAKE, receiveBuf, 0x0C, pnBytesReceived, 0);

    if(receiveBuf[0] != ACK) {
        for(int i=0; i < pnBytesReceived; i++)
            ANG_LOGE("Send se data packet failed,receiveBuf[%d]:0x%hhx", i, receiveBuf[i]);

        return receiveBuf[0];
    }

    nNextOffset = nNextOffset + nChunkSize;
    SE_PACKET_NO++;
    return ANG_STATUS_SUCCESS;
}

int VegaMessenger::angHostProtocolInitUpload(uint32_t nFileSize) {
    int rc = ANG_STATUS_SUCCESS;
    uint8_t buf[64];
    memset(buf, 0, 64);
    ANG_LOGI("angHostProtocolInitUpload nFileSize:%u", nFileSize);
    //起始包4字节标志位
    buf[0] = 0x0a;
    buf[1] = 0x1b;
    buf[2] = 0x2c;
    buf[3] = 0x3d;

    //起始包4字节升级文件大小(高位在前)
    buf[4] = nFileSize >> 24;
    buf[5] = nFileSize >> 16;
    buf[6] = nFileSize >> 8;
    buf[7] = nFileSize;

    int ret = doSendControl(getAngUpgradeInfo().m_upgradeCmd, buf, 8, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angHostProtocolInitUpload send failed!");
        return ANG_STATUS_FAILED;
    }

    uint8_t receiveBuf[64];
    memset(receiveBuf, 0, 64);

    uint32_t pnBytesReceived = 0;
    ret = doReceiveControl(CMD_HANDSHAKE, receiveBuf, 12, pnBytesReceived, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("Upgrade firmware start packet failed to send！");
        return ANG_STATUS_FAILED;
    }

    if (receiveBuf[0] != ACK) {
        ANG_LOGE("Upgrade firmware start packet failed to process");
        for (int i = 0; i < pnBytesReceived; i++)
            ANG_LOGE("Initiation packet delivery failed,receiveBuf[%d]:0x%hhx", i, receiveBuf[i]);
        return ANG_STATUS_FAILED;
    }

    if (rc < 0)
        return ANG_STATUS_FAILED;

    return ANG_STATUS_SUCCESS;
}

int VegaMessenger::angHostProtocolWriteUpload(int &FileToUpload, uint32_t nOffset, uint32_t nFileSize,
                                          uint32_t &nNextOffset) {

    // 1字节包序号 + 1字节数据长度 + 1字节效验和
    uint32_t nExtraSize = 3;
    uint32_t nChunkSize = 0;
    uint32_t max_packet_size = MAX_PACKET_SIZE;
    if (uvc_dev_info_->type == NET_DEV)
        max_packet_size = UDP_MAX_OTA_PACKET_SIZE;

    nChunkSize = max_packet_size - nExtraSize;

    //最后一包不满最大发送包大小的情况
    if (nFileSize - nOffset < nChunkSize) {
        nChunkSize = nFileSize - nOffset;
    } else {
        nChunkSize = max_packet_size - nExtraSize;
    }

    uint32_t nBufferSize = nChunkSize + nExtraSize;

    //1字节包序号 + 1字节数据长度 + 有效数据 + 1字节效验和
    u_char buffer[max_packet_size];
    memset(buffer, 0, max_packet_size);
    uint8_t checkSum = 0;

    //升级包第一个字节是包序号：0~255，大于255再从0开始
    buffer[0] = PACKET_NO;
    //升级包第二个字节是有效数据字节和校验和字节的和
    buffer[1] = nChunkSize + 1;

    int rc = angOSSeekFile64(FileToUpload, ANG_OS_SEEK_SET, nNextOffset);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("xnOSSeekFile fail");
        return ANG_STATUS_FAILED;
    }

    rc = angOSReadFile(FileToUpload, buffer + 2, &nChunkSize);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("angOSReadFile fail");
        return ANG_STATUS_FAILED;
    }

    // 有效数据校验和
    for (int i = 2; i < nBufferSize - 1; i++) {
        checkSum = checkSum + buffer[i];
    }
    buffer[nBufferSize - 1] = checkSum;

    u_char *pDataBuf = (u_char *) angOSMalloc(sizeof(u_char) * nBufferSize);
    angOSMemCopy(pDataBuf, buffer, nBufferSize);

    int ret = doSendControl(getAngUpgradeInfo().m_upgradeCmd, pDataBuf, nBufferSize, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("send upgrade file packet failed!");
        angOSFree(pDataBuf);
        return ANG_STATUS_FAILED;
    }

    angOSFree(pDataBuf);

    uint8_t receiveBuf[64];
    memset(receiveBuf, 0, 64);

    uint32_t pnBytesReceived = 0;

    ret = doReceiveControl(CMD_HANDSHAKE, receiveBuf, 0x0C, pnBytesReceived, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("get the result of sending upgrade file packet failed!");
        return ANG_STATUS_FAILED;
    }

    if (receiveBuf[0] != ACK) {
        ANG_LOGE("Send upgrade data packet failed, pnBytesReceived:%d", pnBytesReceived);
        for (int i = 0; i < pnBytesReceived; i++)
            ANG_LOGE("Send upgrade data packet failed,receiveBuf[%d]:0x%hhx", i, receiveBuf[i]);

        return ANG_STATUS_FAILED;
    }

    nNextOffset = nNextOffset + nChunkSize;
    PACKET_NO++;

    return ANG_STATUS_SUCCESS;
}

int VegaMessenger::angHostProtocolFinishUpload(u_char *versionNo, int32_t &pUpgradeResult) {
    int rc = ANG_STATUS_SUCCESS;

    uint32_t pnBytesReceived = 0;

    uint8_t buf[64];
    memset(buf, 0, 64);

    // 起始包4字节标志位
    buf[0] = 0x0d;
    buf[1] = 0x1c;
    buf[2] = 0x2b;
    buf[3] = 0x3a;
    // 状态码
    buf[4] = ACK;

    // 固件升级包发送完成后发送结束包，结束包格式：结束包：4字节标志（0x0d1c2b3a）+ 1字节状态(如0x06)
    rc = doSendControl(getAngUpgradeInfo().m_upgradeCmd, buf, 5, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("Upgrade firmware finish packet failed to send！,rc:%d", rc);
        pUpgradeResult = UPGRADE_FINISH_PACKET_FAILED;
        return ANG_STATUS_FAILED;
    }
    uint8_t receiveBuf[64];
    angOSMemSet(receiveBuf, 0, 64);

    rc = doReceiveControl(CMD_HANDSHAKE, receiveBuf, 12, pnBytesReceived, 0);
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("Upgrade firmware finish packet failed to process！rc:%d", rc);
        pUpgradeResult = UPGRADE_FINISH_PACKET_FAILED;
        return ANG_STATUS_FAILED;
    }

    if (receiveBuf[0] != ACK && receiveBuf[0] != WAIT) {
        ANG_LOGE("Send upgrade finish packet failed, receiveBuf[0] :%d", receiveBuf[0]);
        for (int i = 0; i < pnBytesReceived; i++)
            ANG_LOGE("Send upgrade finish packet failed,receiveBuf[%d]:0x%hhx", i, receiveBuf[i]);

        pUpgradeResult = UPGRADE_FINISH_PACKET_FAILED;
        return ANG_STATUS_FAILED;
    }

    // 查询模组刷固件到flash的进度
    // 返回结果：状态+类型+进度+错误
    uint8_t receiveUpgradeBuf[64];
    memset(receiveUpgradeBuf, 0, 64);
    AngDeviceUpgradeInfo upgradeInfo;

    uint8_t progress = 0;

    while (true) {
        rc = doReceiveControl(CMD_HANDSHAKE, receiveUpgradeBuf, 4, pnBytesReceived, 0);
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("Failed to get upgrade progress, rc:%d", rc);
            pUpgradeResult = UPGRADE_CAMERA_MODULE_FIRMWARE_FAILED;
            return ANG_STATUS_FAILED;
        }

        if (receiveUpgradeBuf[3] != 0) {
            ANG_LOGE("Camera module firmware upgrade failed , error code: %d",
                     receiveUpgradeBuf[3]);
            pUpgradeResult = UPGRADE_CAMERA_MODULE_FIRMWARE_FAILED;
            return ANG_STATUS_FAILED;
        }

//        if (progress != receiveUpgradeBuf[2]) {
//            // 将升级进度回调给APP层
//            progress = receiveUpgradeBuf[2];
//            upgradeInfo.type = ANG_DEVICE_UPGRADE_PROGRESS;
//            upgradeInfo.value = progress;
//            upgrade_callback_(&upgradeInfo, nullptr);
//        }

        // 固件升级成功，升级进度100%
        if (receiveUpgradeBuf[2] == 100) {
            upgradeInfo.type = ANG_DEVICE_UPGRADE_PROGRESS;
            upgradeInfo.value = 100;
            upgrade_callback_(&upgradeInfo, nullptr);
            break;
        }


        angOSSleep(500);
    }

    if (getAngUpgradeInfo().m_upgradeCmd == CMD_UPCODE) {
        // 升级成功后写入新的固件版本号
        rc = doSendControl(CMD_FW_VER, versionNo, 23, 0);
        //读版本号
        uint8_t receiveVersionBuf[MAX_PACKET_SIZE];
        memset(receiveVersionBuf, 0, MAX_PACKET_SIZE);

        rc = doReceiveControl(CMD_FW_VER, receiveVersionBuf, MAX_PACKET_SIZE, pnBytesReceived, 0);
        ANG_LOGI("Query firmware version number:%s", receiveVersionBuf + 1);
        if (rc != ANG_STATUS_SUCCESS) {
            ANG_LOGE("Query firmware version failed");
        }
    }

    return ANG_STATUS_SUCCESS;
}

static int handleCameraIP(uint8_t* value, uint32_t& receiveDataSize) {
    if (!value) {
        ANG_LOGE("handleCameraIP failed, value is null");
        return ANG_STATUS_FAILED;
    }

    uint8_t buf[MAX_PACKET_SIZE];
    memset(buf, 0, MAX_PACKET_SIZE);
    memcpy(buf, value, receiveDataSize);
    memset(value, 0, receiveDataSize);
    clearHeadTailSpace(buf);
    std::string ip_str((char*)buf);
    std::string key = "inet_addr:";
    int index = ip_str.find(key);
    if (index > 0) {
        std::string ip = ip_str.substr(index + key.size());
        memcpy(value, ip.c_str(), ip.size());
        receiveDataSize = ip.size();
        return ANG_STATUS_SUCCESS;
    } else {
        ANG_LOGE("handleCameraIP failed, ip format error:%s", ip_str.c_str());
        return ANG_STATUS_FAILED;
    }
}

static int handleCameraMacAddr(uint8_t* value, uint32_t& receiveDataSize) {
    if (!value) {
        ANG_LOGE("handleCameraMacAddr failed, value is null");
        return ANG_STATUS_FAILED;
    }

    uint8_t buf[MAX_PACKET_SIZE];
    memset(buf, 0, MAX_PACKET_SIZE);
    memcpy(buf, value, receiveDataSize);
    memset(value, 0, receiveDataSize);
    clearHeadTailSpace(buf);
    std::string mac_str((char*)buf);
    std::string key = "dr:";
    int index = mac_str.find(key);
    if (index > 0) {
        std::string mac = mac_str.substr(index + key.size());
        memcpy(value, mac.c_str(), mac.size());
        receiveDataSize = mac.size();
        return ANG_STATUS_SUCCESS;
    } else {
        ANG_LOGE("handleCameraMacAddr failed, mac format error, index:%d, mac:%s", index, mac_str.c_str());
        return ANG_STATUS_FAILED;
    }
}

static int handleCameraDHCPEnable(uint8_t* value, uint32_t& receiveDataSize) {
    if (!value) {
        ANG_LOGE("handleCameraDHCPEnable failed, value is null");
        return ANG_STATUS_FAILED;
    }

    uint8_t buf[MAX_PACKET_SIZE];
    memset(buf, 0, MAX_PACKET_SIZE);
    memcpy(buf, value, receiveDataSize);
    memset(value, 0, receiveDataSize);
    if (buf[0] == '1') {
        memcpy(value, "1", 1);
    } else if (buf[0] == '0') {
        memcpy(value, "0", 1);
    } else {
        ANG_LOGE("handleCameraDHCPEnable failed, value:%x", value[0]);
        return ANG_STATUS_FAILED;
    }

    receiveDataSize = 1;
    return ANG_STATUS_SUCCESS;
}

static int handleCameraTelnetEnable(uint8_t* value, uint32_t& receiveDataSize) {
    if (!value) {
        ANG_LOGE("handleCameraTelnetEnable failed, value is null");
        return ANG_STATUS_FAILED;
    }

    uint8_t buf[MAX_PACKET_SIZE];
    memset(buf, 0, MAX_PACKET_SIZE);
    memcpy(buf, value, receiveDataSize);
    memset(value, 0, receiveDataSize);
    if (buf[0] == '1') {
        memcpy(value, "1", 1);
    } else if (buf[0] == '0') {
        memcpy(value, "0", 1);
    } else {
        ANG_LOGE("handleCameraTelnetEnable failed, value:%x", value[0]);
        return ANG_STATUS_FAILED;
    }

    receiveDataSize = 1;
    return ANG_STATUS_SUCCESS;
}