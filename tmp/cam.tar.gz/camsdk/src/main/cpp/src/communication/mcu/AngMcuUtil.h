/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_MCU_UTIL_H_
#define _ANG_MCU_UTIL_H_

#include "AngLog.hpp"
#include "AngUtil.h"

#include "IspCmdTool.h"

// MCU升级失败code
static const int STATUS_FAILED_NO_UVC_DEV = -1000;//没找到UVC设备
static const int STATUS_FAILED_OPEN_MCU_DEV = -1001;//打开MCU设备失败
static const int STATUS_FAILED_INSMOD_MCU_DRIVER = -1002;//加载MCU驱动失败
static const int STATUS_FAILED_RMMOD_MCU_DRIVER = -1003;//卸载MCU驱动失败
static const int STATUS_FAILED_MCU_DEV_LOST = -1004;//找不到MCU设备
static const int STATUS_FAILED_ENTER_LOADER = -1005;//进入升级模式失败
static const int STATUS_FAILED_CHMOD_CH37X = -1006;//修改/dev/ch37x权限失败
static const int STATUS_FAILED_QINHENG_READ_TYPE = -1007;//沁恒读取MCU芯片类型失败
static const int STATUS_FAILED_QINHENG_SET_ISP_OPTION = -1008;//沁恒设置属性接口失败
static const int STATUS_FAILED_QINHENG_ISP_DEV_NOT_FOUND = -1009;//沁恒遍历MCU设备接口失败
static const int STATUS_FAILED_QINHENG_DOWNLOAD = -1010;//沁恒MCU下载接口失败

static const std::string MCU_DRIVER_NAME = "ch37x";

static int chmodCh37x() {
    std::vector<std::string> ch37x_v;
    findDev(ch37x_v, "ch37x");
    for (int i = 0; i < ch37x_v.size(); ++i) {
        std::string cmd = "su -c \"chmod 777 " + ch37x_v[i] + "\"";
        ANG_LOGI("chmodCh37x cmd: %s", cmd.c_str());
        int rc = ang_system(cmd.c_str());
        if (rc != 0) {
            ANG_LOGE("chmodCh37x cmd failed, errno:%d", errno);
            return ANG_STATUS_FAILED;
        }
    }
    if (ch37x_v.empty()) {
        ANG_LOGE("chmodCh37x empty");
        return ANG_STATUS_FAILED;
    } else {
        return ANG_STATUS_SUCCESS;
    }

}

static int rmmodMCUDriver() {
    int rc = ANG_STATUS_SUCCESS;
    std::string cmd = "su -c \"rmmod " + MCU_DRIVER_NAME + "\"";
    ANG_LOGI("rmmodMCUDriver cmd: %s", cmd.c_str());
    rc = ang_system(cmd.c_str());
    if (rc != 0) {
        ANG_LOGE("rmmodMCUDriver cmd failed, errno:%d", errno);
        return STATUS_FAILED_RMMOD_MCU_DRIVER;
    }
    return rc;
}

static int insmodMCUDriver(const char *mcuDriverPath) {
    int rc = ANG_STATUS_SUCCESS;
    rc = rmmodMCUDriver();
    std::string temp_path = mcuDriverPath;
    std::string cmd = "su -c \"insmod " + temp_path + "\"";
    ANG_LOGI("insmodMCUDriver cmd: %s", cmd.c_str());
    rc = ang_system(cmd.c_str());
    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("insmodMCUDriver cmd failed, errno:%d", errno);
        return STATUS_FAILED_INSMOD_MCU_DRIVER;
    }
    return rc;
}

static int doMCUDownLoad(char *upgradeFilePath) {
    ANG_LOGI("doMCUDownLoad: upgradeFilePath=%s", upgradeFilePath);
    int ret = ANG_STATUS_SUCCESS;

    sleep(1);
    ret = chmodCh37x();
    if (ret == ANG_STATUS_FAILED) {
        ANG_LOGE("chmodCh37x failure, try again!");
        sleep(1);
        ret = chmodCh37x();
    }
    if (ret == ANG_STATUS_FAILED) {
        ANG_LOGE("chmodCh37x failure!");
        return STATUS_FAILED_CHMOD_CH37X;
    }

    //1.沁恒V1.11版本
    /*unsigned short rlen = 10;
    unsigned char rbuf[256];
    ret = ISPDataFlashRead(0, 0, &rlen, rbuf);
    if (ret == 0) {
        ANG_LOGE("doMCUDownLoad: ISPDataFlashRead fail...!");
        return STATUS_FAILED;
    } else {
        for (int i = 0; i < rlen; i++){
            ANG_LOGI("doMCUDownLoad: rbuf[%d]: 0x%2x", i, rbuf[i]);
        }
    }

    unsigned char chiptype, chipseries;
    ret = ISPMcuTypeRead(0, &chiptype, &chipseries);
    if (ret == 0) {
        ANG_LOGE("doMCUDownLoad: ISPMcuTypeRead failed.");
        return STATUS_FAILED_QINHENG_READ_TYPE;
    } else {
        ANG_LOGI("doMCUDownLoad: MCU chiptype: 0x%2x, chipseries: 0x%2x", chiptype, chipseries);
    }

    Load_Config(chiptype);

    ret = WCH55x_SetIspOption(upgradeFilePath, 0, chiptype, true);
    if (ret) {
        ANG_LOGI("doMCUDownLoad: Set isp option success!");
    } else {
        ANG_LOGE("doMCUDownLoad: Set isp option failure ret:%d", ret);
        return STATUS_FAILED_QINHENG_SET_ISP_OPTION;
    }

    int num = EnumIspDeviceProc(0);
    if (num == 0) {
        ANG_LOGE("doMCUDownLoad: No isp device...!");
        return STATUS_FAILED_QINHENG_ISP_DEV_NOT_FOUND;
    } else {
        ANG_LOGI("doMCUDownLoad: enum devices num: %d", num);
    }

    ret = ISPFlashDnThread_CH55xUSB((void *) 0);
    if (!ret) {
        ANG_LOGI("doMCUDownLoad: Download success!");
    } else {
        ANG_LOGE("doMCUDownLoad: Download failed, ret: %d", ret);
        return STATUS_FAILED_QINHENG_DOWNLOAD;
    }*/

    //2.沁恒V1.10版本
    ret = startMcuUpgrade(upgradeFilePath);
    return ret;
}

#endif //_ANG_MCU_UTIL_H_
