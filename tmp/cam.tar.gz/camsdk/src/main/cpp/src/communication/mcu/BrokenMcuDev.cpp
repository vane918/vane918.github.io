/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "BrokenMcuDev.h"
#include "SonixCamera.h"

using namespace ang;

BrokenMcuDev::BrokenMcuDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid, AngBurnType burn_type) :
                           McuDevBase(descriptor, uid, burn_type),
                           UsbDevBase(descriptor, uid){
}

BrokenMcuDev::~BrokenMcuDev() {
}

int BrokenMcuDev::upgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath){
    ANG_LOGI("upgradeMcuDevice: BrokenMcuDev mcu_uid:%s, burn_type:%d", mcu_uid_.c_str(), burn_type_);
    Mutex::Autolock _l(ang_mutex_);
    int rc = ANG_STATUS_SUCCESS;
    if (burn_type_ == BURN_TYPE_BROKEN_BOOT_NEW) { // 新的变砖升级方式：自研boot
        rc = doUpgradeMcuDevice_new(upgradeFilePath);
    } else if (burn_type_ == BURN_TYPE_BROKEN_BOOT_OLD){  // 旧的变砖升级方式：沁恒boot
        rc = enterMcuLoaderMode();
        ANG_LOGI("upgradeMcuDevice: enterMcuLoaderMode, rc=%d", rc);
        if (rc == ANG_STATUS_SUCCESS) {
            rc = doUpgradeMcuDevice(upgradeFilePath, mcuDriverPath);
            ANG_LOGI("upgradeMcuDevice: doUpgradeMcuDevice, rc=%d", rc);
            int rc2 = exitLoadMode();
            ANG_LOGI("upgradeMcuDevice: exitLoadMode, rc=%d", rc2);
            rc += rc2;
            //升级完成后2s MCU会重启
            if (ANG_STATUS_SUCCESS == rc) sleep(2);
        } else {
            ANG_LOGE("upgradeMcuDevice: enterMcuLoaderMode failed, rc=%d", rc);
            rc = ANG_STATUS_FAILED;
        }
    } else {
        ANG_LOGE("upgradeMcuDevice: BrokenMcuDev failed, burn_type=%d", burn_type_);
        rc =  ANG_STATUS_FAILED;
    }
    return rc;
}

int BrokenMcuDev::enterMcuLoaderMode() {
    ANG_LOGI("enterMcuLoaderMode: %s", video_path_.c_str());

    char videoIndex[16] = {0};
    memcpy(videoIndex, video_path_.c_str(), 11);
    if (access(videoIndex, W_OK) != 0) {
        ANG_LOGE("enterMcuLoaderMode: device=%s is not access!", videoIndex);
        return ANG_STATUS_FAILED;
    }
    if (TRUE != SonixCam_Init(videoIndex)) {
        ANG_LOGE("enterMcuLoaderMode: could not find/open sonix device");
        SonixCam_UnInit();
        return ANG_STATUS_FAILED;
    }

    sleep(1);
    unsigned char pData0[1] = {0x00};
    SonixCam_AsicRegisterWrite(0x8201, pData0, 1);

    usleep(500000);
    unsigned char pData1[1] = {0x02};
    SonixCam_AsicRegisterWrite(0x8201, pData1, 1);

    usleep(500000);
    unsigned char pData2[1] = {0x03};
    SonixCam_AsicRegisterWrite(0x8201, pData2, 1);

    usleep(500000);
    unsigned char pData3[1] = {0x01};
    SonixCam_AsicRegisterWrite(0x8201, pData3, 1);

    usleep(200000);
    unsigned char pData4[1] = {0x00};
    SonixCam_AsicRegisterWrite(0x8201, pData4, 1);

    sleep(1);
    unsigned char pData[1] = {0};
    int rc = SonixCam_AsicRegisterRead(0x8201, pData, 1);
    ANG_LOGI("enterMcuLoaderMode: rc=%d, %x", rc, pData[0]);

    SonixCam_UnInit();

    return (rc && pData[0] == 0x00) ? ANG_STATUS_SUCCESS : ANG_STATUS_FAILED;
}

int BrokenMcuDev::exitLoadMode() {
    ANG_LOGI("exitLoadMode: %s", video_path_.c_str());

    char videoIndex[16] = {0};
    memcpy(videoIndex, video_path_.c_str(), 11);
    if (access(videoIndex, W_OK) != 0) {
        ANG_LOGE("device:%s is not access!", videoIndex);
        return ANG_STATUS_FAILED;
    }
    if (TRUE != SonixCam_Init(videoIndex)) {
        ANG_LOGE("Could not find/open sonix device");
        SonixCam_UnInit();
        return ANG_STATUS_FAILED;
    }

    sleep(1);
    unsigned char pData1[1] = {0};
    pData1[0] = 0x02;
    SonixCam_AsicRegisterWrite(0x8201, pData1, 1);

    sleep(1);
    unsigned char pData2[1] = {0};
    pData2[0] = 0x00;
    SonixCam_AsicRegisterWrite(0x8201, pData2, 1);

    sleep(1);
    unsigned char pData[1] = {0};
    int rc = SonixCam_AsicRegisterRead(0x8201, pData, 1);
    ANG_LOGI("exitLoadMode: rc=%d, %x", rc, pData[0]);

    SonixCam_UnInit();

    return (rc && pData[0] == 0x00) ? ANG_STATUS_SUCCESS : ANG_STATUS_FAILED;
}