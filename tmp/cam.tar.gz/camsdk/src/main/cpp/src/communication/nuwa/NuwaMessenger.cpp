/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "NuwaMessenger.h"
#include "Mutex.h"
#include "McuDevBase.h"
#include "UsbDevBase.h"
#include "UsbMcuDev.h"
#include "UsbUvcDev.h"
#include "BurnModeMcuDev.h"
#include "BrokenMcuDev.h"
#include "UartMcuDev.h"

using namespace ang;

NuwaMessenger::NuwaMessenger(std::shared_ptr<AngDescriptor> descriptor,
                             std::shared_ptr<AngDevInfo> uvc_info, long usbHandle,
                             std::shared_ptr<Driver> driver) :
        Messenger(descriptor, uvc_info, usbHandle, driver),
        upgrade_thread_(std::make_shared<AngThread>()), fd_(usbHandle){
        std::string uvc_uid = uvc_info->usb.uid;
    ANG_LOGI("NuwaMessenger uvc_uid:%s", uvc_uid.c_str());
    AngBurnType burnType = BURN_TYPE_UNKNOWN;
    auto deviceDescriptors = descriptor->getUsbDeviceDescriptors();
    for (auto &dev : *deviceDescriptors) {
        if (dev->getAngDevInfo()->usb.uid == uvc_uid) {
            //uvc_uid正常来说是uvc的uid，但如果是mcu的uid，说明此刻没有ISP存在，设备已变砖
            //设备变砖, 使用沁恒的boot, MCU设备(4348:55e0)没在, ISP存在, 可以通过ISP强制进入烧录模式
            if (checkAngMcuDev(uvc_uid)) {
                burnType = BURN_TYPE_BROKEN_BOOT_OLD;
                mcu_dev_base_ = std::make_unique<BrokenMcuDev>(descriptor, uvc_uid, burnType);
                break;
            }
            else {
                auto mcu_devpath = getDevPath(dev->getAngDevInfo()->usb.devpath, descriptor);
                auto mcu_uid = getDevUid(dev->getAngDevInfo()->usb.devpath, descriptor);
                burnType = getDevBurnMode(mcu_uid);
                if (checkBurnModeDev(mcu_uid)) {
                    burnType = BURN_TYPE_BURN_MODE;
                    mcu_dev_base_ = std::make_unique<BurnModeMcuDev>(descriptor, mcu_uid, burnType);
                }
                else if (checkUartDev(mcu_uid)) {
                    burnType = BURN_TYPE_NORMAL;
                    mcu_dev_base_ = std::make_unique<UartMcuDev>(descriptor, mcu_uid, burnType);
                }
                else {
                    burnType = BURN_TYPE_NORMAL;
                    mcu_dev_base_ = std::make_unique<UsbMcuDev>(descriptor, mcu_uid, burnType);
                    mcu_dev_base_->openDevice(fd_);
                }
            }
        }
    }
}

NuwaMessenger::~NuwaMessenger() {
    if (mcu_dev_base_)
        mcu_dev_base_->closeDevice();
}

int NuwaMessenger::getFirmwareInfo(AngPropertyID propertyId, char **info) {
    return ANG_STATUS_NOT_SUPPORT;
}

int NuwaMessenger::setFirmwareInfo(AngPropertyID propertyId, const char *value, int len) {
    return ANG_STATUS_NOT_SUPPORT;
}

int NuwaMessenger::getChipSeInfo(AngPropertyID propertyId, char **info) {
    return ANG_STATUS_NOT_SUPPORT;
}

int NuwaMessenger::setChipSeInfo(AngPropertyID propertyId, const char *value, int len) {
    return ANG_STATUS_NOT_SUPPORT;
}

int NuwaMessenger::upgradeCamera(int cmd, const char* upgradeFile, DeviceOnUpgradeCallback callback) {
    return ANG_STATUS_NOT_SUPPORT;
}

int NuwaMessenger::cancelUpgradeCamera() {
    return ANG_STATUS_NOT_SUPPORT;
}

int NuwaMessenger::communicateWithDevice(char **value, int &len) {
    if (!mcu_dev_base_)
        return ANG_STATUS_FAILED;
    return mcu_dev_base_->communicateWithDevice(value, len);
}