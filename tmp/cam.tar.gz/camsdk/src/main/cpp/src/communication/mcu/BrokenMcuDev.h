/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _BROKEN_MCU_DEV_H_
#define _BROKEN_MCU_DEV_H_

#include <Mutex.h>
#include "McuDevBase.h"
#include "UsbDevBase.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

class BrokenMcuDev :
        public McuDevBase, UsbDevBase{
public:
    BrokenMcuDev(std::shared_ptr<AngDescriptor> descriptor, std::string uid, AngBurnType burn_type);
    virtual ~BrokenMcuDev();

    int communicateWithDevice(char **value, int &len){return ANG_STATUS_NOT_SUPPORT;}

    int openDevice(int fd) {return ANG_STATUS_NOT_SUPPORT;}

    int closeDevice(){return ANG_STATUS_NOT_SUPPORT;}

    /**
     * @Description: 固件升级，如himax、标定文件等
     * @param:upgradeFile：升级文件绝对路径
     * info：需要升级的指令，表示升级的类型，如himax；
     * @return: 0: 成功; 其他: 失败
     **/
    int upgradeFirmware(const std::string &upgradeFile, const std::string &info){return ANG_STATUS_NOT_SUPPORT;}

    /**
     * @Description: MCU升级，耗时操作，需要调用方在子线程调用该接口进行MCU升级。
     * upgradeFilePath：MCU升级文件的绝对路径； mcuDriverPath：MCU沁恒驱动的绝对路径
     * @return: 0: 成功; 其他: 失败，具体失败值见本头文件上面的相关的失败项说明
     **/
    virtual int upgradeMcuDevice(const std::string &upgradeFilePath, const std::string &mcuDriverPath) override;

    std::string getMcuVersion(){return UNKNOWN_STATUS;}

    std::string getHiMaxVersion(){return UNKNOWN_STATUS;}

    int setInsideOutsideParam(){return ANG_STATUS_NOT_SUPPORT;}

private:
    Mutex ang_mutex_;
    virtual int enterMcuLoaderMode() override;
    int exitLoadMode();
};

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_BROKEN_MCU_DEV_H_