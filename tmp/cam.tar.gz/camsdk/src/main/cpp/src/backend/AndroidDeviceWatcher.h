/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANDROID_DEVICE_WATCHER_H_
#define _ANDROID_DEVICE_WATCHER_H_

#include <memory>
#include <atomic>
#include <unordered_map>

#include "AngTypes.h"
#include "AngDefines.h"
#include "AngThread.hpp"
#include "Backend.h"
#include "Mutex.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN


class AndroidDeviceWatcher : public DeviceWatcher {

public:
    AndroidDeviceWatcher();
    ~AndroidDeviceWatcher();

    int registerCallback(void* ptr, deviceChangedCallback callback) override;

    int unregisterCallback(void* ptr) override;

    int start() override;

    int stop() override;

    bool is_stopped() const override;

    std::unordered_map<void*, deviceChangedCallback> callbacks_;

private:
    std::shared_ptr<AngThread> hotPlug_thread_{nullptr};

    std::atomic<bool> running_;

    static ANG_THREAD_PROC hotPlugThread(ANG_THREAD_PARAM pThreadParam);


};

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANDROID_DEVICE_WATCHER_H_
