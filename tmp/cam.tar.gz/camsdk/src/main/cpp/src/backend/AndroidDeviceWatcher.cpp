/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/prctl.h>
#include <errno.h>
#include <string>

#include "AngThread.hpp"
#include "AngLog.hpp"

#include "AndroidDeviceWatcher.h"

using namespace ang;

static const int UEVENT_MSG_LEN = 1024;

static int uevent_fd = -1;

Mutex mutex_;

struct ang_uevent {
    const char *action;
    const char *path;
    const char *devname;
    const char *product;
    int busnum;
    int devnum;
};

static int initUevent() {
    struct sockaddr_nl addr;
    int sz = 64 * 1024;
    int s;
    ANG_LOGI("%s", "init_socket");
    memset(&addr, 0, sizeof(addr));
    addr.nl_family = AF_NETLINK;
    addr.nl_pid = getpid();
    addr.nl_groups = 0xffffffff;

    s = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    if (s < 0) {
        ANG_LOGE("socket error:%d", errno);
        return -1;
    }

    setsockopt(s, SOL_SOCKET, SO_RCVBUFFORCE, &sz, sizeof(sz));

    if (bind(s, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        close(s);
        ANG_LOGE("bind error:%d", errno);
        return -1;
    }
    return s;
}

static void doConnectStatusCallback(AndroidDeviceWatcher * watcher, struct ang_uevent *event) {
    if (event->busnum > 0 && event->devnum > 0) {
        std::string path = event->path;
        int index = path.find_last_of("/");
        if (index > 0) {
            path = path.substr(index+1);
        }

        AngDevInfo devInfo;
        devInfo.usb.bus = std::to_string(event->busnum);
        devInfo.usb.dev = std::to_string(event->devnum);
        devInfo.usb.devpath = path;
        devInfo.usb.uid = event->devname;
        std::string str = event->product;
        size_t pos = 0;
        std::string token;
        pos = str.find('/');
        token = str.substr(0, pos);
        devInfo.usb.vid = token;
        pos = str.find('/', pos + 1);
        token = str.substr(str.find('/') + 1, pos - str.find('/') - 1);
        devInfo.usb.pid = token;

        for (auto it : watcher->callbacks_) {
            it.second(it.first, std::string(event->action), devInfo);
        }
    }
}

static void parseUevent(AndroidDeviceWatcher * watcher, const char *msg, struct ang_uevent *event) {
    event->action = "";
    event->path = "";
    event->devname = "";
    event->product = "";
    event->busnum = -1;
    event->devnum = -1;
    while (*msg) {
        if (!strncmp(msg, "ACTION=", 7)) {
            msg += 7;
            event->action = msg;
        } else if (!strncmp(msg, "DEVPATH=", 8)) {
            msg += 8;
            event->path = msg;
        } else if (!strncmp(msg, "DEVNAME=", 8)) {
            msg += 8;
            event->devname = msg;
        } else if (!strncmp(msg, "PRODUCT=", 8)) {
            msg += 8;
            event->product = msg;
        } else if (!strncmp(msg, "BUSNUM=", 7)) {
            msg += 7;
            event->busnum = atoi(msg);
        } else if (!strncmp(msg, "DEVNUM=", 7)) {
            msg += 7;
            event->devnum = atoi(msg);
        }

        while (*msg++);
    }
//    ANG_LOGI("event { action:%s, devpath:%s, devname:%s, product:%s, busnum:%d, devnum:%d }",
//             event->action, event->path, event->devname, event->product, event->busnum,
//             event->devnum);

    doConnectStatusCallback(watcher, event);
}

AndroidDeviceWatcher::AndroidDeviceWatcher() :
    hotPlug_thread_(std::make_shared<AngThread>()), running_(false) {
    callbacks_.clear();
}

AndroidDeviceWatcher::~AndroidDeviceWatcher() {

}

ANG_THREAD_PROC AndroidDeviceWatcher::hotPlugThread(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("hotPlugThread start");
    prctl(PR_SET_NAME, "ang-hot-plug");
    auto *watcher = (AndroidDeviceWatcher *) pThreadParam;
    int n;
    char msg[UEVENT_MSG_LEN + 2];
    uevent_fd = initUevent();

    if (uevent_fd < 0) {
        ANG_LOGE("fail to init uevent!，fd:%d", uevent_fd);
        watcher->hotPlug_thread_->detach();
        pthread_detach(pthread_self());
    } else {
        ANG_LOGI("success to init uevent!");
    }
    watcher->running_ = true;
    while (watcher->running_) {
        while ((n = recv(uevent_fd, msg, UEVENT_MSG_LEN, 0)) > 0) {
            struct ang_uevent event;
            if (n == UEVENT_MSG_LEN)
                continue;

            parseUevent(watcher, msg, &event);
        }
        ANG_LOGI("recv n:%d", n);
        if (n <= 0) {
            break;
        }
    }
    watcher->hotPlug_thread_->detach();
    pthread_detach(pthread_self());
    watcher->running_ = false;
    ANG_LOGI("hotPlugThread end");
    return nullptr;
}

int AndroidDeviceWatcher::registerCallback(void* ptr, deviceChangedCallback callback) {
    Mutex::Autolock _l(mutex_);
    for (auto it : callbacks_) {
        if (it.first == ptr) {
            ANG_LOGI("AndroidDeviceWatcher::registerCallback failed, already registerCallback");
            return -1;
        }
    }
    callbacks_.insert(std::make_pair(ptr, std::move(callback)));
    return 0;
}

int AndroidDeviceWatcher::unregisterCallback(void* ptr) {
    Mutex::Autolock _l(mutex_);
    for (auto itr = callbacks_.begin(); itr != callbacks_.end(); ++itr) {
        if (itr->first == ptr) {
            callbacks_.erase(itr);
            return 0;
        }
    }
    return -1;
}

int AndroidDeviceWatcher::start() {
    Mutex::Autolock _l(mutex_);
    if (running_) {
        ANG_LOGI("AndroidDeviceWatcher::start failed, already start");
        return -1;
    }
    if (hotPlug_thread_->get_status()) {
        ANG_LOGI("AndroidDeviceWatcher::start failed, already start2");
    }
    ANG_LOGI("start uevent monitor:%p", this);
    return hotPlug_thread_->create(hotPlugThread, this);
}

int AndroidDeviceWatcher::stop() {
    Mutex::Autolock _l(mutex_);
    if (!running_) {
        ANG_LOGE("AndroidDeviceWatcher::stop failed, already stop");
        return -1;
    }
    if (callbacks_.size() > 0) {
        ANG_LOGI("AndroidDeviceWatcher::stop failed, callbacks_ size:%d", callbacks_.size());
        return -1;
    }
    ANG_LOGI("close uevent monitor");
    //关闭uevent监听
    int rc = ::close(uevent_fd);
    uevent_fd = 0;
    if (rc != 0) {
        ANG_LOGE("close uevent fd failed, rc:%d, errno:%d", rc, errno);
    }
    running_ = false;
    if (hotPlug_thread_->get_status()) {
        ANG_LOGI("terminate hotPlugThread");
        hotPlug_thread_->terminate();
        hotPlug_thread_->detach();
    }

    return 0;
}

bool AndroidDeviceWatcher::is_stopped() const {
    return running_;
}

