/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _KONDYOR_NETTYPES_H_
#define _KONDYOR_NETTYPES_H_

#include <unistd.h>
#include <string>

namespace ang {

    int const  DEVICE_DEFAULT_PORT = 5678;

    int const PORT_BROADCAST = 9000;

    typedef struct {
        std::string ip;
        int port;
    } AddressInfo;

    typedef struct {
        uint8_t act;
        uint8_t type;
        uint16_t id;
        uint32_t seq;
        uint32_t ts;
    } UdpHead;

    typedef struct {
        uint8_t type;
        uint8_t req;
        uint16_t value;
        uint16_t index;
        uint16_t length;
    } CmdHead;

    typedef struct cmd_data_info {
        UdpHead udp_head;
        CmdHead cmd_head;
        uint8_t *data;
    } CmdInfo;

    typedef enum {
        STREAM_OFF = 0x00,//关流
        STREAM_ON = 0x01,//开流
        IP = 0x02,//IP地址
        MAC = 0x03,//MAC地址
        DISCONNECT = 0x04,//断开连接
        DHCP = 0x05,//使能DHCP
    } UdpCmdReq;

    typedef enum {
        CMD_GET = 0xa1,//GET类型
        CMD_SET = 0x21,//SET类型
    } UdpCmdType;
}

#endif //_KONDYOR_NETTYPES_H_
