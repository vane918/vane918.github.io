/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "AngVendorDriver.h"
#include "AngUtil.h"
#include "Mutex.h"

using namespace ang;

static void print_device(libusb_device *dev, libusb_device_handle *handle);

constexpr static uint8_t kEndpointOut_RGB = 0x02;
constexpr static uint8_t kEndpointIn_RGB = 0x82;
constexpr static uint8_t kInterface_RGB = 1;

constexpr static size_t kPacketSize = 512;
constexpr static size_t kPacketLargeSize_RGB = 32 * 1024;
constexpr static size_t kPacketLargeSize_COMPOSITE = 128 * 1024;

//自定义流 开/关
constexpr static uint16_t kAngStreamCmd = 0xAB;
constexpr static uint16_t kAngStreamOn = 0x01;
constexpr static uint16_t kAngStreamOff = 0x02;

constexpr static size_t STREAM_SIZE_MAX  = 1920*1080*2;


constexpr static size_t kFrameMaxSize_RGB = 600 * 1024;
constexpr static size_t kFrameMaxSize_COMPOSITE = STREAM_SIZE_MAX;
constexpr static size_t kPacketMaxCount_RGB = kFrameMaxSize_RGB / kPacketLargeSize_RGB;
constexpr static size_t kPacketMaxCount_COMPOSITE = kFrameMaxSize_COMPOSITE/ kPacketLargeSize_COMPOSITE;
constexpr static uint32_t kFrameWidth_RGB = 480;
constexpr static uint32_t kFrameHeight_RGB = 768;
constexpr static uint32_t kFrameSizeRgb888_RGB = 480 * 768 * 3;

#define ANG_USB_HANDLE_EVENTS_TIMEOUT 500

static int g_firstStart = 1;

Mutex post_mutex_;

VendorDriver::VendorDriver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type) :
        Driver( descriptor, devInfo, driver_type), read_ang_frame_thread_(std::make_shared<AngThread>()),
        post_ang_frame_thread_( std::make_shared<AngThread>()),
        handle_usb_event_thread_( std::make_shared<AngThread>()),
                                  descriptor_(descriptor) {
}

VendorDriver::~VendorDriver() {
}

void angCleanupAngData(VendorDriver *driver) {
    ANG_LOGI("angCleanupAngData");
    libusb_cancel_transfer(driver->usb_handle_.m_transfer);
    if (driver->usb_handle_.m_transfer->buffer) {
        angOSFree(driver->usb_handle_.m_transfer->buffer);
        driver->usb_handle_.m_transfer->buffer = nullptr;
        libusb_free_transfer(driver->usb_handle_.m_transfer);
        driver->usb_handle_.m_transfer = nullptr;
    }

    driver->event_release_ = true;
}

int VendorDriver::init(int interface) {
    ANG_LOGI("VendorDriver[%s]::init interface:%d", ang_dev_info_->usb.uid.c_str(), interface);
    int rc = 0;
    interface_num_ = interface;
    auto devices = descriptor_->getUsbDeviceDescriptors();
    for (auto &dev : *devices) {
        if (dev->getAngDevInfo()->usb.uid != ang_dev_info_->usb.uid)
            continue;
        auto interfaces = dev->getConfigurationDescriptor()->getInterfaceDescriptorList();
        for (auto &interface : *interfaces) {
            if (interface_num_ == interface->getInterfaceNumber()) {
                ANG_LOGI("VendorDriver interface: %p, num:%d", interface.get(), interface->getInterfaceNumber());
                auto endpoints = interface->getEndpointDescriptorList();
                for (auto &endpoint : *endpoints) {
                    uint8_t endpointAddress = endpoint->getEndpointAddress();
                    ANG_LOGI("VendorDriver endpointAddress: %x", endpointAddress);
                    if (endpointAddress & LIBUSB_ENDPOINT_IN)
                        endpoint_in_ = endpointAddress;
                    else
                        endpoint_out_ = endpointAddress;
                }
                break;
            }
        }
    }
    ANG_LOGI("init endpoint_in_: %x, endpoint_out_:%x", endpoint_in_, endpoint_out_);
    if (endpoint_in_ == 0 || endpoint_out_ == 0) {
        ANG_LOGE("endpoint_in_ or endpoint_out_ is wrong!!!");
        abort();
    }

    if (endpoint_in_ == kEndpointIn_RGB)
        rgb_stream_ = true;
    else
        rgb_stream_ = false;
    return rc;
}

int VendorDriver::shutdown() {
    ANG_LOGI("VendorDriver[%s]::shutdown", ang_dev_info_->usb.uid.c_str());
    return 0;
}

int VendorDriver::open(int fd) {
    ANG_LOGI("VendorDriver[%s]::open fd: %d", ang_dev_info_->usb.uid.c_str(), fd);
    int rc = 0;
    if (fd > 0) {
#ifdef _USE_MAIN_LIBUVC_AND_LIBUSB
        rc = libusb_set_option(NULL, LIBUSB_OPTION_NO_DEVICE_DISCOVERY, NULL);
        if (rc != LIBUSB_SUCCESS) {
            ANG_LOGE("libusb_set_option failed: %d", rc);
            return -1;
        }
        rc = libusb_set_option(NULL, LIBUSB_OPTION_LOG_LEVEL, LIBUSB_LOG_LEVEL_INFO);
        ANG_LOGI("VendorDriver libusb_set_option:%d", rc);
        rc = libusb_init(&usb_handle_.context);
        if (rc < 0) {
            ANG_LOGE("libusb_init failed: %d", rc);
            return rc;
        }
#else
        rc = libusb_init2(&usb_handle_.context, std::to_string(fd).c_str());
        if (rc < 0) {
            ANG_LOGE("libusb_init2 failed: %d", rc);
            return rc;
        }
#endif
        rc = openDeviceByFd(fd);
    }

    else {
        rc = libusb_init(&usb_handle_.context);
        unsigned short nVendorID = 0;
        unsigned short nProductID = 0;
        unsigned char nBus = 0;
        unsigned char nAddress = 0;

        sscanf(ang_dev_info_->usb.vid.c_str(), "%hx", &nVendorID);
        sscanf(ang_dev_info_->usb.pid.c_str(), "%hx", &nProductID);
        sscanf(ang_dev_info_->usb.bus.c_str(), "%hhu", &nBus);
        sscanf(ang_dev_info_->usb.dev.c_str(), "%hhu", &nAddress);
        ANG_LOGI("openDeviceByFd %x,%x,%d,%d", nVendorID, nProductID, nBus, nAddress);
        if (nVendorID == 0 || nProductID == 0 || nBus == 0 || nAddress == 0) {
            ANG_LOGE("Invalid connection gVid: %s, gPid: %s", ang_dev_info_->usb.vid.c_str(),
                     ang_dev_info_->usb.pid.c_str());
            return ANG_STATUS_FAILED;
        }

        libusb_device **devs;
        ssize_t cnt;
        cnt = libusb_get_device_list(usb_handle_.context, &devs);
        if (cnt < 0) {
            ANG_LOGE("failed to libusb_get_device_list");
            return ANG_STATUS_FAILED;
        }

        libusb_device *dev;
        int i = 0;
        while ((dev = devs[i++]) != NULL) {
            struct libusb_device_descriptor desc;
            int r = libusb_get_device_descriptor(dev, &desc);
            if (r < 0) {
                ANG_LOGE("failed to get device descriptor");
                return ANG_STATUS_FAILED;
            }
            if (desc.idVendor == nVendorID && desc.idProduct == nProductID &&
                libusb_get_bus_number(dev) == nBus && libusb_get_device_address(dev) == nAddress) {
                usb_handle_.device = dev;
                break;
            }
        }
        libusb_free_device_list(devs, 1);

        if (!usb_handle_.device) {
            ANG_LOGE("failed to get usb_dev");
            return ANG_STATUS_FAILED;
        }

        rc = libusb_open(usb_handle_.device, &usb_handle_.dev_handle);
        if (rc != 0) {
            ANG_LOGE("libusb_open failed:%s", libusb_error_name(rc));
            return ANG_STATUS_FAILED;
        }
    }

    rc = libusb_set_auto_detach_kernel_driver(usb_handle_.dev_handle, 1);
    ANG_LOGI("libusb_set_auto_detach_kernel_driver:%d", rc);
    rc = libusb_claim_interface(usb_handle_.dev_handle, interface_num_);
    ANG_LOGI("libusb_claim_interface[%d], rc:%d", interface_num_, rc);
    return 0;
}

int VendorDriver::close() {
    ANG_LOGI("VendorDriver[%s]::close", ang_dev_info_->usb.uid.c_str());
    int rc = libusb_release_interface(usb_handle_.dev_handle, interface_num_);
    ANG_LOGI("libusb_release_interface[%d], rc:%d", interface_num_, rc);
    libusb_close(usb_handle_.dev_handle);
    ANG_LOGI("libusb_close end");
#ifndef _USE_MAIN_LIBUVC_AND_LIBUSB
    libusb_set_device_fd(usb_handle_.device, 0);
#endif

    libusb_exit(usb_handle_.context);
    usb_handle_.dev_handle = nullptr;
    usb_handle_.device = nullptr;
    usb_handle_.context = nullptr;
    return 0;
}

long VendorDriver::getUsbHandle() {
    return reinterpret_cast<long>(usb_handle_.dev_handle);
}

int VendorDriver::startStream(long sensorHandle, ang_stream_config *streamConfig,
                              FrameCallback callback) {
    ANG_LOGI("VendorDriver[%s]::startStream", ang_dev_info_->usb.uid.c_str());
    frame_ready_ = false;
    int rc = 0;
    sensor_handle_ = sensorHandle;
    frame_callback_ = callback;
    index_ = 0;
    running_ = true;
    size_t frameMaxSize = 0;
    if (rgb_stream_)
        frameMaxSize = kFrameMaxSize_RGB;
    else
        frameMaxSize = kFrameMaxSize_COMPOSITE;
    frame_pool_ = std::make_unique<AngFramePool>(frameMaxSize);
    rc = handle_usb_event_thread_->create(usbHandleEventThread, this);
    angOSSleep(10);
    rc = read_ang_frame_thread_->create(streamReadThread, this);
    angOSSleep(10);
    rc = post_ang_frame_thread_->create(streamPostThread, this);

    return 0;
}

int VendorDriver::stopStream() {
    ANG_LOGI("VendorDriver[%s]::stopStream[%d]", ang_dev_info_->usb.uid.c_str(), interface_num_);
    if (frame_ready_ == false) {
        ANG_LOGE("VendorDriver[%s]::frame_ready_ is false", ang_dev_info_->usb.uid.c_str());
    }
    running_ = false;
    angOSSleep(50);

    int tryCount = 100;
    while ((post_ang_frame_thread_->get_status() || read_ang_frame_thread_->get_status()) && tryCount > 0) {
        angOSSleep(20);
        tryCount--;
    }

    if (!cancel_transfer_) {
        angCleanupAngData(this);
        cancel_transfer_ = true;
    }

    angOSSleep(50);

    ANG_LOGI("stop stream tryCount:%d", 100 - tryCount);

    if (post_ang_frame_thread_->get_status()) {
        ANG_LOGI("terminate post thread");
        post_ang_frame_thread_->terminate();
    }

    if (read_ang_frame_thread_->get_status()) {
        ANG_LOGI("terminate read thread");
        read_ang_frame_thread_->terminate();
    }

    //关闭自定义流
    auto *packetBuff = static_cast<uint8_t *>(malloc(kPacketSize));
    // stream off
    memset(packetBuff, 0, kPacketSize);
    packetBuff[0] = 0x21;
    packetBuff[1] = kAngStreamCmd;
    packetBuff[2] = 0x00;
    packetBuff[3] = 0x00;
    packetBuff[4] = 0x00;
    packetBuff[5] = 0x00;
    packetBuff[6] = kAngStreamOff;
    packetBuff[7] = 0x00;
    int nBytesReceived = 0;

    int rc = 0;

    ANG_LOGI("ANG_STREAM_OFF start");
    tryCount = 3;
    uint8_t pBuffer[32];
    pBuffer[0] = 0x80;
    for (int i = 0; i < tryCount; ++i) {
        if (rgb_stream_) {
            rc = libusb_bulk_transfer(usb_handle_.dev_handle, kEndpointOut_RGB, packetBuff, kPacketSize,
                                      &nBytesReceived, 1000);
            ANG_LOGI("ANG_STREAM_OFF rc:%d, nBytesReceived:%d", rc, nBytesReceived);
            if (rc == 0)
                break;
        } else {
            uint8_t bmRequestType = LIBUSB_REQUEST_TYPE_CLASS;
            bmRequestType |= LIBUSB_ENDPOINT_OUT | LIBUSB_RECIPIENT_INTERFACE;
            ANG_LOGI("VendorDriver[%s]::ANG_STREAM_OFF start", ang_dev_info_->usb.uid.c_str());
            rc = libusb_control_transfer(usb_handle_.dev_handle, bmRequestType,
                                         kAngStreamCmd, 0x0000, 0x0000, pBuffer, kAngStreamOff, 1000);
            ANG_LOGI("VendorDriver[%s]::ANG_STREAM_OFF end, rc:%d", ang_dev_info_->usb.uid.c_str(), rc);
            if (rc > 0)
                break;
        }
    }

    free(packetBuff);
    frame_callback_ = nullptr;

    if (!rgb_stream_) {
        int result = libusb_reset_device(usb_handle_.dev_handle);
        ANG_LOGI("libusb_reset_device:%d", result);
    }

    ANG_LOGI("VendorDriver::stopStream[%d] end", interface_num_);

    usb_event_running_ = false;
    rc = usb_event_cond_.wait(usb_event_mutex_, 1000);
    if (handle_usb_event_thread_->get_status()) {
        ANG_LOGI("terminate usb event thread");
        handle_usb_event_thread_->terminate();
    }

    return 0;
}

int VendorDriver::switchConfig(ang_stream_config *streamConfig) {
    ANG_LOGI("VendorDriver[%s]::switchConfig", ang_dev_info_->usb.uid.c_str());
    return 0;
}

int VendorDriver::updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) {
    ang_dev_info_ = devInfo;
    //todo:
    return ANG_STATUS_SUCCESS;
}

int VendorDriver::sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) {
    return ANG_STATUS_NOT_SUPPORT;
}

void angTransferCallback(libusb_transfer *pTransfer) {
    auto *driver = (VendorDriver *) pTransfer->user_data;
    if (driver->event_release_ == false) {
        // notify endpoint thread this buffer is done
        int nRetVal = driver->submit_cond_.notify(driver->submit_mutex_);
        if (nRetVal != 0) {
            // we don't have much to do if set event failed, log a warning
            ANG_LOGE("Failed to wait event for buffer: %d", nRetVal);
        }
    } else {
        ANG_LOGI("angTransferCallback bEventRelease is TRUE");
    }
}

int angUSBAngSubmitCustomRead(VendorDriver *driver, uint8_t *buffer,
                              int &pnBytesReceived) {

    driver->event_release_ = false;
    int tryCount = 3;
    int rc = 0;
    while (tryCount > 0 && driver->running_) {
        tryCount--;
        rc = libusb_submit_transfer(driver->usb_handle_.m_transfer);
        if (rc == 0)
            break;
        else
            ANG_LOGE("Failed to submit asynch I/O transfer (rc=%d)!", rc);
    }
    if (rc != 0)
        return -1;

    rc = driver->submit_cond_.wait(driver->submit_mutex_, 100);
    if (rc == 0) {
        if (driver->event_release_ == false) {
            angOSMemCopy(buffer, driver->usb_handle_.m_transfer->buffer,
                         driver->usb_handle_.m_transfer->actual_length);
            pnBytesReceived = driver->usb_handle_.m_transfer->actual_length;
        }
    } else {
        if (rc == ETIMEDOUT) {
            ANG_LOGE("timeout. cancelling transfer...");
            rc = libusb_cancel_transfer(driver->usb_handle_.m_transfer);
            return ANG_STATUS_TIMEOUT;
        }
        else {
            ANG_LOGI("submit_cond_.wait:%d", rc);
        }
    }
    return rc;
}

ANG_THREAD_PROC VendorDriver::usbHandleEventThread(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("usb_handle_event_thread start");
    auto driver = static_cast<VendorDriver *>(pThreadParam);
    // init timeout
    struct timeval timeout{};
    timeout.tv_sec = 0;
    timeout.tv_usec = ANG_USB_HANDLE_EVENTS_TIMEOUT * 1000;
    driver->usb_event_running_ = true;
    while (driver->usb_event_running_) {
        // let libusb process its asynchronous events
        libusb_handle_events_timeout(driver->usb_handle_.context, &timeout);
    }
    int nRetVal = driver->usb_event_cond_.notify(driver->usb_event_mutex_);
    nRetVal = driver->handle_usb_event_thread_->detach();
    if (nRetVal != 0) {
        ANG_LOGE("handle_usb_event_thread_ detach failed, nRetVal:%d, errno:%d", nRetVal, errno);
    }
    pthread_detach(pthread_self());
    ANG_LOGI("usb_handle_event_thread end");
    ANG_THREAD_PROC_RETURN(ANG_STATUS_SUCCESS);
}

ANG_THREAD_PROC VendorDriver::streamReadThread(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("stream_read_thread start");
    prctl(PR_SET_NAME, "ang-read-frame");
    auto driver = static_cast<VendorDriver *>(pThreadParam);
    driver->running_ = true;
    driver->time_old_ = angOsGetTime();
    driver->frame_count_ = 0;
    size_t packetLargeSize = 0;
    size_t frameMaxSize = 0;
    size_t packetMaxCount = 0;

    if (driver->rgb_stream_) {
        packetLargeSize = kPacketLargeSize_RGB;
        frameMaxSize = kFrameMaxSize_RGB;
        packetMaxCount = kPacketMaxCount_RGB;
    } else {
        packetLargeSize = kPacketLargeSize_COMPOSITE;
        frameMaxSize = kFrameMaxSize_COMPOSITE;
        packetMaxCount = kPacketMaxCount_COMPOSITE;
    }

    if (g_firstStart == true) {
        int result = libusb_reset_device(driver->usb_handle_.dev_handle);
        ANG_LOGI("libusb_reset_device:%d", result);
        g_firstStart = false;
    }

    auto *packetBuff = static_cast<uint8_t *>(angOSMalloc(kPacketSize));

    auto *packetLargeBuff = static_cast<uint8_t *>(angOSMalloc(packetLargeSize));
    // stream on
    angOSMemSet(packetBuff, 0, kPacketSize);
    packetBuff[0] = 0x21;
    packetBuff[1] = kAngStreamCmd;
    packetBuff[2] = 0x00;
    packetBuff[3] = 0x00;
    packetBuff[4] = 0x00;
    packetBuff[5] = 0x00;
    packetBuff[6] = kAngStreamOn;
    packetBuff[7] = 0x00;

    int nBytesReceived = 0;
    int rc = 0;
    int tryCount = 3;
    driver->usb_handle_.m_transfer = libusb_alloc_transfer(0);

    nBytesReceived = 0;
    ANG_LOGI("VendorDriver[%s]::ANG_STREAM_ON start interface:%d, endpoint_in_:%x, endpoint_out_:%x, "
             "dev_handle:%p", driver->ang_dev_info_->usb.uid.c_str(), driver->interface_num_, driver->endpoint_in_,
             driver->endpoint_out_, driver->usb_handle_.dev_handle);
    if (driver->endpoint_in_ == 0) {
        ANG_LOGE("endpoint_in_ is wrong");
        abort();
    }

    uint8_t pBuffer[32];
    pBuffer[0] = CUSTOMER_TYPE_DEEPTH;
    for (int i = 0; i < tryCount; ++i) {
        if (driver->rgb_stream_) {
            rc = libusb_bulk_transfer(driver->usb_handle_.dev_handle, driver->endpoint_out_, packetBuff,
                                      kPacketSize,
                                      &nBytesReceived, 1000);
            ANG_LOGI("ANG_STREAM_ON rc:%d, nBytesReceived:%d", rc, nBytesReceived);
            if (rc == 0)
                break;
        } else {
            uint8_t bmRequestType = LIBUSB_REQUEST_TYPE_CLASS;
            bmRequestType |= LIBUSB_ENDPOINT_OUT | LIBUSB_RECIPIENT_INTERFACE;
            rc = libusb_control_transfer(driver->usb_handle_.dev_handle, bmRequestType,
                                         kAngStreamCmd, 0x0000, 0x0000, pBuffer, kAngStreamOn, 1000);
            ANG_LOGI("ANG_STREAM_ON rc:%d", rc);
            if (rc > 0)
                break;
        }
    }

    if (driver->rgb_stream_ && rc!=0) {
        pthread_detach(pthread_self());
        ANG_THREAD_PROC_RETURN(-1);
    } else if (!driver->rgb_stream_ && rc <= 0){
        pthread_detach(pthread_self());
        ANG_THREAD_PROC_RETURN(-1);
    }

    ANG_LOGI("ANG_STREAM_ON ok");

    uint8_t initBuff[4];
    angOSMemSet(initBuff, 0, 4);
    //帧起始包4字节标志位
    initBuff[0] = 0x0a;
    initBuff[1] = 0x1b;
    initBuff[2] = 0x2c;
    initBuff[3] = 0x3d;

    uint8_t finalBuff[4];
    angOSMemSet(finalBuff, 0, 4);
    //帧结束包4字节标志位
    finalBuff[0] = 0x0d;
    finalBuff[1] = 0x1c;
    finalBuff[2] = 0x2b;
    finalBuff[3] = 0x3a;

    uint8_t frameLenBuf[4];
    angOSMemSet(frameLenBuf, 0, 4);

    uint32_t idealFrameSize;
    uint32_t receiveFrameByte;

    uint16_t packetCount;

    uint16_t packetNo;

    auto *frameBuff = static_cast<uint8_t *>(angOSMalloc(frameMaxSize));

    auto *gBuffer = (uint8_t *) angOSMalloc(packetLargeSize);

    angOSMemSet(gBuffer, 0, packetLargeSize);
    driver->usb_handle_.m_transfer->type = LIBUSB_TRANSFER_TYPE_BULK;
    libusb_fill_bulk_transfer(driver->usb_handle_.m_transfer, driver->usb_handle_.dev_handle,
                              driver->endpoint_in_,
                              gBuffer,
                              packetLargeSize,
                              angTransferCallback, driver, 100);

    driver->cancel_transfer_ = false;

    AngFrame frame_t;
    ANG_LOGI("packetLargeSize:%d, frameMaxSize:%d", packetLargeSize, frameMaxSize);
    while (driver->running_) {

        initState:
        //获取起始包
        tryCount = 500;
        while (driver->running_ && tryCount > 0) {
            nBytesReceived = 0;
            angOSMemSet(packetBuff, 0, kPacketSize);
            rc = libusb_bulk_transfer(driver->usb_handle_.dev_handle, driver->endpoint_in_, packetBuff,
                                      kPacketSize,
                                      &nBytesReceived, 100);
            tryCount--;
            if (rc != 0) {
                ANG_LOGE("failed to get initBuff, rc:%d, tryCount:%d", rc, (500 - tryCount));
                if (tryCount == 0) {
                    ANG_LOGE("read_stream_failed, failed to get initBuff, rc:%d", rc);
                    goto read_stream_failed;
                }

            } else {
                if (packetBuff[0] == initBuff[0] && packetBuff[1] == initBuff[1] &&
                    packetBuff[2] == initBuff[2] && packetBuff[3] == initBuff[3]) {
                    if (500 - tryCount > 100)
                        ANG_LOGI("get initBuff success:%d", (500 - tryCount));
                    break;
                } else {
                    if (tryCount == 0) {
                        ANG_LOGE("read_stream_failed, initBuff failed");
                        goto read_stream_failed;
                    }
                }

            }

//            angOSSleep(5);
        }

        if (!driver->running_) {
            ANG_LOGI("m_isRunning is false");
            goto read_stream_failed;
        }

        //获取帧长度
        nBytesReceived = 0;
        idealFrameSize = 0;
        packetCount = 0;
        idealFrameSize = DW_TO_INT(&packetBuff[4]);
        packetCount = packetBuff[8];
        packetCount = (packetCount << 8) | packetBuff[9];
        if (idealFrameSize > frameMaxSize || idealFrameSize <= 0 || packetCount > packetMaxCount) {
            ANG_LOGE("frame size error！idealFrameSize:%d, packetCount:%d, jump to initState",
                     idealFrameSize, packetCount);
            goto initState;
        }

        receiveFrameByte = 0;
        angOSMemSet(frameBuff, 0, frameMaxSize);

        packetNo = 0;

        int packetCount_temp = packetCount;

        while (driver->running_ && packetCount > 0) {
            nBytesReceived = 0;
            memset(packetLargeBuff, 0, packetLargeSize);

            rc = angUSBAngSubmitCustomRead(driver, packetLargeBuff, nBytesReceived);

            if (rc != 0) {
                ANG_LOGE("failed to get frame data！rc:%d", rc);
                goto initState;
            }

            packetNo = packetLargeBuff[0];

            //重要！！！
            //该代码是在出现frame data丢包时的修复方案，具体方案如下：
            //如果包序号和frame data的包序号不一致，则认为是发生了丢包，接收frame data是按照128K接收，
            //但系统与模组还是每次按照512 byte(bulk传输最大值)来传输，因此将128K frame data以512 byte
            //分为256份，每份的前四个字节如果是起始包0a 1b 2c 3d,则认为是新的frame data，但此刻的新的frame
            //是不满128K的，因此需要使用512大小来收发剩下的frame data，加起来即为新的frame的第一包，
            //剩下的按照常规的128K来接收frame data
            if (packetNo != packetCount) {
                ANG_LOGE("frame packet loss, packetNO error:%d, packetCount:%d", packetNo, packetCount);
                uint8_t i0, i1, i2, i3, i9 = 0;
                int index = 0;
                for (int i = 1; i<256; i++) {
                    i0 = packetLargeBuff[kPacketSize*i+0];
                    i1 = packetLargeBuff[kPacketSize*i+1];
                    i2 = packetLargeBuff[kPacketSize*i+2];
                    i3 = packetLargeBuff[kPacketSize*i+3];
                    i9 = packetLargeBuff[kPacketSize*i+9];
                    if (i0 == initBuff[0] && i1 == initBuff[1] && i2 == initBuff[2] && i3 == initBuff[3]) {
                        index = i;
                        idealFrameSize = DW_TO_INT(&packetLargeBuff[kPacketSize*i+4]);
                        packetCount = packetLargeBuff[kPacketSize*i+8];
                        packetCount = (packetCount << 8) | packetLargeBuff[kPacketSize*i+9];
                        ANG_LOGI("found init packet again, i:%d, packetCount:%d", i, packetCount);
                        break;
                    }
                }
                if (index == 0) {
                    ANG_LOGE("not found init packet in data, goto initState");
                    goto initState;
                }

                angOSMemCopy(&frameBuff[receiveFrameByte], &packetLargeBuff[kPacketSize*(index+1)+1],
                             packetLargeSize - kPacketSize*(index+1) - 1);
                receiveFrameByte = receiveFrameByte + (nBytesReceived - kPacketSize*(index+1)) - 1;

                int needCount = 1 + index;
                while (needCount > 0) {
                    needCount--;
                    nBytesReceived = 0;
                    angOSMemSet(packetBuff, 0, kPacketSize);
                    rc = libusb_bulk_transfer(driver->usb_handle_.dev_handle, driver->endpoint_in_, packetBuff,
                                              kPacketSize,
                                              &nBytesReceived, 100);
                    if (rc == 0 && nBytesReceived == kPacketSize) {
                        receiveFrameByte = receiveFrameByte + nBytesReceived;
                    }
                }
                packetCount--;
                continue;
            }

            angOSMemCopy(&frameBuff[receiveFrameByte], &packetLargeBuff[1], packetLargeSize - 1);
            receiveFrameByte = receiveFrameByte + nBytesReceived - 1;
            packetCount--;
        }

        //获取结束包
        tryCount = 3;
        while (driver->running_ && tryCount-- > 0) {
            nBytesReceived = 0;
            angOSMemSet(packetBuff, 0, kPacketSize);
            rc = libusb_bulk_transfer(driver->usb_handle_.dev_handle, driver->endpoint_in_, packetBuff,
                                      kPacketSize, &nBytesReceived, 1000);

            if (rc != 0)
                ANG_LOGE("end packet failed, rc:%d", rc);
            else
                break;
        }

        auto angFrame = driver->frame_pool_->get_frame_buffer();
        if (idealFrameSize > receiveFrameByte)
            frame_t.size_ = receiveFrameByte;
        else
            frame_t.size_ = idealFrameSize;

        if (driver->rgb_stream_) {
            frame_t.type_ = ANG_FRAME_COLOR;
            frame_t.format_ = ANG_FRAME_FORMAT_MJPEG;
        } else {
            frame_t.type_ = ANG_FRAME_SET;
            frame_t.format_ = ANG_FRAME_FORMAT_MJPEG;
        }

        frame_t.width_ = driver->width_;
        frame_t.height_ = driver->height_;
        frame_t.index_ = ++driver->index_;
        frame_t.data_ = frameBuff;
        createFrame(frame_t, angFrame);

        driver->frame_count_++;

        if (angOsGetTime() - driver->time_old_ >= 1000 * 1000) {
            int mRgbLen = DW_TO_INT(&frameBuff[1024 + 48]);
            ANG_LOGI("VendorDriver[%s] frameLen:%d, mRgbLen:%d, frameCount:%d", driver->ang_dev_info_->usb.uid.c_str(),
                     frame_t.size_, mRgbLen, driver->frame_count_);
            driver->time_old_ = angOsGetTime();
            driver->frame_count_ = 0;
        }
        rc = driver->frame_cond_.notify(driver->frame_mutex_);
        if (rc != ANG_STATUS_SUCCESS)
            ANG_LOGE("Failed to set event for hAngFrameEvent: %d", rc);
    }

    if (!driver->cancel_transfer_) {
        angCleanupAngData(driver);
        driver->cancel_transfer_ = true;
    }

    angOSFree(packetBuff);
    angOSFree(packetLargeBuff);
    angOSFree(frameBuff);
    driver->running_ = false;
    ANG_LOGI("AngStreamReadThread end");
    driver->read_ang_frame_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_THREAD_PROC_RETURN(0);

    read_stream_failed:

    if (!driver->cancel_transfer_) {
        angCleanupAngData(driver);
        driver->cancel_transfer_ = true;
    }
    angOSFree(packetBuff);
    angOSFree(packetLargeBuff);
    angOSFree(frameBuff);
    driver->running_ = false;
    ANG_LOGI("goto read_stream_failed");
    rc = driver->read_ang_frame_thread_->detach();
    if (rc != 0) {
        ANG_LOGE("read_ang_frame_thread_ detach failed, rc:%d, errno:%d", rc, errno);
    }
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_LOGI("AngStreamReadThread end forcibly");
    ANG_THREAD_PROC_RETURN(0);
}

ANG_THREAD_PROC VendorDriver::streamPostThread(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("stream_post_thread start");
    prctl(PR_SET_NAME, "ang-post-frame");
    auto *driver = (VendorDriver *) pThreadParam;
    int rc = ANG_STATUS_SUCCESS;
    uint32_t timeout = 100;
    uint32_t width, height;

    while (driver->running_) {
        rc = driver->frame_cond_.wait(driver->frame_mutex_, timeout);
        if (rc == ANG_STATUS_SUCCESS) {
            if (driver->frame_callback_) {
                Mutex::Autolock _l(post_mutex_);
                if (!driver->frame_pool_->empty()) {
                    std::shared_ptr<Frame> angFrame = driver->frame_pool_->pop_frame_buffer();
                    driver->frame_callback_(driver->sensor_handle_, angFrame);
                    driver->frame_ready_ = true;
                }
            }
        } else {
            ANG_LOGI("AngStreamPostThread timeout");
        }
    }

    ANG_LOGI("AngStreamPostThread end");
    rc = driver->post_ang_frame_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_THREAD_PROC_RETURN(ANG_STATUS_OK);
}

int VendorDriver::openDeviceByFd(int fd) {
    int r = 0;
#ifdef _USE_MAIN_LIBUVC_AND_LIBUSB
    r = libusb_wrap_sys_device(usb_handle_.context, (intptr_t) fd, &usb_handle_.dev_handle);
    if (r < 0) {
        ANG_LOGE("libusb_wrap_sys_device failed: %d", r);
        return r;
    } else if (usb_handle_.dev_handle == NULL) {
        ANG_LOGE("libusb_wrap_sys_device returned invalid handle");
        return r;
    }
#else
    unsigned short nVendorID = 0;
    unsigned short nProductID = 0;
    unsigned char nBus = 0;
    unsigned char nAddress = 0;

    sscanf(ang_dev_info_->usb.vid.c_str(), "%hx", &nVendorID);
    sscanf(ang_dev_info_->usb.pid.c_str(), "%hx", &nProductID);
    sscanf(ang_dev_info_->usb.bus.c_str(), "%hhu", &nBus);
    sscanf(ang_dev_info_->usb.dev.c_str(), "%hhu", &nAddress);
    ANG_LOGI("openDeviceByFd %x,%x,%d,%d", nVendorID, nProductID, nBus, nAddress);
    usb_handle_.device = libusb_get_device_with_fd(usb_handle_.context, nVendorID, nProductID,
                                                   nullptr, fd, nBus, nAddress);
    r = libusb_set_device_fd(usb_handle_.device, fd);
    ANG_LOGI("VendorDriver[%s]::open start", ang_dev_info_->usb.uid.c_str());
    r = libusb_open(usb_handle_.device, &usb_handle_.dev_handle);
    if (rc != 0) {
        ANG_LOGE("libusb_open failed:%s", libusb_error_name(rc));
        return ANG_STATUS_FAILED;
    }
    ANG_LOGI("VendorDriver[%s]::open end, rc:%d", ang_dev_info_->usb.uid.c_str(), r);
#endif
    //    print_device(libusb_get_device(usb_handle_.dev_handle), usb_handle_.dev_handle);
    return r;
}

#if 0
int verbose = 1;

static void print_endpoint_comp(const struct libusb_ss_endpoint_companion_descriptor *ep_comp) {
    ANG_LOGI("      USB 3.0 Endpoint Companion:\n");
    ANG_LOGI("        bMaxBurst:           %u\n", ep_comp->bMaxBurst);
    ANG_LOGI("        bmAttributes:        %02xh\n", ep_comp->bmAttributes);
    ANG_LOGI("        wBytesPerInterval:   %u\n", ep_comp->wBytesPerInterval);
}

static void print_endpoint(const struct libusb_endpoint_descriptor *endpoint) {
    int i, ret;

    ANG_LOGI("      Endpoint:\n");
    ANG_LOGI("        bEndpointAddress:    %02xh\n", endpoint->bEndpointAddress);
    ANG_LOGI("        bmAttributes:        %02xh\n", endpoint->bmAttributes);
    ANG_LOGI("        wMaxPacketSize:      %u\n", endpoint->wMaxPacketSize);
    ANG_LOGI("        bInterval:           %u\n", endpoint->bInterval);
    ANG_LOGI("        bRefresh:            %u\n", endpoint->bRefresh);
    ANG_LOGI("        bSynchAddress:       %u\n", endpoint->bSynchAddress);

    for (i = 0; i < endpoint->extra_length;) {
        if (LIBUSB_DT_SS_ENDPOINT_COMPANION == endpoint->extra[i + 1]) {
            struct libusb_ss_endpoint_companion_descriptor *ep_comp;

            ret = libusb_get_ss_endpoint_companion_descriptor(NULL, endpoint, &ep_comp);
            if (LIBUSB_SUCCESS != ret)
                continue;

            print_endpoint_comp(ep_comp);

            libusb_free_ss_endpoint_companion_descriptor(ep_comp);
        }

        i += endpoint->extra[i];
    }
}

static void print_altsetting(const struct libusb_interface_descriptor *interface) {
    uint8_t i;

    ANG_LOGI("    Interface:\n");
    ANG_LOGI("      bInterfaceNumber:      %u\n", interface->bInterfaceNumber);
    ANG_LOGI("      bAlternateSetting:     %u\n", interface->bAlternateSetting);
    ANG_LOGI("      bNumEndpoints:         %u\n", interface->bNumEndpoints);
    ANG_LOGI("      bInterfaceClass:       %u\n", interface->bInterfaceClass);
    ANG_LOGI("      bInterfaceSubClass:    %u\n", interface->bInterfaceSubClass);
    ANG_LOGI("      bInterfaceProtocol:    %u\n", interface->bInterfaceProtocol);
    ANG_LOGI("      iInterface:            %u\n", interface->iInterface);

    for (i = 0; i < interface->bNumEndpoints; i++)
        print_endpoint(&interface->endpoint[i]);
}

static void print_2_0_ext_cap(struct libusb_usb_2_0_extension_descriptor *usb_2_0_ext_cap) {
    ANG_LOGI("    USB 2.0 Extension Capabilities:\n");
    ANG_LOGI("      bDevCapabilityType:    %u\n", usb_2_0_ext_cap->bDevCapabilityType);
    ANG_LOGI("      bmAttributes:          %08xh\n", usb_2_0_ext_cap->bmAttributes);
}

static void print_ss_usb_cap(struct libusb_ss_usb_device_capability_descriptor *ss_usb_cap) {
    ANG_LOGI("    USB 3.0 Capabilities:\n");
    ANG_LOGI("      bDevCapabilityType:    %u\n", ss_usb_cap->bDevCapabilityType);
    ANG_LOGI("      bmAttributes:          %02xh\n", ss_usb_cap->bmAttributes);
    ANG_LOGI("      wSpeedSupported:       %u\n", ss_usb_cap->wSpeedSupported);
    ANG_LOGI("      bFunctionalitySupport: %u\n", ss_usb_cap->bFunctionalitySupport);
    ANG_LOGI("      bU1devExitLat:         %u\n", ss_usb_cap->bU1DevExitLat);
    ANG_LOGI("      bU2devExitLat:         %u\n", ss_usb_cap->bU2DevExitLat);
}

static void print_bos(libusb_device_handle *handle) {
    struct libusb_bos_descriptor *bos;
    uint8_t i;
    int ret;

    ret = libusb_get_bos_descriptor(handle, &bos);
    if (ret < 0)
        return;

    ANG_LOGI("  Binary Object Store (BOS):\n");
    ANG_LOGI("    wTotalLength:            %u\n", bos->wTotalLength);
    ANG_LOGI("    bNumDeviceCaps:          %u\n", bos->bNumDeviceCaps);

    for (i = 0; i < bos->bNumDeviceCaps; i++) {
        struct libusb_bos_dev_capability_descriptor *dev_cap = bos->dev_capability[i];

        if (dev_cap->bDevCapabilityType == LIBUSB_BT_USB_2_0_EXTENSION) {
            struct libusb_usb_2_0_extension_descriptor *usb_2_0_extension;

            ret = libusb_get_usb_2_0_extension_descriptor(NULL, dev_cap, &usb_2_0_extension);
            if (ret < 0)
                return;

            print_2_0_ext_cap(usb_2_0_extension);
            libusb_free_usb_2_0_extension_descriptor(usb_2_0_extension);
        } else if (dev_cap->bDevCapabilityType == LIBUSB_BT_SS_USB_DEVICE_CAPABILITY) {
            struct libusb_ss_usb_device_capability_descriptor *ss_dev_cap;

            ret = libusb_get_ss_usb_device_capability_descriptor(NULL, dev_cap, &ss_dev_cap);
            if (ret < 0)
                return;

            print_ss_usb_cap(ss_dev_cap);
            libusb_free_ss_usb_device_capability_descriptor(ss_dev_cap);
        }
    }

    libusb_free_bos_descriptor(bos);
}

static void print_interface(const struct libusb_interface *interface) {
    int i;

    for (i = 0; i < interface->num_altsetting; i++)
        print_altsetting(&interface->altsetting[i]);
}

static void print_configuration(struct libusb_config_descriptor *config) {
    uint8_t i;

    ANG_LOGI("  Configuration:\n");
    ANG_LOGI("    wTotalLength:            %u\n", config->wTotalLength);
    ANG_LOGI("    bNumInterfaces:          %u\n", config->bNumInterfaces);
    ANG_LOGI("    bConfigurationValue:     %u\n", config->bConfigurationValue);
    ANG_LOGI("    iConfiguration:          %u\n", config->iConfiguration);
    ANG_LOGI("    bmAttributes:            %02xh\n", config->bmAttributes);
    ANG_LOGI("    MaxPower:                %u\n", config->MaxPower);

    for (i = 0; i < config->bNumInterfaces; i++)
        print_interface(&config->interface[i]);
}

static void print_device(libusb_device *dev, libusb_device_handle *handle) {
    struct libusb_device_descriptor desc;
    unsigned char string[256];
    const char *speed;
    int ret;
    uint8_t i;

    switch (libusb_get_device_speed(dev)) {
        case LIBUSB_SPEED_LOW:
            speed = "1.5M";
            break;
        case LIBUSB_SPEED_FULL:
            speed = "12M";
            break;
        case LIBUSB_SPEED_HIGH:
            speed = "480M";
            break;
        case LIBUSB_SPEED_SUPER:
            speed = "5G";
            break;
        default:
            speed = "Unknown";
    }

    ret = libusb_get_device_descriptor(dev, &desc);
    if (ret < 0) {
        ANG_LOGE("failed to get device descriptor");
        return;
    }

    ANG_LOGI("Dev (bus %u, device %u): %04X - %04X speed: %s\n",
             libusb_get_bus_number(dev), libusb_get_device_address(dev),
             desc.idVendor, desc.idProduct, speed);

    if (handle) {
        if (desc.iManufacturer) {
            ret = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, string,
                                                     sizeof(string));
            if (ret > 0)
                ANG_LOGI("  Manufacturer:              %s\n", (char *) string);
        }

        if (desc.iProduct) {
            ret = libusb_get_string_descriptor_ascii(handle, desc.iProduct, string, sizeof(string));
            if (ret > 0)
                ANG_LOGI("  Product:                   %s\n", (char *) string);
        }

        if (desc.iSerialNumber && verbose) {
            ret = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, string,
                                                     sizeof(string));
            if (ret > 0)
                ANG_LOGI("  Serial Number:             %s\n", (char *) string);
        }
    }

    if (verbose) {
        for (i = 0; i < desc.bNumConfigurations; i++) {
            struct libusb_config_descriptor *config;

            ret = libusb_get_config_descriptor(dev, i, &config);
            if (LIBUSB_SUCCESS != ret) {
                ANG_LOGE("  Couldn't retrieve descriptors\n");
                continue;
            }

            print_configuration(config);

            libusb_free_config_descriptor(config);
        }

        if (handle && desc.bcdUSB >= 0x0201)
            print_bos(handle);
    }
}
#endif