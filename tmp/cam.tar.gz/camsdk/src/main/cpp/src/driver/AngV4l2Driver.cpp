/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifdef _USE_V4L2_DRIVER

#include "AngV4l2Driver.h"
#include "AngStreamConfig.h"

using namespace ang;

Mutex mutex_v4l2_;

V4l2Driver::V4l2Driver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type) :
        Driver(descriptor, devInfo, driver_type), read_ang_frame_thread_(std::make_shared<AngThread>()),
        post_ang_frame_thread_(std::make_shared<AngThread>()) {
}

V4l2Driver::~V4l2Driver() {
}

int V4l2Driver::init(int interface) {
    int ret = chmodPermission();
    if (ret != ANG_STATUS_SUCCESS) {
        return ret;
    }
    std::vector<std::string> videoList;
    findDevVideo(videoList);
    ANG_LOGI("V4l2Driver[%s] init videoList size:%d", ang_dev_info_->usb.uid.c_str(), videoList.size());
    for (auto &it : videoList) {
        std::string busnum = getUvcBusnum(it);
        std::string devnum = getUvcDevnum(it);
        std::string bus_dev = busnum + "/" + devnum;
        ANG_LOGI("V4l2Driver video:%s, bus_dev:%s, ang_dev_info_->uid:%s", it.c_str(), bus_dev.c_str(),
                 ang_dev_info_->usb.uid.c_str());
        if (ang_dev_info_->usb.uid.find(bus_dev) != std::string::npos) {
            video_node_ = it;
            break;
        }
    }
    return 0;
}

int V4l2Driver::shutdown() {
    ANG_LOGI("V4l2Driver[%s] shutdown", ang_dev_info_->usb.uid.c_str());
    return 0;
}

int V4l2Driver::open(int fd) {
    ANG_LOGI("V4l2Driver[%s] open fd:%d start", ang_dev_info_->usb.uid.c_str(), fd);
    fd_ = ::open(video_node_.c_str(), O_RDWR);
    ANG_LOGI("V4l2Driver[%s] open fd:%d end:video_node_%s", ang_dev_info_->usb.uid.c_str(), fd_, video_node_.c_str());
    if (fd_ < 0) {
        ANG_LOGE("V4l2Driver Failed to open device");
        return ANG_STATUS_FAILED;
    }
    return ANG_STATUS_SUCCESS;
}

int V4l2Driver::close() {
    ANG_LOGI("V4l2Driver[%s] close start", ang_dev_info_->usb.uid.c_str());
    int rc = ::close(fd_);
    ANG_LOGI("V4l2Driver[%s] close rc:%d end", ang_dev_info_->usb.uid.c_str(), rc);
    return rc;
}

int V4l2Driver::updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) {
    ang_dev_info_ = devInfo;
    std::vector<std::string> videoList;
    findDevVideo(videoList);
    ANG_LOGI("V4l2Driver[%s] init videoList size:%d", ang_dev_info_->usb.uid.c_str(), videoList.size());
    for (auto &it : videoList) {
        std::string busnum = getUvcBusnum(it);
        std::string devnum = getUvcDevnum(it);
        std::string bus_dev = busnum + "/" + devnum;
        ANG_LOGI("V4l2Driver video:%s, bus_dev:%s, ang_dev_info_->uid:%s", it.c_str(), bus_dev.c_str(),
                 ang_dev_info_->usb.uid.c_str());
        if (ang_dev_info_->usb.uid.find(bus_dev) != std::string::npos) {
            video_node_ = it;
            break;
        }
    }
    return ANG_STATUS_SUCCESS;
}

int V4l2Driver::sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) {
    return ANG_STATUS_NOT_SUPPORT;
}

long V4l2Driver::getUsbHandle() {
    return 0L;
}

ANG_THREAD_PROC V4l2Driver::streamPostThread_v4l2(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("post_ang_frame_thread_ start");
    prctl(PR_SET_NAME, "ang-v4l2-post-frame");
    auto driver = static_cast<V4l2Driver *>(pThreadParam);
    int rc = 0;
    while (driver->running_) {
        rc = driver->frame_cond_.wait(driver->frame_mutex_, 100);
        if (rc == ANG_STATUS_SUCCESS) {
            if (driver->frame_callback_) {
                Mutex::Autolock _l(mutex_v4l2_);
                if (!driver->frame_pool_->empty()) {
                    std::shared_ptr<Frame> angFrame = driver->frame_pool_->pop_frame_buffer();
                    driver->frame_callback_(driver->sensor_handle_, angFrame);
                    driver->frame_ready_ = true;
                }
            }
        } else {
//            ANG_LOGI("AngStreamPostThread_v4l2 timeout");
        }
    }
    driver->post_ang_frame_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_THREAD_PROC_RETURN(0);
}


ANG_THREAD_PROC V4l2Driver::streamReadThread_v4l2(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("stream_read_thread start");
    prctl(PR_SET_NAME, "ang-v4l2-read-frame");
    auto driver = static_cast<V4l2Driver *>(pThreadParam);
    driver->running_ = true;
    AngFrame frame_t;
    int rc = 0;
    driver->time_old_ = angOsGetTime();
    driver->frame_count_ = 0;
    while (driver->running_) {
        rc = driver->deQueueBufferGetFrame(&driver->buf_);
        if (rc < 0) {
            angOSSleep(1);
            continue;
        }

        if (driver->format_ == ANG_FRAME_FORMAT_YUYV && driver->buf_.length != driver->buf_.bytesused) {
            ANG_LOGE("bytesused:%d is not equal with length:%d", driver->buf_.bytesused, driver->buf_.length);
            continue;
        }

        driver->frame_count_++;
        auto angFrame = driver->frame_pool_->get_frame_buffer();
        frame_t.size_ = driver->buf_.bytesused;
        frame_t.width_ = driver->width_;
        frame_t.height_ = driver->height_;
        frame_t.format_ = driver->format_;
        frame_t.type_ = ANG_FRAME_COLOR;
        frame_t.index_ = ++driver->index_;
        frame_t.data_ = driver->frame_buff[driver->buf_.index].start;
        createFrame(frame_t, angFrame);
        if (angOsGetTime() - driver->time_old_ >= 1000 * 1000) {
            ANG_LOGI("V4l2Driver[%s] frameLen:%d, frameCount:%d", driver->ang_dev_info_->usb.uid.c_str(),
                     frame_t.size_, driver->frame_count_);
            driver->time_old_ = angOsGetTime();
            driver->frame_count_ = 0;
        }
        rc = driver->enQueueBuffer(&driver->buf_);
        rc = driver->frame_cond_.notify(driver->frame_mutex_);
    }
    ANG_LOGI("stream_read_thread end");
    driver->read_ang_frame_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_THREAD_PROC_RETURN(0);
}

int V4l2Driver::requestBuffers(struct v4l2_requestbuffers *reqbuf) {
    int ret = -1;
    reqbuf->count = BUFFER_COUNT;
    reqbuf->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    reqbuf->memory = V4L2_MEMORY_MMAP;

    ret = ioctl(fd_, VIDIOC_REQBUFS, reqbuf);
    if (ret < 0) {
        ANG_LOGE("V4l2Driver VIDIOC_REQBUFS failed(%d)", ret);
    }
    return ret;
}

int V4l2Driver::mapAndEnqueue(struct v4l2_requestbuffers *reqbuf, struct v4l2_buffer *buf,
                              VideoBuffer *framebuf) {
    int i = -1, ret = -1;
    // Map And Enqueue
    for (i = 0; i < reqbuf->count; i++) {
        buf->index = i;
        buf->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf->memory = V4L2_MEMORY_MMAP;
        ret = ioctl(fd_, VIDIOC_QUERYBUF, buf);
        if (ret < 0) {
            ANG_LOGE("VIDIOC_QUERYBUF (%d) failed (%d)", i, ret);
            return ret;
        }

        // mmap buffer
        framebuf[i].length = buf->length;
        framebuf[i].start = (char *) mmap(0, buf->length, PROT_READ | PROT_WRITE, MAP_SHARED, fd_,
                                          buf->m.offset);
        if (framebuf[i].start == MAP_FAILED) {
            ANG_LOGE("mmap (%d) failed: %s", i, strerror(errno));
            return -1;
        }

        // Queen buffer
        ret = ioctl(fd_, VIDIOC_QBUF, buf);
        if (ret < 0) {
            ANG_LOGE("VIDIOC_QBUF (%d) failed (%d)", i, ret);
            return -1;
        }

        ANG_LOGI("Frame buffer[%d]: address=%p, length=%d", i, framebuf[i].start,
                 framebuf[i].length);
    }
    return 0;
}

void V4l2Driver::cam_ummap(VideoBuffer *framebuf) {
    int i = -1;
    // Release the resource
    for (i = 0; i < BUFFER_COUNT; i++) {
        munmap(framebuf[i].start, framebuf[i].length);
    }
}

int V4l2Driver::startCameraStreaming() {
    int ret = -1;
    // start camera streaming
    enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    ANG_LOGI("V4l2Driver[%s] stream on start", ang_dev_info_->usb.uid.c_str());
    ret = ioctl(fd_, VIDIOC_STREAMON, &type);
    ANG_LOGI("V4l2Driver[%s] stream on end", ang_dev_info_->usb.uid.c_str());
    if (ret < 0) {
        ANG_LOGE("VIDIOC_STREAMON failed (%d)", ret);
        return ret;
    }
    return ret;
}

int V4l2Driver::stopCameraStreaming() {
    int ret = -1;
    // start camera streaming
    enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    ANG_LOGI("V4l2Driver[%s] stream off start", ang_dev_info_->usb.uid.c_str());
    ret = ioctl(fd_, VIDIOC_STREAMOFF, &type);
    ANG_LOGI("V4l2Driver[%s] stream off end", ang_dev_info_->usb.uid.c_str());
    if (ret < 0) {
        ANG_LOGE("VIDIOC_STREAMOFF failed (%d)", ret);
        return ret;
    }
    return ret;
}

int V4l2Driver::deQueueBufferGetFrame(struct v4l2_buffer *buf) {
    int ret = -1;
    // De-queue buffer ,Get frame
    ret = ioctl(fd_, VIDIOC_DQBUF, buf);
    if (ret < 0) {
        ANG_LOGE("VIDIOC_DQBUF failed (%d)", ret);
        return ret;
    }
    return ret;
}

int V4l2Driver::enQueueBuffer(struct v4l2_buffer *buf) {
    int ret = -1;
    // Re-queen buffer
    ret = ioctl(fd_, VIDIOC_QBUF, buf);
    if (ret < 0) {
        ANG_LOGE("VIDIOC_QBUF failed (%d)", ret);
        return ret;
    }
    return 0;
}

int V4l2Driver::startStream(long sensorHandle, ang_stream_config *streamConfig,
                            FrameCallback callback) {
    ANG_LOGI("V4l2Driver[%s] startStream", ang_dev_info_->usb.uid.c_str());
    if (!streamConfig) {
        ANG_LOGE("V4l2Driver[%s] startStream failed, streamConfig is null", ang_dev_info_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
    frame_ready_ = false;
    int ret = 0;
    frame_callback_ = callback;
    sensor_handle_ = sensorHandle;
    index_ = 0;
    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
    format_ = stream_config->getStreamFormat();
    struct v4l2_format fmt;
    struct v4l2_requestbuffers req;
    enum v4l2_buf_type type;

    // Set the video format
    memset(&fmt, 0, sizeof(fmt));
    fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt.fmt.pix.width = stream_config->getWidth();
    fmt.fmt.pix.height = stream_config->getHeight();
    width_ = stream_config->getWidth();
    height_ = stream_config->getHeight();
    if (stream_config->getStreamFormat() == ANG_FRAME_FORMAT_YUYV)
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
    else
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB24;

    fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;
    if (ioctl(fd_, VIDIOC_S_FMT, &fmt) < 0) {
        ANG_LOGE("Could not set video format");
        return 1;
    }
    ANG_LOGI("startStream width:%d, height:%d, V4L2_PIX_FMT_YUYV:%d",
             fmt.fmt.pix.width, fmt.fmt.pix.height, fmt.fmt.pix.pixelformat == V4L2_PIX_FMT_YUYV);
    requestBuffers(&req_buf_);

    mapAndEnqueue(&req_buf_, &buf_, frame_buff);

    startCameraStreaming();

    ANG_LOGI("buf_.length:%d", buf_.length);

    frame_pool_ = std::make_unique<AngFramePool>(buf_.length);
    ret = read_ang_frame_thread_->create(streamReadThread_v4l2, this);
    angOSSleep(10);
    ret = post_ang_frame_thread_->create(streamPostThread_v4l2, this);

    return 0;
}

int V4l2Driver::stopStream() {
    ANG_LOGI("V4l2Driver[%s] stopStream", ang_dev_info_->usb.uid.c_str());
    if (frame_ready_ == false) {
        ANG_LOGE("V4l2Driver[%s]::frame_ready_ is false", ang_dev_info_->usb.uid.c_str());
    }
    running_ = false;
    angOSSleep(50);

    stopCameraStreaming();

    int tryCount = 100;
    while ((read_ang_frame_thread_->get_status() || post_ang_frame_thread_->get_status()) &&
           tryCount > 0) {
        angOSSleep(20);
        tryCount--;
    }

    if (read_ang_frame_thread_->get_status()) {
        ANG_LOGE("terminate read thread");
        read_ang_frame_thread_->terminate();
    }

    if (post_ang_frame_thread_->get_status()) {
        ANG_LOGE("terminate post thread");
        post_ang_frame_thread_->terminate();
    }

    enum v4l2_buf_type type;
    int ret;
    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    ret = ioctl(fd_, VIDIOC_STREAMOFF, &type);
    if (ret < 0) {
        ANG_LOGE("Unable query buffer: %s", strerror(errno));
        return -1;
    }

    cam_ummap(frame_buff);

    return 0;
}

int V4l2Driver::switchConfig(ang_stream_config *streamConfig) {
    ANG_LOGE("V4l2Driver[%s] switchConfig", ang_dev_info_->usb.uid.c_str());
    return 0;
}

#endif