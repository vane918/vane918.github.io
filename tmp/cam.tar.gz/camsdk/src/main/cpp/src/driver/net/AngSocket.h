/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_SOCKET_H_
#define _ANG_SOCKET_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#include "NetTypes.h"

namespace ang {

    class AngSocket {
    public:
        AngSocket();
        ~AngSocket();
        int init();
        int bind();
        int setsockopt(int level, int option, const void* value, socklen_t value_length);
        int getsockopt(int level, int option, void* value, socklen_t* value_length);
        ssize_t recvfrom( void* buf, size_t n, int flags, struct sockaddr* src_addr, socklen_t* src_addr_length);
        ssize_t sendto(const void *buf, size_t buffsize, int flags, struct sockaddr *addr, socklen_t addr_len);
        static int createSockaddrIn(sockaddr_in& address, const char *ip, int port);
        static UdpHead createUdpHead(uint8_t act, uint8_t type, uint16_t id, uint32_t seq, uint32_t ts);

    private:
        int socket_fd_;

    };
}

#endif //_ANG_SOCKET_H_
