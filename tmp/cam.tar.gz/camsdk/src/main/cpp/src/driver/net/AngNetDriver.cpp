/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "AngNetDriver.h"
#include "AngDefines.h"

using namespace ang;

int const CMD_MAX_LEN = 60;

int const BUF_SIZE = 1024;

int const PACKET_SIZE = 1024;

int const UDP_MAX_PACKET_SIZE = 1472;

int const UDP_MAX_KERNEL_BUFF_SIZE = 5 * 1024 * 1024;

static int const UDP_MAX_OTA_PACKET_SIZE = 255;

int const HEAD_SIZE = 12;

int const FRAME_WIDTH = 640;
int const FRAME_HEIGHT = 642;
int const FRAME_BUFF_SIZE = FRAME_WIDTH * FRAME_HEIGHT * 2;

int const CMD_TIME_OUT = 5;//XU指令超时时间，单位：秒
int const RECEIVE_TIME_OUT = 5;//接收UDP数据超时时间，单位：秒
int const RECEIVE_BROADCAST_TIME_OUT = 50;//接收UDP广播超时时间，单位：毫秒
int const SEND_TIME_OUT = 5;//发送UDP数据超时时间，单位：秒

int const XU_DATA_INDEX = 12;//UDP XU协议数据偏移量

#define MAX_PACKET_SIZE 60 //一次最多只能传输60字节
#define ACK		0x06 	//指令正常
#define NAK		0x15	//指令异常
#define WAIT	0x18	//指令正在处理
#define CMD_HANDSHAKE	0x88

Mutex auto_cmd_mutex_;

NetDriver::NetDriver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type)
        : Driver(descriptor, devInfo, driver_type), cmd_seq_(0),
          socket_ptr_(nullptr),
          frame_pool_(nullptr),
          ang_heartbeat_thread_(std::make_shared<AngThread>()),
          post_frame_thread_(std::make_shared<AngThread>()),
          receive_net_data_thread_(std::make_shared<AngThread>()) {
    address_info_.ip = devInfo->net.ip;
    address_info_.port = devInfo->net.port;
}

NetDriver::~NetDriver() noexcept {
}

int NetDriver::sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) {
    Mutex::Autolock _l(auto_cmd_mutex_);

    int ret = 0;

    xu_req_ = req;
    cmd_receive_buf_len_ = 0;
    cmd_data_info data_info;
    data_info.udp_head.act = 0xff;
    data_info.udp_head.type = 0x01;
    data_info.udp_head.id = 0x01;
    data_info.udp_head.seq = cmd_seq_++;
    data_info.cmd_head.type = type;
    data_info.cmd_head.req = req;
    data_info.cmd_head.value = 0x01;
    data_info.cmd_head.index = 0x0a;
    data_info.cmd_head.length = buf_size;
    data_info.data = buf;

    int len = 0;
    len += sizeof(UdpHead);
    len += sizeof(CmdHead);
    len += data_info.cmd_head.length;
    uint8_t send_data[len];
    memset(send_data, 0, len);

    memcpy(send_data, &data_info.udp_head, sizeof(UdpHead));
    memcpy(send_data + sizeof(UdpHead), &data_info.cmd_head, sizeof(CmdHead));
    memcpy(send_data + sizeof(UdpHead) + sizeof(CmdHead), data_info.data,
           data_info.cmd_head.length);

    struct timeval timeout;
    timeout.tv_sec = SEND_TIME_OUT;
    timeout.tv_usec = 0;
    socket_ptr_->setsockopt(SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    cmd_respond_ready_.store(false, std::memory_order_release);

    int send_size = socket_ptr_->sendto(send_data, len, 0, (sockaddr *) &sockaddr_in_,
                                        sizeof(sockaddr_in_));
    if (send_size < 0) {
        ANG_LOGE("failed to send %x to device, errno:%s", req, strerror(errno));
        return ANG_STATUS_FAILED;
    }
    int rc = ANG_STATUS_SUCCESS;
    if (!cmd_respond_ready_.load(std::memory_order_acquire)) {
        rc = xu_cmd_cond_.wait(xu_cmd_mutex_, CMD_TIME_OUT * 1000);
    }

    if (!(req == CMD_UPCODE || req == CMD_UPDATE_KERNEL || req == CMD_UPDATE_ISP || req == CMD_UPDATE_HiMAX
        || req == CMD_UPDATE_IVP || req == CMD_UPDATE_HiMAX || req == CMD_UPDATE_SCAN_CODE ||
        req == CMD_HANDSHAKE || buf_size == UDP_MAX_OTA_PACKET_SIZE)) {
        ANG_LOGI("sendCmdMessage type:%x, req:%x, buf_size:%d, seq:%d", type, req, buf_size, data_info.udp_head.seq);
    }

    if (rc == ANG_STATUS_SUCCESS) {
        ret = cmd_receive_buf_len_;
//        ANG_LOGI("sendCmdMessage respond:%s", cmd_receive_buf_);
        if (cmd_receive_buf_len_ > buf_size) {
            ANG_LOGE("sendCmdMessage failed, buf_size:%d:%d is not enough", buf_size, cmd_receive_buf_len_);
            memset(cmd_receive_buf_, 0, UDP_MAX_PACKET_SIZE);
            cmd_receive_buf_len_ = 0;
            return ANG_STATUS_FAILED;
        }
        if (buf)
            memcpy(buf, cmd_receive_buf_, cmd_receive_buf_len_);

        memset(cmd_receive_buf_, 0, UDP_MAX_PACKET_SIZE);
        cmd_receive_buf_len_ = 0;
    } else {
        ANG_LOGI("xu_cmd_cond_ wait timeout, cmd seq:%d, rc:%d, errno[%d]:%s", (cmd_seq_-1), rc, errno, strerror(errno));
        memset(cmd_receive_buf_, 0, UDP_MAX_PACKET_SIZE);
        cmd_receive_buf_len_ = 0;
        return ANG_STATUS_FAILED;
    }
    return ret;
}

void *NetDriver::heartbeatThread(void *pThreadParam) {
    auto device = static_cast<NetDriver *>(pThreadParam);
    ANG_LOGI("heartbeatThread start :%s", device->address_info_.ip.c_str());
    int rc;
    device->heartbeat_running_ = true;
    socklen_t slen = sizeof(device->sockaddr_in_);
    device->heartbeat_seq_ = 1;
    auto send_packet = AngSocket::createUdpHead(0xff, 0x01, 0x02, device->heartbeat_seq_, 0);
    uint8_t send_buf[13];
    memset(send_buf, 0, 13);

    send_buf[0] = send_packet.act;
    send_buf[1] = send_packet.type;
    SHORT_TO_SW(send_packet.id, &send_buf[2]);
    INT_TO_DW(device->heartbeat_seq_, &send_buf[4]);

    struct timeval timeout;
    timeout.tv_sec = SEND_TIME_OUT;
    timeout.tv_usec = 0;
    device->socket_ptr_->setsockopt(SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    int tryCount = 5;
    device->connected_ = false;
    while (device->heartbeat_running_) {
        INT_TO_DW(device->heartbeat_seq_++, &send_buf[4]);
//        ANG_LOGI("send heartbeat:%d", device->heartbeat_seq_-1);
        int send_size = device->socket_ptr_->sendto(send_buf, sizeof(send_buf), 0,
                                                    (sockaddr *) &device->sockaddr_in_, slen);
        if (send_size <= 0) {
            ANG_LOGE("failed to send heartbeat packet, errno:%s", strerror(errno));
        } else {
//            ANG_LOGI("send heartbeat packet success:%d", send_size);
        }
        sleep(1);
    }
    rc = device->ang_heartbeat_thread_->detach();
    if (rc != 0) {
        ANG_LOGE("ang_heartbeat_thread_ detach failed, rc:%d, errno:%s", rc, strerror(errno));
    }
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_LOGI("heartbeatThread end");
    return nullptr;
}

void *NetDriver::postFrameThread(void *pThreadParam) {
    auto driver = static_cast<NetDriver *>(pThreadParam);
    ANG_LOGI("postFrameThread start");
    driver->frame_running_ = true;
    while (driver->frame_running_) {
        int rc = ANG_STATUS_SUCCESS;
        rc = driver->frame_cond_.wait(driver->frame_mutex_, 100);
        if (rc != ANG_STATUS_SUCCESS) {
//            ANG_LOGI("postFrameThread wait timeout");
            continue;
        }
        if (driver->frame_callback_) {
            if (!driver->frame_pool_->empty()) {
                std::shared_ptr<Frame> angFrame = driver->frame_pool_->pop_frame_buffer();
                driver->frame_callback_(driver->sensor_handle_, angFrame);
                driver->frame_ready_ = true;
            }
        }
    }
    int rc = driver->post_frame_thread_->detach();
    if (rc != 0) {
        ANG_LOGE("post_frame_thread_ detach failed, rc:%d, errno:%s", rc, strerror(errno));
    }
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_LOGI("postFrameThread end");
    return nullptr;
}

void *NetDriver::receiveNetDataThread(void *pThreadParam) {
    auto driver = static_cast<NetDriver *>(pThreadParam);
    ANG_LOGI("receiveNetDataThread start");
    driver->receive_data_running_ = true;
    int rc;
    socklen_t slen = sizeof(driver->sockaddr_in_);
    char ret_pack[HEAD_SIZE];
    uint8_t recv_buff[UDP_MAX_PACKET_SIZE];
    memset(recv_buff, 0, sizeof(recv_buff));
    int frame_buf_index = 0;

    driver->frame_seq_ = 0;

    if (!driver->cmd_receive_buf_)
        driver->cmd_receive_buf_ = static_cast<uint8_t *>(malloc(UDP_MAX_PACKET_SIZE));
    if (!driver->frame_receive_buf_)
        driver->frame_receive_buf_ = static_cast<uint8_t *>(malloc(FRAME_BUFF_SIZE));

    struct timeval timeout;
    timeout.tv_sec = RECEIVE_TIME_OUT;
    timeout.tv_usec = 0;
    driver->socket_ptr_->setsockopt(SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    struct timeval timeout_send;
    timeout_send.tv_sec = SEND_TIME_OUT;
    timeout_send.tv_usec = 0;
    driver->socket_ptr_->setsockopt(SOL_SOCKET, SO_SNDTIMEO, &timeout_send, sizeof(timeout_send));

    //设置socket kernel层读取buffer缓存大小，该选项可以有效解决UDP丢包的问题
    int recev_size = UDP_MAX_KERNEL_BUFF_SIZE;
    int s = sizeof(recev_size);
    driver->socket_ptr_->setsockopt(SOL_SOCKET , SO_RCVBUF , &recev_size , s);

    uint32_t packet_index_old = -1;
    bool has_bad_packet = false;
    driver->total_size_ = 0.f;
    while (driver->receive_data_running_) {
        memset(recv_buff, 0, UDP_MAX_PACKET_SIZE);
        int recv_size = driver->socket_ptr_->recvfrom(recv_buff, UDP_MAX_PACKET_SIZE, 0,
                                                      (sockaddr *) &driver->sockaddr_in_, &slen);
        if (recv_size <= 0) {
            ANG_LOGE("receive data error, errno:%s", strerror(errno));
            continue;
        }

        int data_len = recv_size - HEAD_SIZE;
        if (data_len < 0) {
            ANG_LOGE("receive data error, recv_size:%d, data_len:%d", recv_size, data_len);
            continue;
        }

        // receive heartbeat packet
        if (recv_buff[0] == 0xfe && recv_buff[1] == 0x01 && recv_buff[2] == 0x02) {
//            ANG_LOGI("receive heartbeat packet seq:%d", DW_TO_INT(&recv_buff[4]));
            continue;
        }

        // receive cmd packet
        if (recv_buff[0] == 0xfe && recv_buff[1] == 0x01 && recv_buff[2] == 0x01) {
//            for (int i = 0; i < recv_size; ++i) {
//                ANG_LOGI("cmd_data[%d]:%x", i, recv_buff[i]);
//            }

            if (data_len > 0) {
                bool ota_cmd = false;
                uint8_t req = req = recv_buff[13];
                if (req == CMD_UPCODE || req == CMD_UPDATE_KERNEL || req == CMD_UPDATE_ISP ||
                        req == CMD_UPDATE_HiMAX || req == CMD_UPDATE_IVP || req == CMD_UPDATE_HiMAX
                        || req == CMD_UPDATE_SCAN_CODE || req == CMD_HANDSHAKE || data_len > CMD_MAX_LEN) {
                    ota_cmd = true;
                }
                if (data_len > CMD_MAX_LEN && (!ota_cmd)) {
                    ANG_LOGE("cmd recv len is error, data_len:%d, xu_req_:%x, buf[13]:%x", data_len, driver->xu_req_, recv_buff[13]);
                }

                int len = std::min(data_len, UDP_MAX_PACKET_SIZE);
                memset(driver->cmd_receive_buf_,0 ,UDP_MAX_PACKET_SIZE);
                memcpy(driver->cmd_receive_buf_, &recv_buff[XU_DATA_INDEX], UDP_MAX_PACKET_SIZE-XU_DATA_INDEX);
                driver->cmd_receive_buf_len_ = len;
            } else {
                memset(driver->cmd_receive_buf_,0 ,UDP_MAX_PACKET_SIZE);
                driver->cmd_receive_buf_len_ = 0;
            }

            driver->cmd_respond_ready_.store(true, std::memory_order_release);
            /**
             * 由于编译器或CPU重排，xu_cmd_cond_.notify有可能会在cmd_respond_ready_ = true前执行，
             * 从而导致xu_cmd_cond_概率性唤醒失败。
             * 可以使用std::atomic_thread_fence内存屏障来防止编译器和CPU进行重排。
             * std::atomic_thread_fence使用std::memory_order_release内存序，
             * std::atomic_thread_fence作用是保证在它之前的内存操作在其之前执行，而在它之后的内存操作在其之后执行，
             * 从而保证cmd_respond_ready_在xu_cmd_cond_.notify之前执行
             */
            std::atomic_thread_fence(std::memory_order_release);

            rc = driver->xu_cmd_cond_.notify(driver->xu_cmd_mutex_);

            if (driver->xu_req_ == DISCONNECT) {
                ANG_LOGI("receive DISCONNECT cmd packet, finish receive net thread");
                driver->receive_data_running_ = false;
            }
            continue;
        }

        if (driver->frame_running_) {
            // receive common stream packet
            if (recv_buff[0] == 0xff && recv_buff[1] == 0x00 && recv_buff[2] == 0x00) {
                if (data_len <= 0) {
                    ANG_LOGE("receive common stream packet error, data_len:%d", data_len);
                    continue;
                }

                uint32_t frame_packet_index = DW_TO_INT(&recv_buff[4]);
                if (packet_index_old != -1 && (frame_packet_index != packet_index_old+1)) {
                    ANG_LOGE("frame packet loss, old packet:%d, last packet:%d, data_len:%d",
                             packet_index_old, frame_packet_index, data_len);
                    has_bad_packet = true;
                }
                packet_index_old = frame_packet_index;

                if (frame_buf_index > FRAME_BUFF_SIZE) {
                    ANG_LOGE("common stream packet error, frame_buf_index:%d", frame_buf_index);
                    frame_buf_index = 0;
                    continue;
                }
                memcpy(driver->frame_receive_buf_ + frame_buf_index, recv_buff + HEAD_SIZE,
                       data_len);
                frame_buf_index += data_len;
            }
            // receive last stream packet
            else if (recv_buff[0] == 0xff && recv_buff[1] == 0x01 && recv_buff[2] == 0x00) {

                uint32_t frame_packet_index = DW_TO_INT(&recv_buff[4]);
                if (frame_packet_index != packet_index_old+1) {
                    has_bad_packet = true;
                    ANG_LOGE("last frame packet loss, old packet:%d, last packet:%d", packet_index_old, frame_packet_index);
                }
                packet_index_old = frame_packet_index;

                if (frame_buf_index + data_len > FRAME_BUFF_SIZE) {
                    ANG_LOGE("frame packet error, frameSize:%d", frame_buf_index + data_len);
                    frame_buf_index = 0;
                    continue;
                }

                auto angFrame = driver->frame_pool_->get_frame_buffer();
                memcpy(driver->frame_receive_buf_ + frame_buf_index, recv_buff + HEAD_SIZE,
                       data_len);

                frame_buf_index += data_len;

                AngFrame frame_t;
                frame_t.size_ = frame_buf_index;
                frame_t.width_ = driver->width_;
                frame_t.height_ = driver->height_;
                frame_t.type_ = ANG_FRAME_COLOR;
                frame_t.format_ = ANG_FRAME_FORMAT_MJPEG;
                frame_t.index_ = ++driver->index_;
                frame_t.data_ = driver->frame_receive_buf_;
                ang::NetDriver::createFrame(frame_t, angFrame);

                driver->total_size_ += frame_t.size_;
                driver->frame_seq_++;
                driver->frame_respond_ready_ = true;
                driver->frame_cond_.notify(driver->frame_mutex_);

                if (!has_bad_packet) {
                    driver->frame_count_++;
                } else {
                    has_bad_packet = false;
                }
//                ANG_LOGI("========>frameLen:%d, frameCount:%d", frame_buf_index, driver->frame_count_);
                if (angOsGetTime() - driver->time_old_ >= 1000 * 1000) {
                    ANG_LOGI("frameLen:%d, frameCount:%d, %.2f mb/s",
                             frame_buf_index, driver->frame_count_, driver->total_size_/1048576.f);
                    driver->time_old_ = angOsGetTime();
                    driver->frame_count_ = 0;
                    driver->total_size_ = 0.f;
                }
                frame_buf_index = 0;
                memcpy(ret_pack, recv_buff, HEAD_SIZE);
                ret_pack[0] = 0xfe;
                // send last stream ack packet to device
                if ((driver->socket_ptr_->sendto(ret_pack, HEAD_SIZE, 0,
                                                 (struct sockaddr *) &driver->sockaddr_in_, slen)) <
                    0) {
                    ANG_LOGE("failed to send ack packet to device:%s", strerror(errno));
                } else {
//                ANG_LOGI("send ack packet to device success");
                }

                continue;
            }
        }
    }

    rc = driver->receive_net_data_thread_->detach();
    if (rc != 0) {
        ANG_LOGE("receive_net_data_thread_ detach failed, rc:%d, errno:%s", rc, strerror(errno));
    }
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_LOGI("receiveNetDataThread end");
    return nullptr;
}

int NetDriver::init(int interface) {
    return 0;
}

int NetDriver::shutdown() {
    return 0;
}

bool NetDriver::sendBroadcast() {
    ANG_LOGI("sendBroadcast start :%s", address_info_.ip.c_str());
    int rc;
    socklen_t slen = sizeof(sockaddr_in_);
    auto send_packet = AngSocket::createUdpHead(0xff, 0x01, 0x02, 0, 0);
    uint8_t send_buf[13];
    memset(send_buf, 0, 13);

    send_buf[0] = send_packet.act;
    send_buf[1] = send_packet.type;
    SHORT_TO_SW(send_packet.id, &send_buf[2]);
    INT_TO_DW(0, &send_buf[4]);

    struct timeval timeout;
    timeout.tv_sec = SEND_TIME_OUT;
    timeout.tv_usec = 0;
    socket_ptr_->setsockopt(SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    int tryCount = 5;
    while (tryCount-- > 0) {
        int send_size = socket_ptr_->sendto(send_buf, sizeof(send_buf), 0,
                                            (sockaddr *) &sockaddr_in_, slen);
        if (send_size <= 0) {
            ANG_LOGE("failed to send broadcast packet, errno:%s", strerror(errno));
            usleep(100 * 1000);
            continue;
        }

        socklen_t slen = sizeof(sockaddr_in_);
        char recv_buff[BUF_SIZE]{0};
        memset(recv_buff, 0, sizeof(recv_buff));
        int recv_size = socket_ptr_->recvfrom(recv_buff, sizeof(recv_buff), 0,
                                              (struct sockaddr *) &sockaddr_in_, &slen);
        if (recv_size <= 0) {
            ANG_LOGE("failed to get broadcast packet, ip:%s, port:%d", address_info_.ip.c_str(),
                     address_info_.port);
            usleep(100 * 1000);
            continue;
        }

        if (recv_size > HEAD_SIZE) {
            std::string str_recv_buff = recv_buff + HEAD_SIZE;
            std::string type_key = "Type:";
            std::string type_tartget = "Hp60cn";
            int type_index = str_recv_buff.find(type_key);
            if (type_index == -1) {
                ANG_LOGE("receive buf is not right:%s", str_recv_buff.c_str());
                usleep(100 * 1000);
                continue;
            }
            std::string str_type = str_recv_buff.substr(type_index + type_key.size());
            if (str_type != type_tartget) {
                ANG_LOGE("str_type[%s] != type_tartget[%s]", str_type.c_str(),
                         type_tartget.c_str());
                usleep(100 * 1000);
                continue;
            }
            return true;
        } else {
            ANG_LOGE("get broadcast packet recv_size error:%d", recv_size);
            usleep(100 * 1000);
            continue;
        }
    }
    return false;
}

int NetDriver::open(int fd) {
    ANG_LOGI("open start %s", address_info_.ip.c_str());
    socket_ptr_ = std::make_unique<AngSocket>();
    int rc = socket_ptr_->init();
    if (rc != ANG_STATUS_SUCCESS) {
        socket_ptr_.reset();
        ANG_LOGE("openDevice failed, socket init failed");
        return ANG_STATUS_FAILED;
    }

    rc = AngSocket::createSockaddrIn(sockaddr_in_, address_info_.ip.c_str(), address_info_.port);
    ANG_LOGI("createSockaddrIn ip:%s, port:%d", address_info_.ip.c_str(), address_info_.port);

    if (rc != ANG_STATUS_SUCCESS) {
        ANG_LOGE("openDevice failed, createSockaddrIn failed, ip:%s, port:%d",
                address_info_.ip.c_str(), address_info_.port);
        return ANG_STATUS_FAILED;
    }

    bool ret = sendBroadcast();
    if (!ret) {
        ANG_LOGE("sendBroadcast failed");
        return ANG_STATUS_FAILED;
    }

    ang_heartbeat_thread_->create(heartbeatThread, this);

    struct timeval timeout;
    timeout.tv_sec = RECEIVE_TIME_OUT;
    timeout.tv_usec = 0;
    socket_ptr_->setsockopt(SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    socklen_t slen;
    slen = sizeof(sockaddr_in_);
    int tryCount = 10;
    while (tryCount-- > 0) {
        uint8_t recv_buff[PACKET_SIZE];
        memset(recv_buff, 0, sizeof(recv_buff));
        int recv_size = socket_ptr_->recvfrom(recv_buff, sizeof(recv_buff), 0,
                                              (struct sockaddr *) &sockaddr_in_, &slen);
        if (recv_size <= 0) {
            ANG_LOGE("connect to device FAILED, ip:%s, port:%d", address_info_.ip.c_str(),
                     address_info_.port);
            continue;
        }

        // receive heartbeat packet
        if (recv_buff[0] == 0xfe && recv_buff[1] == 0x01 && recv_buff[2] == 0x02) {
            ANG_LOGI("connect to device successful, ip:%s, port:%d", address_info_.ip.c_str(),
                     address_info_.port);
            receive_net_data_thread_->create(receiveNetDataThread, this);
            int waitCount = 100;
            while (!receive_data_running_ && waitCount-- > 0) {
                usleep(1*1000);
            }
            connected_ = true;
            ANG_LOGI("openDevice end");
            return ANG_STATUS_SUCCESS;
        }
    }

    ANG_LOGE("connect to device failed, ip:%s, port:%d", address_info_.ip.c_str(),
            address_info_.port);
    heartbeat_running_ = false;
    tryCount = 100;
    while (ang_heartbeat_thread_->get_status() && tryCount > 0) {
        usleep(20 * 1000);
        tryCount--;
    }
    if (ang_heartbeat_thread_->get_status()) {
        ANG_LOGI("terminate heartbeat thread");
        ang_heartbeat_thread_->terminate();
    }

    return ANG_STATUS_FAILED;
}

int NetDriver::close() {
    ANG_LOGI("close start");
    heartbeat_running_ = false;
    int tryCount = 100;
    while (ang_heartbeat_thread_->get_status() && tryCount > 0) {
        usleep(20 * 1000);
        tryCount--;
    }
    if (ang_heartbeat_thread_->get_status()) {
        ANG_LOGI("terminate heartbeat thread");
        ang_heartbeat_thread_->terminate();
    }

    int rc = sendCmdMessage(CMD_SET, DISCONNECT, nullptr, 0);
    ANG_LOGI("closeDevice DISCONNECT end, rc:%d", rc);
    receive_data_running_ = false;

    tryCount = 100;
    while (receive_net_data_thread_->get_status() && tryCount > 0) {
        usleep(20 * 1000);
        tryCount--;
    }
    if (receive_net_data_thread_->get_status()) {
        ANG_LOGI("terminate receive net data thread");
        receive_net_data_thread_->terminate();
    }

    if (cmd_receive_buf_) {
        free(cmd_receive_buf_);
        cmd_receive_buf_ = nullptr;
    }

    if (frame_receive_buf_) {
        free(frame_receive_buf_);
        frame_receive_buf_ = nullptr;
    }
    socket_ptr_.reset();
    ANG_LOGI("closeDevice end");
    return ANG_STATUS_SUCCESS;
}

long NetDriver::getUsbHandle() {
    return 0L;
}

int NetDriver::startStream(long sensorHandle, ang_stream_config* streamConfig,
                               FrameCallback callback) {
    ANG_LOGI("startStream start");
    int rc = sendCmdMessage(CMD_SET, STREAM_ON, nullptr, 0);
    ANG_LOGI("startStream STREAM_ON end, rc:%d", rc);
    if (rc < 0) {
        ANG_LOGE("startStream failed");
        return ANG_STATUS_FAILED;
    }

    frame_callback_ = callback;
    sensor_handle_ = sensorHandle;
    frame_running_ = true;

    //申请后处理的frame buffer池，buffer池大小为3
    frame_pool_ = std::make_unique<AngFramePool>(FRAME_BUFF_SIZE);
    post_frame_thread_->create(postFrameThread, this);
    time_old_ = angOsGetTime();
    frame_count_ = 0;
    ANG_LOGI("startStream end");
    return ANG_STATUS_SUCCESS;
}

int NetDriver::stopStream() {
    ANG_LOGI("stopStream start");
    int rc = sendCmdMessage(CMD_SET, STREAM_OFF, nullptr, 0);
    ANG_LOGI("stopStream STREAM_OFF end, rc:%d", rc);
    frame_running_ = false;
    int tryCount = 100;
    while (post_frame_thread_->get_status() && tryCount > 0) {
        usleep(20 * 1000);
        tryCount--;
    }
    if (post_frame_thread_->get_status()) {
        ANG_LOGI("terminate post frame thread");
        post_frame_thread_->terminate();
    }
    frame_pool_.reset();
    if (rc < 0) {
        ANG_LOGE("stopStream failed");
        return ANG_STATUS_FAILED;
    }
    return ANG_STATUS_SUCCESS;
}

int NetDriver::switchConfig(ang_stream_config* streamConfig) {
    return 0;
}

int NetDriver::updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) {
    return 0;
}