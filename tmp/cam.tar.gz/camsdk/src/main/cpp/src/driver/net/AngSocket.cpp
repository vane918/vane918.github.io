/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include "AngSocket.h"
#include "AngLog.hpp"

using namespace ang;

static bool checkSocket(int fd);

AngSocket::AngSocket() : socket_fd_(-1){

}

AngSocket::~AngSocket() {
    if (checkSocket(socket_fd_))
        ::close(socket_fd_);
}

int AngSocket::init() {
    socket_fd_ = socket(AF_INET, SOCK_DGRAM,0);
    if (!checkSocket(socket_fd_)) {
        ANG_LOGE("socket failed, errno:%s", strerror(errno));
        return -1;
    }

    return 0;
}

int AngSocket::bind() {
    if (!checkSocket(socket_fd_))
        return -1;

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT_BROADCAST);
    addr.sin_addr.s_addr = INADDR_ANY;
    if (::bind(socket_fd_, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        ANG_LOGE("bind failed, errno:%s", strerror(errno));
        return -1;
    }

    return 0;
}

int AngSocket::setsockopt(int level, int option, const void* value, socklen_t value_length) {
    if (!checkSocket(socket_fd_))
        return -1;

    if (::setsockopt(socket_fd_, level, option, value, value_length) < 0) {
        ANG_LOGE("setsockopt failed, errno:%s", strerror(errno));
        return -1;
    }
    return 0;
}

int AngSocket::getsockopt(int level, int option, void* value, socklen_t* value_length) {
    if (!checkSocket(socket_fd_))
        return -1;

    if (::getsockopt(socket_fd_, level, option, value, value_length) < 0) {
        ANG_LOGE("getsockopt failed, errno:%s", strerror(errno));
        return -1;
    }
    return 0;
}

ssize_t AngSocket::recvfrom(void *buf, size_t n, int flags, struct sockaddr *src_addr,
                            socklen_t *src_addr_length) {
    if (!checkSocket(socket_fd_))
        return -1;
    return ::recvfrom(socket_fd_, buf, n, flags, src_addr, src_addr_length);
}

ssize_t AngSocket::sendto(const void *buf, size_t buffsize, int flags, struct sockaddr *addr, socklen_t addr_len) {
    if (!checkSocket(socket_fd_))
        return -1;
    return ::sendto(socket_fd_, buf, buffsize, flags, addr, addr_len);
}

static bool checkSocket(int fd) {
    if (fd < 0) {
        ANG_LOGE("socket_fd_ is error:%d", fd);
        return false;
    }
    return true;
}

int AngSocket::createSockaddrIn(sockaddr_in& address, const char *ip, int port) {
    memset(&address,0, sizeof(sockaddr_in));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    int rc = inet_aton(ip, &address.sin_addr);
    if (rc == 0)
        return -1;
    else
        return 0;
}

/**
 *Atc	数据包功能，用于区分 发送/应答 包 		    0xFF/0xFE
 *Type 	可靠性标志，用于标识 控制/流 包 			0x01/0x00
 *Id	通道id，用于区分 流/控制/心跳 通道		    0x00/0x01/0x02
 *Seq	本包序列号							 	0 ~ 2^32
 *Time	发包时间戳，用于接收到应答时的RTT计算      0 ~ 2^32
**/
UdpHead AngSocket::createUdpHead(uint8_t act, uint8_t type, uint16_t id, uint32_t seq, uint32_t ts) {
    UdpHead udpHead;
    udpHead.act = act;
    udpHead.type = type;
    udpHead.id = id;
    udpHead.seq = seq;
    udpHead.ts = ts;
    return udpHead;
}