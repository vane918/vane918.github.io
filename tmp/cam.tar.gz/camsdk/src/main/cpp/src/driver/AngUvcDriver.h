/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_UVCDRIVER_H_
#define _ANG_UVCDRIVER_H_

#include <AngFramePool.h>
#include "AngCondition.hpp"
#include "AngThread.hpp"
#include "AngDriver.h"
#include "libuvc.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    typedef struct {
        uint8_t timeout_{0};
        uint8_t tryCount_{0};

    } monitorStream_st;

    class UvcDriver :
            public Driver {
    public:
        explicit UvcDriver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type);

        ~UvcDriver();

        int init(int interface) override;

        int shutdown() override;

        int open(int fd) override;

        int close() override;

        long getUsbHandle() override;

        int startStream(long sensorHandle, ang_stream_config* streamConfig,
                        FrameCallback callback) override;

        int stopStream() override;

        int switchConfig(ang_stream_config* streamConfig) override;

        int updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) override;

        int sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) override;

        long sensor_handle_{0};

        uvc_context_t *mContext{nullptr};
        uvc_device_t *mDevice{nullptr};
        uvc_device_handle_t *mDeviceHandle{nullptr};
        std::shared_ptr<AngDescriptor> usb_descriptor_;
        FrameCallback frame_callback_;
        std::unique_ptr<AngFramePool> frame_pool_;

        AngCondition frame_cond_;

        AngMutex frame_mutex_;

        monitorStream_st monitor_stream_st_;

    private:
        static ANG_THREAD_PROC streamPostThread_uvc(ANG_THREAD_PARAM pThreadParam);
        static ANG_THREAD_PROC streamMonitorThread(ANG_THREAD_PARAM pThreadParam);
        int restart();
        std::shared_ptr<AngThread> post_ang_frame_thread_{nullptr};
        std::shared_ptr<AngThread> monitor_stream_thread_{nullptr};
        StreamConfig stream_config_;
        std::atomic<bool> running_{false};
        std::atomic<bool> monitor_{false};
        std::atomic<bool> restarting_{false};
        std::atomic<bool> start_from_restart_{false};
        uint64_t monitor_time_{0};
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_VENDORDRIVER_H_
