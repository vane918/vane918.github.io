/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2023 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_NETDRIVER_H_
#define _ANG_NETDRIVER_H_

#include "NetTypes.h"
#include "AngSocket.h"

#include "AngDriver.h"
#include "AngFramePool.h"
#include "AngCondition.hpp"
#include "AngThread.hpp"

namespace ang {

    class NetDriver : public Driver {
    private:
        AddressInfo address_info_;
        sockaddr_in sockaddr_in_;
        std::unique_ptr<AngSocket> socket_ptr_;
        std::unique_ptr<AngFramePool> frame_pool_;
        std::atomic<bool> heartbeat_running_{false};
        std::atomic<bool> frame_running_{false};
        std::atomic<bool> receive_data_running_{false};
        std::atomic<bool> message_running_{false};
        std::atomic<bool> cmd_respond_ready_{false};
        std::atomic<bool> frame_respond_ready_{false};
        std::atomic<uint32_t> cmd_seq_{false};

        uint8_t* cmd_receive_buf_{nullptr};

        uint8_t cmd_receive_buf_len_;

        uint8_t* frame_receive_buf_{nullptr};

        uint8_t xu_req_;

        uint32_t frame_seq_;

        uint32_t heartbeat_seq_;

        uint64_t time_old_{0};
        uint32_t frame_count_{0};

        float total_size_{0.00};

        AngCondition xu_cmd_cond_;

        AngMutex xu_cmd_mutex_;

        AngCondition frame_cond_;

        AngMutex frame_mutex_;

        long sensor_handle_{0};

        std::shared_ptr<AngDescriptor> usb_descriptor_;
        FrameCallback frame_callback_;
        std::atomic<bool> running_{false};
        std::atomic<bool> connected_{false};

        static void* heartbeatThread(void * pThreadParam);

        static void* postFrameThread(void * pThreadParam);

        static void* receiveNetDataThread(void * pThreadParam);

        static void* messageThread(void * pThreadParam);

        bool sendBroadcast();

        std::shared_ptr<AngThread> ang_heartbeat_thread_{nullptr};
        std::shared_ptr<AngThread> post_frame_thread_{nullptr};
        std::shared_ptr<AngThread> receive_net_data_thread_{nullptr};

    public:

        explicit NetDriver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type);

        ~NetDriver();

        int init(int interface) override;

        int shutdown() override;

        int open(int fd) override;

        int close() override;

        long getUsbHandle() override;

        int startStream(long sensorHandle, ang_stream_config* streamConfig,
                        FrameCallback callback) override;

        int stopStream() override;

        int switchConfig(ang_stream_config* streamConfig) override;

        int updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) override;

        int sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) override;
    };

}

#endif //_ANG_NETDRIVER_H_
