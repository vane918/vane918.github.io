/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_VENDORDRIVER_H_
#define _ANG_VENDORDRIVER_H_

#include "AngDriver.h"
#include "AngCondition.hpp"
#include "AngThread.hpp"
#include "AngFramePool.h"

#include "libusbi.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    struct UsbHandle {
        libusb_context *context;
        libusb_device *device;
        libusb_device_handle *dev_handle;
        libusb_transfer *m_transfer;
    };

    typedef enum {
        CUSTOMER_TYPE_NONE = 0x80,
        CUSTOMER_TYPE_NORMAL = 0x81,//rgb+ir/deepth交替帧
        CUSTOMER_TYPE_CALIB = 0x82,//rgb+dot散斑图
        CUSTOMER_TYPE_RGB = 0x83,//仅rgb图
        CUSTOMER_TYPE_DISP = 0x84,//仅视差图
        CUSTOMER_TYPE_DEEPTH = 0x85,//仅深度图
        CUSTOMER_TYPE_UNKOWN = 0x86,
    } CustomerStreamType;

    class VendorDriver :
            public Driver {
    public:
        explicit VendorDriver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type);

        ~VendorDriver();

        int init(int interface) override;

        int shutdown() override;

        int open(int fd) override;

        int close() override;

        long getUsbHandle() override;

        int startStream(long sensorHandle, ang_stream_config* streamConfig,
                        FrameCallback callback) override;

        int stopStream() override;

        int switchConfig(ang_stream_config* streamConfig) override;

        int updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) override;

        int sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) override;

        std::atomic<bool> event_release_{false};

        AngCondition submit_cond_;

        AngMutex submit_mutex_;

        AngCondition frame_cond_;

        AngMutex frame_mutex_;

        AngCondition usb_event_cond_;

        AngMutex usb_event_mutex_;

        UsbHandle usb_handle_{nullptr};

        std::atomic<bool> running_{false};

        std::atomic<bool> usb_event_running_{false};

    private:
        int openDeviceByFd(int fd);

        static ANG_THREAD_PROC usbHandleEventThread(ANG_THREAD_PARAM pThreadParam);

        static ANG_THREAD_PROC streamReadThread(ANG_THREAD_PARAM pThreadParam);

        static ANG_THREAD_PROC streamPostThread(ANG_THREAD_PARAM pThreadParam);

        std::shared_ptr<AngThread> read_ang_frame_thread_{nullptr};
        std::shared_ptr<AngThread> post_ang_frame_thread_{nullptr};
        std::shared_ptr<AngThread> handle_usb_event_thread_{nullptr};
        std::atomic<bool> cancel_transfer_{};

        long sensor_handle_{0};
        int interface_num_{0};
        int endpoint_in_{0};
        int endpoint_out_{0};
        bool rgb_stream_{false};
        FrameCallback frame_callback_;
        std::unique_ptr<AngFramePool> frame_pool_;
        std::shared_ptr<AngDescriptor> descriptor_;
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_VENDORDRIVER_H_
