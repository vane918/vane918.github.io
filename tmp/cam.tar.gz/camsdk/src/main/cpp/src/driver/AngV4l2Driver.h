/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_V4L2DRIVER_H_
#define _ANG_V4L2DRIVER_H_

#ifdef _USE_V4L2_DRIVER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <asm/types.h>
#include <linux/videodev2.h>
#include <AngStreamConfig.h>

#include "AngCondition.hpp"
#include "AngThread.hpp"
#include "AngFramePool.h"
#include "AngDriver.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    //缓存的帧数
    const static int BUFFER_COUNT = 1;

    typedef struct VideoBuffer {
        void *start;
        size_t length;
    } VideoBuffer;

    class V4l2Driver :
            public Driver {
    public:
        explicit V4l2Driver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type);

        ~V4l2Driver();

        int init(int interface) override;

        int shutdown() override;

        int open(int fd) override;

        int close() override;

        long getUsbHandle() override;

        int startStream(long sensorHandle, ang_stream_config *streamConfig,
                        FrameCallback callback) override;

        int stopStream() override;

        int switchConfig(ang_stream_config *streamConfig) override;

        int updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) override;

        int sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) override;

        std::atomic<bool> running_{false};

        AngCondition frame_cond_;

        AngMutex frame_mutex_;

    private:
        static ANG_THREAD_PROC streamReadThread_v4l2(ANG_THREAD_PARAM pThreadParam);

        static ANG_THREAD_PROC streamPostThread_v4l2(ANG_THREAD_PARAM pThreadParam);

        int requestBuffers(struct v4l2_requestbuffers *reqbuf);

        int mapAndEnqueue(struct v4l2_requestbuffers *reqbuf, struct v4l2_buffer *buf,
                          VideoBuffer *framebuf);

        void cam_ummap(VideoBuffer *framebuf);

        int startCameraStreaming();

        int stopCameraStreaming();

        int deQueueBufferGetFrame(struct v4l2_buffer *buf);

        int enQueueBuffer(struct v4l2_buffer *buf);

        std::shared_ptr<AngThread> read_ang_frame_thread_{nullptr};
        std::shared_ptr<AngThread> post_ang_frame_thread_{nullptr};

        std::string video_node_{""};// dev/video*
        int fd_{0};

        struct v4l2_requestbuffers req_buf_;
        VideoBuffer frame_buff[BUFFER_COUNT];
        struct v4l2_buffer buf_;

        FrameCallback frame_callback_;
        long sensor_handle_{0};
        std::unique_ptr<AngFramePool> frame_pool_;
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif

#endif //_ANG_VENDORDRIVER_H_
