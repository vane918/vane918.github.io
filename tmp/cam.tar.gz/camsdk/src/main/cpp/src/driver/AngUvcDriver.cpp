/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <sys/prctl.h>

#include "AngUvcDriver.h"
#include "AngStreamConfig.h"

#include "libuvc_internal.h"

using namespace ang;

Mutex mutex_uvc_;
Mutex mutex_uvc_driver_;

UvcDriver::UvcDriver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type) :
        Driver(descriptor, devInfo, driver_type), usb_descriptor_(descriptor), mContext(nullptr),
        post_ang_frame_thread_(std::make_shared<AngThread>()), monitor_stream_thread_(std::make_shared<AngThread>()){
}

UvcDriver::~UvcDriver() {
    if (mContext) {
        uvc_exit(mContext);
        mContext = nullptr;
    }
}

int UvcDriver::init(int interface) {
    ANG_LOGI("UvcDriver[%s]::init", ang_dev_info_->usb.uid.c_str());
    return 0;
}

int UvcDriver::shutdown() {
    ANG_LOGI("UvcDriver[%s]::shutdown", ang_dev_info_->usb.uid.c_str());
    return 0;
}

int UvcDriver::open(int fd) {
    Mutex::Autolock _l(mutex_uvc_driver_);
    auto devices = usb_descriptor_->getUsbDeviceDescriptors();
    for (auto &it : *devices) {
        auto angDevInfo = it->getAngDevInfo();
        ANG_LOGI("open info:%s", angDevInfo->usb.dump().c_str());
        if (angDevInfo->usb.devpath == ang_dev_info_->usb.devpath) {
            ang_dev_info_ = angDevInfo;
            break;
        }
    }
    ANG_LOGI("UvcDriver[%s]::open fd:%d", ang_dev_info_->usb.uid.c_str(), fd);
    int result;
    unsigned short nVendorID = 0;
    unsigned short nProductID = 0;
    unsigned char nBus = 0;
    unsigned char nAddress = 0;

    sscanf(ang_dev_info_->usb.vid.c_str(), "%hx", &nVendorID);
    sscanf(ang_dev_info_->usb.pid.c_str(), "%hx", &nProductID);
    sscanf(ang_dev_info_->usb.bus.c_str(), "%hhu", &nBus);
    sscanf(ang_dev_info_->usb.dev.c_str(), "%hhu", &nAddress);

    ANG_LOGI("vid:%x, pid:%x, busnum:%d, devaddr:%d", nVendorID, nProductID, nBus, nAddress);
    if (fd > 0) {
#ifdef _USE_MAIN_LIBUVC_AND_LIBUSB
        //如果是libusb底层打开USB设备，则不需要设置LIBUSB_OPTION_NO_DEVICE_DISCOVERY
        result = libusb_set_option(NULL, LIBUSB_OPTION_NO_DEVICE_DISCOVERY, NULL);
        if (result != LIBUSB_SUCCESS) {
            ANG_LOGI("libusb_set_option failed: %d", result);
            return -1;
        }
        result = uvc_init(&mContext, NULL);
        if (UNLIKELY(result < 0)) {
            ANG_LOGE("failed to init libuvc:%d, errno:%d", result, errno);
            return result;
        }
        result = uvc_wrap(fd, mContext, &mDeviceHandle);
        if (UNLIKELY(result < 0)) {
            ANG_LOGE("uvc_wrap failed:%d", result);
            return result;
        }

        mDevice = uvc_get_device(mDeviceHandle);
        if (!mDevice)
            return result;

        ANG_LOGI("uvc_wrap uvc device done");
#else
        result = uvc_init2(&mContext, NULL, std::to_string(fd).c_str());
        if (UNLIKELY(result < 0)) {
            ANG_LOGE("failed to init2 libuvc:%d, errno:%d", result, errno);
            return result;
        }
        result = uvc_get_device_with_fd(mContext, &mDevice, nVendorID, nProductID, nullptr, fd, nBus, nAddress);
        ANG_LOGI("uvc_get_device_with_fd:%d", result);
        if (LIKELY(!result)) {
            ANG_LOGI("UvcDriver[%s]::uvc_open start", ang_dev_info_->usb.uid.c_str());
            result = uvc_open(mDevice, &mDeviceHandle);
            ANG_LOGI("UvcDriver[%s]::uvc_open result:%d", ang_dev_info_->usb.uid.c_str(), result);
            if (UNLIKELY(result)) {
                ANG_LOGE("could not open camera:err=%d", result);
                uvc_unref_device(mDevice);
                mDevice = nullptr;
                mDeviceHandle = nullptr;
                return -1;
            }
        } else {
            ANG_LOGE("could not find camera:err=%d", result);
            return -1;
        }
#endif
    }
    else {
        result = uvc_init(&mContext, NULL);
        if (UNLIKELY(result < 0)) {
            ANG_LOGE("failed to init libuvc:%d, errno:%d", result, errno);
            return result;
        }

        uvc_device_t **list;
        uvc_device_t *test_dev;
        int dev_idx;
        int found_dev;
        dev_idx = 0;
        found_dev = 0;
        result = uvc_get_device_list(mContext, &list);
        if (result != UVC_SUCCESS) {
            ANG_LOGI("uvc_get_device_list failed, result:%d", result);
            return result;
        }

        while (!found_dev && (test_dev = list[dev_idx++]) != NULL) {
            uint8_t address = uvc_get_device_address(test_dev);
            uvc_device_descriptor_t *desc;

            if (uvc_get_device_descriptor(test_dev, &desc) != UVC_SUCCESS)
                continue;

            if ((desc->idVendor == nVendorID)
                && (desc->idProduct == nProductID)
                && (address == nAddress))
                found_dev = 1;

            uvc_free_device_descriptor(desc);
        }

        if (found_dev)
            uvc_ref_device(test_dev);

        uvc_free_device_list(list, 1);

        if (found_dev) {
            mDevice = test_dev;
        } else {
            ANG_LOGE("uvc_get_device_list failed!");
            return UVC_ERROR_NO_DEVICE;
        }
        ANG_LOGI("UvcDriver[%s]::uvc_open start", ang_dev_info_->usb.uid.c_str());
        result = uvc_open(mDevice, &mDeviceHandle);
        ANG_LOGI("UvcDriver[%s]::uvc_open result:%d", ang_dev_info_->usb.uid.c_str(), result);
        if (!mDeviceHandle) {
            ANG_LOGE("UvcDriver[%s] open failed", ang_dev_info_->usb.uid.c_str());
            return ANG_STATUS_FAILED;
        }
        if (result != 0)
            return result;
    }

    return 0;
}

int UvcDriver::close() {
    Mutex::Autolock _l(mutex_uvc_driver_);
    ANG_LOGI("UvcDriver[%s]::close", ang_dev_info_->usb.uid.c_str());
    if (!mDeviceHandle) {
        ANG_LOGE("UvcDriver[%s] close failed", ang_dev_info_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
    if (LIKELY(mDeviceHandle)) {
        uvc_close(mDeviceHandle);
        ANG_LOGI("UvcDriver[%s]::close end", ang_dev_info_->usb.uid.c_str());
        mDeviceHandle = nullptr;
    }
    if (LIKELY(mDevice)) {
        uvc_unref_device(mDevice);
        mDevice = nullptr;
    }
    uvc_exit(mContext);
    mContext = nullptr;
    return 0;
}

long UvcDriver::getUsbHandle() {
    if (!mDeviceHandle) {
        ANG_LOGE("UvcDriver[%s] getUsbHandle failed", ang_dev_info_->usb.uid.c_str());
        return 0L;
    }
    return reinterpret_cast<long>(mDeviceHandle->usb_devh);
}

void uvcFameCallback(uvc_frame_t *frame, void *ptr) {
//    prctl(PR_SET_NAME, "ang-uvc-read-frame");
    auto driver = static_cast<UvcDriver *>(ptr);
    if (frame->data_bytes != driver->frame_size_ && frame->frame_format == UVC_FRAME_FORMAT_YUYV) {
        ANG_LOGI("UvcDriver[%s] receive %d len is wrong", driver->ang_dev_info_->usb.uid.c_str(), frame->data_bytes);
        return;
    }
    driver->frame_count_++;
    if ( angOsGetTime() - driver->time_old_ >= 1000 * 1000) {
        ANG_LOGI("UvcDriver[%s] frameLen:%d, frameCount:%d", driver->ang_dev_info_->usb.uid.c_str(),
                 frame->data_bytes, driver->frame_count_);
        driver->time_old_ = angOsGetTime();
        driver->frame_count_ = 0;
    }

    driver->frame_ready_ = true;
    driver->monitor_stream_st_.timeout_ = 1;
    driver->monitor_stream_st_.tryCount_ = 3;

    AngFrame frame_t;
    auto angFrame = driver->frame_pool_->get_frame_buffer();
    frame_t.size_ = frame->data_bytes;
    frame_t.width_ = frame->width;
    frame_t.height_ = frame->height;
    frame_t.format_ = static_cast<AngFormat>(frame->frame_format);
    frame_t.type_ = ANG_FRAME_COLOR;
    frame_t.index_ = ++driver->index_;
    frame_t.data_ = frame->data;
    ang::UvcDriver::createFrame(frame_t, angFrame);
//    driver->frame_callback_(driver->sensor_handle_, angFrame);
    driver->frame_cond_.notify(driver->frame_mutex_);
}

ANG_THREAD_PROC UvcDriver::streamPostThread_uvc(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("streamPostThread_uvc start");
    prctl(PR_SET_NAME, "ang-uvc-post-frame");
    auto driver = static_cast<UvcDriver *>(pThreadParam);
    int rc = 0;
    while (driver->running_) {
        rc = driver->frame_cond_.wait(driver->frame_mutex_, 100);
        if (rc == ANG_STATUS_SUCCESS) {
            if (driver->frame_callback_) {
                Mutex::Autolock _l(mutex_uvc_);
                if (!driver->frame_pool_->empty()) {
                    std::shared_ptr<Frame> angFrame = driver->frame_pool_->pop_frame_buffer();
                    driver->frame_callback_(driver->sensor_handle_, angFrame);
                }
            }
        } else {
//            ANG_LOGI("streamPostThread_uvc timeout");
        }
    }
    driver->post_ang_frame_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_LOGI("streamPostThread_uvc end");
    ANG_THREAD_PROC_RETURN(0);
}

ANG_THREAD_PROC UvcDriver::streamMonitorThread(ANG_THREAD_PARAM pThreadParam) {
    ANG_LOGI("streamMonitorThread start");
    prctl(PR_SET_NAME, "ang-monitor-stream");
    auto driver = static_cast<UvcDriver *>(pThreadParam);
    driver->monitor_time_ = angOsGetTime();
    uint64_t now = driver->monitor_time_;
    driver->monitor_stream_st_.timeout_ = 3;
    driver->monitor_stream_st_.tryCount_ = 3;
    while (driver->monitor_ && driver->monitor_stream_st_.tryCount_ > 0) {
        now = angOsGetTime();
        if (!driver->frame_ready_) {
            if (now - driver->monitor_time_ >= driver->monitor_stream_st_.timeout_ * 1000 * 1000) {
                driver->restart();
                if (driver->monitor_stream_st_.timeout_ < 3)
                    driver->monitor_stream_st_.timeout_++;
                driver->monitor_stream_st_.tryCount_--;
                driver->monitor_time_ = angOsGetTime();
            }
        } else {
            driver->monitor_time_ = now;
        }
        driver->frame_ready_ = false;
        angOSSleep(100);
    }
    driver->monitor_stream_thread_->detach();
    pthread_detach(pthread_self());//调用pthread_detach才会释放线程的资源
    ANG_LOGI("streamMonitorThread end, tryCount:%d", driver->monitor_stream_st_.tryCount_);
    ANG_THREAD_PROC_RETURN(0);
}

int UvcDriver::startStream(long sensorHandle, ang_stream_config* streamConfig,
                           FrameCallback callback) {
    if (!start_from_restart_) {
        while (restarting_) {
            angOSSleep(2);
        }
    }
    ANG_LOGI("UvcDriver[%s]::startStream", ang_dev_info_->usb.uid.c_str());
    if (!mDeviceHandle) {
        ANG_LOGE("UvcDriver[%s] startStream failed", ang_dev_info_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
    if (!streamConfig) {
        ANG_LOGE("UvcDriver[%s] startStream failed, streamConfig is null", ang_dev_info_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
    frame_ready_ = false;
    frame_callback_ = callback;
    sensor_handle_ = sensorHandle;
    index_ = 0;
    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
    int result = 0;
    ANG_LOGI("startStream width:%d, height:%d, fps:%d, format:%d", stream_config->getWidth(), stream_config->getHeight(),
             stream_config->getFps(), stream_config->getStreamFormat());

    stream_config_.width_ = stream_config->getWidth();
    stream_config_.height_ = stream_config->getHeight();
    stream_config_.fps_ = stream_config->getFps();
    stream_config_.format_ = stream_config->getStreamFormat();

    uvc_stream_ctrl_t ctrl;
    uvc_frame_format uvcFrameFormat = UVC_FRAME_FORMAT_YUYV;
    if (stream_config->getStreamFormat() == ANG_FRAME_FORMAT_YUYV)
        uvcFrameFormat = UVC_FRAME_FORMAT_YUYV;
    else if (stream_config->getStreamFormat() == ANG_FRAME_FORMAT_MJPEG)
        uvcFrameFormat = UVC_FRAME_FORMAT_MJPEG;

    result = uvc_get_stream_ctrl_format_size(mDeviceHandle, &ctrl,
                                             uvcFrameFormat,
                                             stream_config->getWidth(),
                                             stream_config->getHeight(),
                                             stream_config->getFps());
    if (result != 0) {
        ANG_LOGE("uvc_get_stream_ctrl_format_size failed :%d, errno:%s", result, strerror(errno));
        return result;
    }

    frame_size_ = stream_config->getWidth() * stream_config->getHeight() * 2;
    frame_pool_ = std::make_unique<AngFramePool>(frame_size_);
    running_ = true;
    monitor_ = true;
    ANG_LOGI("restarting_:%d", restarting_.load());
    if (!restarting_) {
        result = post_ang_frame_thread_->create(streamPostThread_uvc, this);
        result = monitor_stream_thread_->create(streamMonitorThread, this);
    }
    monitor_time_ = 0;

    ANG_LOGI("uvc_get_stream_ctrl_format_size end");
    void *user_ptr = (void *) this;
    result = uvc_start_streaming(mDeviceHandle, &ctrl, uvcFameCallback, user_ptr, 0);
    ANG_LOGI("uvc_start_streaming end");
    if (result < 0) {
        ANG_LOGE("start_streaming failed :%d", result);
        running_ = false;
        return result;
    }
    return 0;
}

int UvcDriver::stopStream() {
    Mutex::Autolock _l(mutex_uvc_driver_);
    ANG_LOGI("UvcDriver[%s]::stopStream", ang_dev_info_->usb.uid.c_str());
    if (!mDeviceHandle) {
        ANG_LOGE("UvcDriver[%s] stopStream failed", ang_dev_info_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
    running_ = false;
    monitor_ = false;
    uvc_stop_streaming(mDeviceHandle);
    ANG_LOGI("UvcDriver[%s]::stopStream end", ang_dev_info_->usb.uid.c_str());
    int tryCount = 100;
    while (monitor_stream_thread_->get_status() && tryCount > 0) {
        angOSSleep(10);
        tryCount--;
    }
    if (monitor_stream_thread_->get_status()) {
        ANG_LOGE("terminate monitor thread");
        monitor_stream_thread_->terminate();
    }
    tryCount = 100;
    while (post_ang_frame_thread_->get_status() && tryCount > 0) {
        angOSSleep(20);
        tryCount--;
    }
    if (post_ang_frame_thread_->get_status()) {
        ANG_LOGE("terminate post thread");
        post_ang_frame_thread_->terminate();
    }
    frame_callback_ = nullptr;
    if (frame_ready_ == false) {
        ANG_LOGE("UvcDriver[%s]::frame_ready_ is false", ang_dev_info_->usb.uid.c_str());
    }
    return 0;
}

int UvcDriver::switchConfig(ang_stream_config* streamConfig) {
    Mutex::Autolock _l(mutex_uvc_driver_);
    ANG_LOGE("UvcDriver[%s]::switchConfig", ang_dev_info_->usb.uid.c_str());
    if (!mDeviceHandle) {
        ANG_LOGE("UvcDriver[%s] switchConfig failed", ang_dev_info_->usb.uid.c_str());
        return ANG_STATUS_FAILED;
    }
    if (frame_callback_) {
        uvc_stop_streaming(mDeviceHandle);
        startStream(sensor_handle_, streamConfig, frame_callback_);
    }

    return 0;
}

int UvcDriver::updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) {
    ang_dev_info_ = devInfo;
    //todo:
    return ANG_STATUS_SUCCESS;
}

int UvcDriver::sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) {
    return ANG_STATUS_NOT_SUPPORT;
}

int UvcDriver::restart() {
    start_from_restart_ = true;
    Mutex::Autolock _l(mutex_uvc_driver_);
    if (frame_callback_) {
        ANG_LOGI("do restart monitor timeout:%d", monitor_stream_st_.timeout_);
        restarting_ = true;
        uvc_stop_streaming(mDeviceHandle);
        ANG_LOGI("uvc_stop_streaming end");
        int rc = startStream(sensor_handle_, reinterpret_cast<ang_stream_config *>(&stream_config_), frame_callback_);
        restarting_ = false;
        start_from_restart_ = false;
        ANG_LOGI("do restart end");
        return rc;
    }
    start_from_restart_ = false;
    return ANG_STATUS_FAILED;
}