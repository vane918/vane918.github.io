/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#ifndef _ANG_DRIVER_H_
#define _ANG_DRIVER_H_

#include <sys/prctl.h>

#include "AngDefines.h"
#include "AngDescriptors.h"
#include "AngLog.hpp"
#include "AngStreamConfig.h"
#include "AngFrame.h"
#include "AngUtil.h"
#include "Mutex.h"
#include "AngTypes.h"
#include "NetTypes.h"

ANG_NAMESPACE_IMPLEMENTATION_BEGIN

    typedef struct AngFrame {
        AngFrameType type_;
        uint16_t width_;
        uint16_t height_;
        AngFormat format_;
        uint64_t index_;
        void *data_;
        uint32_t size_;
        uint64_t timeStamp_;
    } AngFrame;

    class Driver {
    public:
        explicit Driver(std::shared_ptr<AngDescriptor> descriptor, std::shared_ptr<AngDevInfo> devInfo, AngDriverType driver_type) :
                ang_dev_info_(devInfo), driver_type_(driver_type){
        }

        virtual ~Driver() {
        }

        inline AngDriverType getDriverType() const{
            return driver_type_;
        }

        virtual int init(int interface) = 0;

        virtual int shutdown() = 0;

        virtual int open(int fd) = 0;

        virtual int close() = 0;

        virtual long getUsbHandle() = 0;

        virtual int startStream(long sensorHandle, ang_stream_config* streamConfig,
                                FrameCallback callback) = 0;

        virtual int stopStream() = 0;

        virtual int switchConfig(ang_stream_config* streamConfig) = 0;

        virtual int updateDevInfo(std::shared_ptr<AngDevInfo> devInfo) = 0;

        virtual int sendCmdMessage(UdpCmdType type, uint8_t req, uint8_t *buf, uint16_t buf_size) = 0;

        static void createFrame(AngFrame &angFrame, std::shared_ptr<Frame> frame) {
            frame->type_ = angFrame.type_;
            frame->width_ = angFrame.width_;
            frame->height_ = angFrame.height_;
            frame->format_ = angFrame.format_;
            frame->index_ = angFrame.index_;
            frame->size_ = angFrame.size_;
            frame->timeStamp_ = angFrame.timeStamp_;
            angOSMemSet(frame->data_, 0, frame->size_);
            angOSMemCopy(frame->data_, angFrame.data_, frame->size_);
        }

        int frame_size_{0};
        uint64_t time_old_{0};
        int frame_count_{0};
        bool frame_ready_{false};

        uint16_t width_{0};

        uint16_t height_{0};

        AngFormat format_{ANG_FRAME_FORMAT_UNKNOWN};

        uint64_t index_{0};

        std::shared_ptr<AngDevInfo> ang_dev_info_;
    protected:
        AngDriverType driver_type_;
    };

ANG_NAMESPACE_IMPLEMENTATION_END

#endif //_ANG_DRIVER_H_
