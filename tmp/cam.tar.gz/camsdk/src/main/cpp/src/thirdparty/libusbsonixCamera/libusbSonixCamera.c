#include "include/libusbSonixCamera.h"

extern libusb_ERROR_CODE gEC;
extern unsigned int libusb_uiRomID;

libusb_sonixbool libusb_SonixCam_RestartDevice(libusb_device_handle *devh)
{
	return libusb_LibUsb_RestartDevice(devh);
}


libusb_sonixbool libusb_SonixCam_GetAsicRomType(libusb_device_handle *devh, libusb_DSP_ROM_TYPE *romType)
{
	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE dspArchType;
	*romType = libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType);
	return libusb_TRUE;
}

libusb_ERROR_CODE libusb_SonixCam_GetErrorCode()
{
	return gEC;
}

libusb_sonixbool libusb_SonixCam_AsicRegisterRead(libusb_device_handle *devh, unsigned short addr, unsigned char pData[], long len)
{
	libusb_BYTE data = 0;
	libusb_USHORT startAddr = addr;
	libusb_LONG i = 0;
	for (i = 0; i < len; i++)
	{
		if (libusb_TRUE != libusb_LibUsb_ReadFromASIC(devh, (libusb_USHORT)startAddr++, &data))
			return libusb_FALSE;
		memcpy(pData + i, &data, 1);
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_AsicRegisterWrite(libusb_device_handle *devh, unsigned short addr, unsigned char pData[], long len)
{
	libusb_BYTE data = 0;
	libusb_LONG startAddr = addr;
	libusb_LONG i = 0;
	for (i = 0; i < len; i++)
	{
		data = pData[i];
		if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, (libusb_USHORT)startAddr++, data))
			return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_SensorRegisterRead(unsigned char slaveId, unsigned short addr, unsigned char pData[], long len)
{
	libusb_LONG loop = len / 3;
	libusb_LONG ram = len % 3;
	libusb_BYTE tempData[3] = { 0 };
	libusb_LONG i = 0;
	for (i = 0; i < loop; i++)
	{
		if (libusb_TRUE != libusb_LibUsb_ReadFromSensor(slaveId, (libusb_USHORT)addr, tempData, 3))
			return libusb_FALSE;
        memcpy(&pData[i * 3], tempData, 3);
	}
	if (ram)
	{
		if (libusb_TRUE != libusb_LibUsb_ReadFromSensor(slaveId, (libusb_USHORT)addr, tempData, ram))
			return libusb_FALSE;
        memcpy(&pData[loop * 3], tempData, ram);
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_SensorRegisterWrite(unsigned char slaveId, unsigned short addr, unsigned char pData[], long len)
{
	libusb_LONG loop = len / 3;
	libusb_LONG ram = len % 3;
	libusb_LONG i = 0;
	for (i = 0; i < loop; i++)
	{
		if (libusb_TRUE != libusb_LibUsb_WriteToSensor(slaveId, (libusb_USHORT)addr, &pData[i * 3], 3))
			return libusb_FALSE;
	}
	if (ram)
	{
		if (libusb_TRUE != libusb_LibUsb_WriteToSensor(slaveId, (libusb_USHORT)addr, &pData[loop * 3], ram))
			return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_LONG libusb_GetByteLengthFormAddr(libusb_LONG addr)
{
	if (addr <= 0xFF)
		return 1;
	else if (addr <= 0xFFFF)
		return 2;
	else if (addr <= 0xFFFFFF)
		return 3;
	else
		return 4;
}

libusb_sonixbool  libusb_SonixCam_SensorRegisterCustomRead(libusb_device_handle *devh, unsigned char slaveId, unsigned short  addr, unsigned short  addrByteNumber, unsigned char pData[], long dataByteNumber, libusb_sonixbool pollSCL)
{
	libusb_USHORT temp = 0;
	if (!libusb_LibUsb_CustomReadFromSensor(devh, slaveId, addr, addrByteNumber, &temp, dataByteNumber, pollSCL))
		return libusb_FALSE;
	if(dataByteNumber > 1){
		pData[0] = (libusb_BYTE)(temp >> 8);
		pData[1] = (libusb_BYTE)temp;
	}else{
		pData[0] = (libusb_BYTE)temp;
	}

	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_SensorRegisterCustomWrite(libusb_device_handle *devh, unsigned char slaveId, unsigned short addr, unsigned short  addrByteNumber, unsigned char pData[], long dataByteNumber, libusb_sonixbool pollSCL)
{
	libusb_USHORT temp = 0;
	if(dataByteNumber > 1){
		temp = (libusb_USHORT)((libusb_USHORT)pData[0] << 8) + pData[1];
	}else{
		temp = pData[0];
	}
	if (!libusb_LibUsb_CustomWriteToSensor(devh, slaveId, addr, addrByteNumber, temp, dataByteNumber, pollSCL))
		return libusb_false;

	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_GetSerialFlashType(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE *sft, libusb_sonixbool check)
{
	return libusb_LibUsb_GetSerialFlashType(devh, sft, check);
}

libusb_sonixbool  libusb_SonixCam_SerialFlashRead(libusb_device_handle *devh, long addr, unsigned char pData[], long len)
{
	return libusb_LibUsb_ReadFormSF(devh, addr, pData, len);
}

libusb_sonixbool libusb_SonixCam_SerialFlashWrite(libusb_device_handle *devh, long addr, unsigned char pData[], long len)
{
	libusb_LONG startAddr = addr;
	libusb_LONG loop = len / 8;
	libusb_LONG ram = len % 8;
	libusb_BYTE tempData[8];
	libusb_LONG i = 0;
	for (i = 0; i < loop; i++)
	{
		memcpy(tempData, pData + i * 8, 8);
		if (!libusb_LibUsb_WriteDataToFlash(devh, startAddr, tempData, 8))
			return libusb_FALSE;
		startAddr += 8;
	}

	if (ram > 0)
	{
		memset(&tempData, 0xFF, 8);
		memcpy(tempData, pData + (loop * 8), ram);
		if (!libusb_LibUsb_WriteDataToFlash(devh, startAddr, tempData, ram)){
			return libusb_FALSE;
		}
	}

	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_SerialFlashSectorWrite(libusb_device_handle *devh, long addr, unsigned char pData[], long len, libusb_SERIAL_FLASH_TYPE sft)
{
	return libusb_LibUsb_WriteToSF(devh, addr, pData, len, sft);
}


libusb_sonixbool  libusb_SonixCam_GetFwVersion(libusb_device_handle *devh, unsigned char pData[], long len, libusb_BOOL bNormalExport)
{
	libusb_BYTE RomValue[10] = { 0 };
	libusb_BOOL hr = libusb_LibUsb_GetAsicRomVersion(devh, RomValue);

	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE dspArchType;
	if (libusb_DRT_Unknow == libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType))
		return libusb_FALSE;

	libusb_BYTE FlashCodeVer[56] = { 0 };
	libusb_BYTE CusVer[31];
	libusb_BYTE DayVer[31];
	libusb_BYTE Customer[31];

	switch (chipID){
	case 0x15:
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x16:
		libusb_LibUsb_ReadFormSF(devh, 0x0FD0, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0148 + 11, FlashCodeVer, 5);
		break;
	case 0x20:
		libusb_LibUsb_ReadFormSF(devh, 0x5E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0 + 11, FlashCodeVer, 4);
		break;
	case 0x25:
		libusb_LibUsb_ReadFormSF(devh, 0x5E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x30:
		libusb_LibUsb_ReadFormSF(devh, 0x1E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
	case 0x31:
		if (!hr){
			return libusb_FALSE;
		}
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x1E00, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		}
		else if (RomValue[5] == 2){
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x1E00, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x1E00 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x1E00 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x01e8 + 11, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}

		break;
	case 0x32:
		if (!hr){
			return libusb_FALSE;
		}
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0148 + 11, FlashCodeVer, 5);
		}
		else if (RomValue[5] == 2){
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 18, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 28, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 10, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}
		break;
	case 0x36:
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x50:
		libusb_LibUsb_ReadFormSF(devh, 0x5E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x56:
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x70:
		libusb_LibUsb_ReadFormSF(devh, 0x3E05, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E0F, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E19, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, FlashCodeVer, 5);
		break;
	case 0x71:
		libusb_LibUsb_ReadFormSF(devh, 0x3E05, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E0F, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E19, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, FlashCodeVer, 5);
		break;
	case 0x75:
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}

		break;
	case 0x76: //128K
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x3FD0, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x3FD0 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x3FD0 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0148 + 11, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}
		break;
	case 0x83: //128K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
	case 0x85: //128K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	case 0x86: //258K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	case 0x90:
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	case 0x92: //128K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	default:
		return libusb_FALSE;
		break;
	}

	//220
	if (chipID == 0x20){
		FlashCodeVer[40] = '\0';
	}
	else{
		FlashCodeVer[41] = '\0';
	}

	if(bNormalExport){
		memcpy(FlashCodeVer + 5, CusVer + 2, 10);
		memcpy(FlashCodeVer + 15, Customer + 2, 10);
		memcpy(FlashCodeVer + 25, DayVer + 2, 10);
	}else{
		/* 第二种组合方式	*/
		libusb_BYTE cFLashCodeVer2 = FlashCodeVer[4];
		FlashCodeVer[4] = '-';
		int index = 0;
		libusb_BYTE *pFWVersion = FlashCodeVer;
		pFWVersion += 5;
		int i = 0;
		for (i = 0; i<10; i++)
		{
			if (CusVer[i + 2] != 0x2d)
			{
				*(pFWVersion++) = CusVer[i + 2];
			}
		}
		if ( 0 != memcmp(RomValue, "220R", 4))
		{
			*(pFWVersion++) = '-';
			*(pFWVersion++) = cFLashCodeVer2;
		}
		char cDayVer1[7] = {0};
		char cDayVer2[3] = {0};
		char cDayVer3[3] = {0};
		memcpy(cDayVer1, DayVer + 2, 6);
		memcpy(cDayVer2, DayVer + 8, 2);
		memcpy(cDayVer3, DayVer + 10, 2);

		*(pFWVersion++) = '-';
		*(pFWVersion++) = 'V';
		memcpy(pFWVersion, cDayVer1, 6);
		pFWVersion += 6;
		*(pFWVersion++) = '_';
		memcpy(pFWVersion, cDayVer2, 2);
		pFWVersion += 2;
		*(pFWVersion++) = '_';
		memcpy(pFWVersion, cDayVer3, 2);
		pFWVersion += 2;
		*(pFWVersion++) = '-';

		for (i = 0; i < 10; i++)
		{
			if (Customer[i + 2] != 0x2d)
			{
				*(pFWVersion++) = Customer[i + 2];
			}
		}
	}
	
	char Temp[56] = { 0 };
	memcpy(Temp, FlashCodeVer, 56);
	memcpy(pData, Temp, sizeof(Temp));
	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_GetFwVersionEx(libusb_device_handle *devh, libusb_DSP_ROM_TYPE romType, unsigned char pData[], long len, libusb_BOOL bNormalExport)
{
	libusb_BYTE RomValue[10] = { 0 };
	libusb_BOOL hr = libusb_LibUsb_GetAsicRomVersion(devh, RomValue);

	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE dspArchType;
	if (libusb_DRT_Unknow == libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType))
		return libusb_FALSE;

	libusb_BYTE FlashCodeVer[56] = { 0 };
	libusb_BYTE CusVer[31];
	libusb_BYTE DayVer[31];
	libusb_BYTE Customer[31];

	switch (chipID){
	case 0x15:
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x16:
		libusb_LibUsb_ReadFormSF(devh, 0x0FD0, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0148 + 11, FlashCodeVer, 5);
		break;
	case 0x20:
		libusb_LibUsb_ReadFormSF(devh, 0x5E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x0 + 11, FlashCodeVer, 4);
		break;
	case 0x25:
		libusb_LibUsb_ReadFormSF(devh, 0x5E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x30:
		libusb_LibUsb_ReadFormSF(devh, 0x1E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
	case 0x31:
		if (!hr){
			return libusb_FALSE;
		}
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x1E00, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x1E00 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		}
		else if (RomValue[5] == 2){
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x1E00, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x1E00 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x1E00 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x6000 + 0x01e8 + 11, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}

		break;
	case 0x32:
		if (!hr){
			return libusb_FALSE;
		}
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0148 + 11, FlashCodeVer, 5);
		}
		else if (RomValue[5] == 2){
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 18, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 28, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0FD0 + 10, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}
		break;
	case 0x36:
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x50:
		libusb_LibUsb_ReadFormSF(devh, 0x5E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x5E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x56:
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 10, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00 + 20, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x01e8 + 11, FlashCodeVer, 5);
		break;
	case 0x70:
		libusb_LibUsb_ReadFormSF(devh, 0x3E05, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E0F, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E19, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, FlashCodeVer, 5);
		break;
	case 0x71:
		libusb_LibUsb_ReadFormSF(devh, 0x3E05, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E0F, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E19, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x3E00, FlashCodeVer, 5);
		break;
	case 0x75:
		if (RomValue[5] == 1){
			
			if(romType == libusb_DRT_64K){
				libusb_LibUsb_ReadFormSF(devh, 0x4E00, Customer + 2, 10);
				libusb_LibUsb_ReadFormSF(devh, 0x4E12, CusVer + 2, 10);
				libusb_LibUsb_ReadFormSF(devh, 0x4E1C, DayVer + 2, 10);
				libusb_LibUsb_ReadFormSF(devh, 0x4E0A, FlashCodeVer, 5);
				printf("dsp rom type=%s\n", Customer);
			}
			else if(romType == libusb_DRT_128K){
				libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
				libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
				libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
				libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
			}
			else
			{
				return libusb_FALSE;
			}
		}
		else{
			return libusb_FALSE;
		}

		break;
	case 0x76: //128K
		if (RomValue[5] == 1){
			libusb_LibUsb_ReadFormSF(devh, 0x3FD0, Customer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x3FD0 + 10, CusVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x3FD0 + 20, DayVer + 2, 10);
			libusb_LibUsb_ReadFormSF(devh, 0x0148 + 11, FlashCodeVer, 5);
		}
		else{
			return libusb_FALSE;
		}
		break;
	case 0x83: //128K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
	case 0x85: //128K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	case 0x86: //258K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;		
	case 0x90:
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	case 0x92: //128K
		libusb_LibUsb_ReadFormSF(devh, 0x2000, Customer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x2012, CusVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x201C, DayVer + 2, 10);
		libusb_LibUsb_ReadFormSF(devh, 0x200A, FlashCodeVer, 5);
		break;
	default:
		return libusb_FALSE;
		break;
	}

	//220
	if (chipID == 0x20){
		FlashCodeVer[40] = '\0';
	}
	else{
		FlashCodeVer[41] = '\0';
	}


	if(bNormalExport){
		memcpy(FlashCodeVer + 5, CusVer + 2, 10);
		memcpy(FlashCodeVer + 15, Customer + 2, 10);
		memcpy(FlashCodeVer + 25, DayVer + 2, 10);
	}else{
		/* 第二种组合方式	*/
		libusb_BYTE cFLashCodeVer2 = FlashCodeVer[4];
		FlashCodeVer[4] = '-';
		int index = 0;
		libusb_BYTE *pFWVersion = FlashCodeVer;
		pFWVersion += 5;
		int i = 0;
		for (i = 0; i<10; i++)
		{
			if (CusVer[i + 2] != 0x2d)
			{
				*(pFWVersion++) = CusVer[i + 2];
			}
		}
		if ( 0 != memcmp(RomValue, "220R", 4))
		{
			*(pFWVersion++) = '-';
			*(pFWVersion++) = cFLashCodeVer2;
		}
		char cDayVer1[7] = {0};
		char cDayVer2[3] = {0};
		char cDayVer3[3] = {0};
		memcpy(cDayVer1, DayVer + 2, 6);
		memcpy(cDayVer2, DayVer + 8, 2);
		memcpy(cDayVer3, DayVer + 10, 2);

		*(pFWVersion++) = '-';
		*(pFWVersion++) = 'V';
		memcpy(pFWVersion, cDayVer1, 6);
		pFWVersion += 6;
		*(pFWVersion++) = '_';
		memcpy(pFWVersion, cDayVer2, 2);
		pFWVersion += 2;
		*(pFWVersion++) = '_';
		memcpy(pFWVersion, cDayVer3, 2);
		pFWVersion += 2;
		*(pFWVersion++) = '-';

		for (i = 0; i < 10; i++)
		{
			if (Customer[i + 2] != 0x2d)
			{
				*(pFWVersion++) = Customer[i + 2];
			}
		}
	}

	char Temp[56] = { 0 };
	memcpy(Temp, FlashCodeVer, 56);
	memcpy(pData, Temp, sizeof(Temp));
	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_GetFwVersionFromFile(libusb_device_handle *devh, unsigned char pFwFile[], unsigned char pData[], long len, libusb_sonixbool bNormalExport)
{
	libusb_BYTE RomValue[10] = { 0 };
	libusb_BOOL hr = libusb_LibUsb_GetAsicRomVersion(devh, RomValue);

	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE dspArchType;
	if (libusb_DRT_Unknow == libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType))
		return libusb_FALSE;

	libusb_BYTE FlashCodeVer[56] = { 0 };
	libusb_BYTE CusVer[31];
	libusb_BYTE DayVer[31];
	libusb_BYTE Customer[31];

	switch (chipID){
	case 0x15:
		memcpy(Customer + 2, pFwFile + 0x3E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x3E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x3E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
		break;
	case 0x16:
		memcpy(Customer + 2, pFwFile + 0x0FD0, 10);
		memcpy(CusVer + 2, pFwFile + 0x0FD0 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x0FD0 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x0148 + 11, 5);
		break;
	case 0x20:
		memcpy(Customer + 2, pFwFile + 0x5E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x5E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x5E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x0 + 11, 4);
		break;
	case 0x25:
		memcpy(Customer + 2, pFwFile + 0x5E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x5E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x5E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
		break;
	case 0x30:
		memcpy(Customer + 2, pFwFile + 0x1E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x1E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x1E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
	case 0x31:
		if (!hr){
			return libusb_false;
		}
		if (RomValue[5] == 1){
			memcpy(Customer + 2, pFwFile + 0x1E00, 10);
			memcpy(CusVer + 2, pFwFile + 0x1E00 + 10, 10);
			memcpy(DayVer + 2, pFwFile + 0x1E00 + 20, 10);
			memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
		}
		else if (RomValue[5] == 2){
			memcpy(Customer + 2, pFwFile + 0x6000 + 0x1E00, 10);
			memcpy(CusVer + 2, pFwFile + 0x6000 + 0x1E00 + 10, 10);
			memcpy(DayVer + 2, pFwFile + +0x1E00 + 0x1E00 + 20, 10);
			memcpy(FlashCodeVer, pFwFile + 0x6000 + 0x01e8 + 11, 5);
		}
		else{
			return libusb_false;
		}

		break;
	case 0x32:
		if (!hr){
			return libusb_false;
		}
		if (RomValue[5] == 1){
			memcpy(Customer + 2, pFwFile + 0x0FD0, 10);
			memcpy(CusVer + 2, pFwFile + 0x0FD0 + 10, 10);
			memcpy(DayVer + 2, pFwFile + 0x0FD0 + 20, 10);
			memcpy(FlashCodeVer, pFwFile + 0x0148 + 11, 5);
		}
		else if (RomValue[5] == 2){
			memcpy(Customer + 2, pFwFile + 0x0FD0, 10);
			memcpy(CusVer + 2, pFwFile + 0x0FD0 + 18, 10);
			memcpy(DayVer + 2, pFwFile + 0x0FD0 + 28, 10);
			memcpy(FlashCodeVer, pFwFile + 0x0FD0 + 10, 5);
		}
		else{
			return libusb_false;
		}
		break;
	case 0x36:
		memcpy(Customer + 2, pFwFile + 0x3E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x3E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x3E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
		break;
	case 0x50:
		memcpy(Customer + 2, pFwFile + 0x5E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x5E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x5E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
		break;
	case 0x56:
		memcpy(Customer + 2, pFwFile + 0x3E00, 10);
		memcpy(CusVer + 2, pFwFile + 0x3E00 + 10, 10);
		memcpy(DayVer + 2, pFwFile + 0x3E00 + 20, 10);
		memcpy(FlashCodeVer, pFwFile + 0x01e8 + 11, 5);
		break;
	case 0x70:
		memcpy(Customer + 2, pFwFile + 0x3E05, 10);
		memcpy(CusVer + 2, pFwFile + 0x3E0F, 10);
		memcpy(DayVer + 2, pFwFile + 0x3E19, 10);
		memcpy(FlashCodeVer, pFwFile + 0x3E00, 5);
		break;
	case 0x71:
		memcpy(Customer + 2, pFwFile + 0x3E05, 10);
		memcpy(CusVer + 2, pFwFile + 0x3E0F, 10);
		memcpy(DayVer + 2, pFwFile + 0x3E19, 10);
		memcpy(FlashCodeVer, pFwFile + 0x3E00, 5);
		break;
	case 0x75:
		if (RomValue[5] == 1){
			memcpy(Customer + 2, pFwFile + 0x2000, 10);
			memcpy(CusVer + 2, pFwFile + 0x2012, 10);
			memcpy(DayVer + 2, pFwFile + 0x201C, 10);
			memcpy(FlashCodeVer, pFwFile + 0x200A, 5);
		}
		else{
			return libusb_false;
		}

		break;
	case 0x76: //128K
		if (RomValue[5] == 1){
			memcpy(Customer + 2, pFwFile + 0x3FD0, 10);
			memcpy(CusVer + 2, pFwFile + 0x3FD0 + 10, 10);
			memcpy(DayVer + 2, pFwFile + 0x3FD0 + 20, 10);
			memcpy(FlashCodeVer, pFwFile + 0x0148 + 11, 5);
		}
		else{
			return libusb_false;
		}
		break;
	case 0x83: //128K
		memcpy(Customer + 2, pFwFile + 0x2000, 10);
		memcpy(CusVer + 2, pFwFile + 0x2012, 10);
		memcpy(DayVer + 2, pFwFile + 0x201C, 10);
		memcpy(FlashCodeVer, pFwFile + 0x200A, 5);
		break;
	case 0x85: //128K
		memcpy(Customer + 2, pFwFile + 0x2000, 10);
		memcpy(CusVer + 2, pFwFile + 0x2012, 10);
		memcpy(DayVer + 2, pFwFile + 0x201C, 10);
		memcpy(FlashCodeVer, pFwFile + 0x200A, 5);
		break;
	case 0x86: //128K
		memcpy(Customer + 2, pFwFile + 0x2000, 10);
		memcpy(CusVer + 2, pFwFile + 0x2012, 10);
		memcpy(DayVer + 2, pFwFile + 0x201C, 10);
		memcpy(FlashCodeVer, pFwFile + 0x200A, 5);
		break;
	case 0x90:
		memcpy(Customer + 2, pFwFile + 0x2000, 10);
		memcpy(CusVer + 2, pFwFile + 0x2012, 10);
		memcpy(DayVer + 2, pFwFile + 0x201C, 10);
		memcpy(FlashCodeVer, pFwFile + 0x200A, 5);
		break;
	case 0x92: //128K
		memcpy(Customer + 2, pFwFile + 0x2000, 10);
		memcpy(CusVer + 2, pFwFile + 0x2012, 10);
		memcpy(DayVer + 2, pFwFile + 0x201C, 10);
		memcpy(FlashCodeVer, pFwFile + 0x200A, 5);
		break;
	default:
		return libusb_false;
		break;
	}

	//220
	if (chipID == 0x20){
		FlashCodeVer[40] = '\0';
	}
	else{
		FlashCodeVer[41] = '\0';
	}

	if(bNormalExport){
		memcpy(FlashCodeVer + 5, CusVer + 2, 10);
		memcpy(FlashCodeVer + 15, Customer + 2, 10);
		memcpy(FlashCodeVer + 25, DayVer + 2, 10);
	}else{
		/* 第二种组合方式	*/
		libusb_BYTE cFLashCodeVer2 = FlashCodeVer[4];
		FlashCodeVer[4] = '-';
		int index = 0;
		libusb_BYTE *pFWVersion = FlashCodeVer;
		pFWVersion += 5;
		int i = 0;
		for (i = 0; i<10; i++)
		{
			if (CusVer[i + 2] != 0x2d)
			{
				*(pFWVersion++) = CusVer[i + 2];
			}
		}
		if ( 0 != memcmp(RomValue, "220R", 4))
		{
			*(pFWVersion++) = '-';
			*(pFWVersion++) = cFLashCodeVer2;
		}
		char cDayVer1[7] = {0};
		char cDayVer2[3] = {0};
		char cDayVer3[3] = {0};
		memcpy(cDayVer1, DayVer + 2, 6);
		memcpy(cDayVer2, DayVer + 8, 2);
		memcpy(cDayVer3, DayVer + 10, 2);

		*(pFWVersion++) = '-';
		*(pFWVersion++) = 'V';
		memcpy(pFWVersion, cDayVer1, 6);
		pFWVersion += 6;
		*(pFWVersion++) = '_';
		memcpy(pFWVersion, cDayVer2, 2);
		pFWVersion += 2;
		*(pFWVersion++) = '_';
		memcpy(pFWVersion, cDayVer3, 2);
		pFWVersion += 2;
		*(pFWVersion++) = '-';

		for (i = 0; i < 10; i++)
		{
			if (Customer[i + 2] != 0x2d)
			{
				*(pFWVersion++) = Customer[i + 2];
			}
		}
	}
	
	char Temp[56] = { 0 };
	memcpy(Temp, FlashCodeVer, 56);
	memcpy(pData, Temp, sizeof(Temp));
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_GetSerialNumber(libusb_device_handle *devh, unsigned char pData[], long len)
{
	return libusb_LibUsb_GetStringSettingFormSF(devh, pData, len, 0xC0, libusb_TRUE);
}

libusb_sonixbool  libusb_SonixCam_GetManufacturer(libusb_device_handle *devh, unsigned char pData[], long len)
{
	return libusb_LibUsb_GetStringSettingFormSF(devh, pData, len, 0x80, libusb_TRUE);
}

libusb_sonixbool  libusb_SonixCam_GetProduct(libusb_device_handle *devh, unsigned char pData[], long len)
{
	return libusb_LibUsb_GetStringSettingFormSF(devh, pData, len, 0x40, libusb_TRUE);
}

libusb_sonixbool  libusb_SonixCam_GetVidPid(libusb_device_handle *devh, unsigned char pData[], long len)
{
	libusb_DWORD dwStringAddr = 0;
	libusb_ULONG dwParaTableStartAddr = 0;
	libusb_ULONG dwParaTableEndAddr = 0;
	libusb_ULONG dwCRCStartAddr = 0;
	if (!libusb_LibUsb_GetParaTableAndCRCAddrFormSF(devh, &dwParaTableStartAddr, &dwParaTableEndAddr, &dwCRCStartAddr))
		return libusb_FALSE;

	dwStringAddr = dwParaTableStartAddr + 0x06;
	libusb_BYTE pbyStringBuf[4] = { 0 };
	if (!libusb_LibUsb_ReadFormSF(devh, dwStringAddr, pbyStringBuf, sizeof(pbyStringBuf)))
		return libusb_FALSE;

	memcpy(pData, pbyStringBuf, 4);
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_GetString3(libusb_device_handle *devh, unsigned char pData[], long len)
{
	return libusb_LibUsb_GetStringSettingFormSF(devh, pData, len, 0x100, libusb_TRUE);
}

libusb_sonixbool libusb_SonixCam_GetInterface(libusb_device_handle *devh, unsigned char pData[], long len)
{
	return libusb_LibUsb_GetStringSettingFormSF(devh, pData, len, 0x140, libusb_TRUE);
}

libusb_sonixbool libusb_SonixCam_XuRead(libusb_device_handle *devh, unsigned char pData[], unsigned int length, unsigned char unitID, unsigned char cs)
{
	if(!libusb_LibUsb_Read(devh, pData, length, unitID, cs))
		return libusb_FALSE;
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_XuWrite(libusb_device_handle *devh, unsigned char pData[], unsigned int length, unsigned char unitID, unsigned char cs)
{
	if(!libusb_LibUsb_Write(devh, pData, length, unitID, cs))
		return libusb_FALSE;
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_DisableSerialFlashWriteProtect(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft)
{
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_EraseBlockFlash(libusb_device_handle *devh, long addr, libusb_SERIAL_FLASH_TYPE sft)
{
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		return libusb_FALSE;
	}

	if (!libusb_LibUsb_EraseBlockForSerialFlash(devh, addr, sft))
	{
		gEC = libusb_EC_EraseFlashFail;
		return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_EraseSectorFlash(libusb_device_handle *devh, long addr, libusb_SERIAL_FLASH_TYPE sft)
{
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		return libusb_FALSE;
	}

	if (!libusb_LibUsb_EraseSectorForSerialFlash(devh, addr, sft))
	{
		gEC = libusb_EC_EraseFlashFail;
		return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_EraseSerialFlash(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft)
{
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		return libusb_FALSE;
	}

	if (!libusb_LibUsb_SerialFlashErase(devh, sft))
	{
		gEC = libusb_EC_EraseFlashFail;
		return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_SerialFlashCustomRead(libusb_device_handle *devh, long addr, unsigned char pData[], long len)
{
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfModeAddr, 0);//series flash mode
	libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);//CS -> 0

	libusb_BYTE data = 3;
	libusb_LibUsb_WriteToASIC(devh, 0x1088, data);//read command 0x1088 = 0x03
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);

	libusb_LONG startAddr = addr;
	data = startAddr >> 16;
	libusb_LibUsb_WriteToASIC(devh, 0x1089, data);
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//addr0
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
	libusb_LibUsb_SFWaitReady(devh);

	data = startAddr >> 8;
	libusb_LibUsb_WriteToASIC(devh, 0x108a, data);
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//addr1
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
	libusb_LibUsb_SFWaitReady(devh);

	data = (libusb_BYTE)startAddr;
	libusb_LibUsb_WriteToASIC(devh, 0x108b, data);
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//addr2
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
	libusb_LibUsb_SFWaitReady(devh);

	libusb_LONG i = 0;
	for (i = 0; i < len; i++)
	{
		data = 0;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadDataAddr, data);//ready for read
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 1);	//read TRG
		libusb_LibUsb_SFWaitReady(devh);//read 1084 bit0 when bit0 is 1 means ISP controler is ready
		//500us timeout
		libusb_LibUsb_ReadFromASIC(devh, libusb_sfReadDataAddr, &pData[i]);//read data
	}
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);//CS -> 1
	libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfModeAddr, 0);//series flash mode disable
	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_SerialFlashSectorCustomWrite(libusb_device_handle *devh, long addr, unsigned char pData[], long len, libusb_SERIAL_FLASH_TYPE sft)
{
	// 0x1080 [1 : Serial Flash mode]
	// 0x1081 [1:SF_WRITE_TRG Trigger  2:SF_READ_TRG] 
	// 0x1082 [SF_WRITE_DATA[7:0]
	// 0x1083 [SF_READ_DATA[7:0]
	// 0x1091 [0: SF chip select] 

	//disable serial flash wirte protect
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
		return libusb_FALSE;

	//erase serial flash sector 
	if (!libusb_LibUsb_EraseSectorForSerialFlash(devh, addr, sft))
		return libusb_FALSE;
	sleep(1);
	libusb_LibUsb_SFWaitReady(devh);
	
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfModeAddr, 0);			// Flash Mode:En
	//WREN cycle
	libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:0
	libusb_BYTE data = 6;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);					//WREN
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
	libusb_LibUsb_SFWaitReady(devh);
	libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:1

	libusb_LONG startAddr = addr;
	if (sft == libusb_SFT_SST)
	{
		libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);
		data = 0xaf;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);

		data = startAddr >> 16;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		data = startAddr >> 8;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);				//addr2
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		data = (libusb_BYTE)startAddr;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);				//addr3
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LONG i = 0;
		for (i = 0; i < len; i++)
		{
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, pData[i]);		//Data
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);				// CS:1
			if (i == len - 1)
				break;
			libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);				// CS:0
			data = 0xaf;
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);				//PP  [0xaf:SST 0x2:other]
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
		}
		//WRDI
		libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:0
		data = 4;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:1
		usleep(100000);
		libusb_LibUsb_SFWaitReady(devh);
	}
	else if (sft == libusb_SFT_MXIC || sft == libusb_SFT_GIGA)
	{
		libusb_LONG j = 0;
		do{
			//WREN cycle
			libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:0
			libusb_BYTE data = 6;
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);					//WREN
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:1

			libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);			// CS:0
			data = 2;									
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);								//addr1
			data = startAddr >> 16;
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
			data = startAddr >> 8;
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);				//addr2
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
			data = (libusb_BYTE)startAddr;
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);				//addr3
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
			for (; j < len;)
			{
				libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, pData[j]);		//Data
				libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
				libusb_LibUsb_SFWaitReady(devh);
				startAddr++;
				j++;
				if (0 == startAddr % 256)
				{
					libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);	// CS:1
					break;
				}
			}
			if (j == len)
			{
				libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);	// CS:1
				break;
			}
		} while (1);
	}
	else
	{
		libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfCSAddr, 0);				// CS:0
		data = 2;									//PP  modify from ldata = 2;  // 0x2:other   0xaf:SST
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		//ldata = 0;									//addr1
		data = startAddr >> 16;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		data = startAddr >> 8;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);		//addr2
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		data = (libusb_BYTE)startAddr;
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);		//addr3
		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LONG i = 0;
		for (i = 0; i < len; i++)
		{
			libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, pData[i]);  //Data
			libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfReadWriteTriggerAddr, 0);
			libusb_LibUsb_SFWaitReady(devh);
		}

		libusb_LibUsb_EnableAsicRegisterBit(devh, libusb_sfCSAddr, 0);				// CS:1
	}
	libusb_LibUsb_DisableAsicRegisterBit(devh, libusb_sfModeAddr, 0);				// Flash Mode:Dis
	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_BurnerFW(libusb_device_handle *devh, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_SERIAL_FLASH_TYPE sft, libusb_BOOL bFullCheckFW)
{
	if (sft == libusb_SFT_UNKNOW)
	{	
		gEC = libusb_EC_UnKnowSerialFlashType;
		return libusb_FALSE;
	}
	
	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE asicArchType;
	libusb_DSP_ROM_TYPE romType = libusb_LibUsb_GetChipRomType(devh, &chipID, &asicArchType);
	if (romType == libusb_DRT_Unknow)
		return libusb_FALSE;
	switch (chipID)
	{
	case 0x85:
		libusb_LibUsb_WriteToASIC(devh, 0x5FF, 0x5A);
		libusb_LibUsb_WriteToASIC(devh, 0xA00, 0x1); // first frame for tw
		libusb_LibUsb_WriteToASIC(devh, 0xA0A, 0x1); // first frame for sz
		break;
	case 0x86:
		libusb_LibUsb_WriteToASIC(devh, 0xA00, 0x1); // first frame for tw
		libusb_LibUsb_WriteToASIC(devh, 0xA0A, 0x1); // first frame for sz
		break;
	default:
		break;
	}
	if (libusb_TRUE != libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		return libusb_FALSE;
	}
	if (libusb_TRUE != libusb_LibUsb_SerialFlashErase(devh, sft))
	{
		gEC = libusb_EC_EraseFlashFail;
		return libusb_FALSE;
	}
	sleep(1);

	//erase check
	libusb_LONG i;
	libusb_LONG fwLen = lFwLength;
	libusb_BYTE data[8];
	libusb_BYTE temp[8];
	memset(temp, 0xFF, sizeof(temp));
	for (i = 0; i < fwLen - 1024; i += 1024){
		memset(&data, 0xff, 8);
		if (!libusb_LibUsb_ReadDataFormFlash(devh, i, data, 8))
			return libusb_FALSE;
		if (0 != memcmp(data, temp, 8))
		{
			gEC = libusb_EC_EraseFlashFail;
			return libusb_FALSE;
		}
	}

	/*********************************************************************************/
	/*********************************************************************************/
	/* 将0x160位置的四个字节设置为0xFF,在烧录固件过程中拔掉设备后，在插上设备
	dsp首先检查0x160是否是有效数据，如果是0xFF则固件无效，使用dsp rom内的固
	件启动设备，否则加载flash里面的固件启动设备。*/
	libusb_BYTE *pCopyFW = (libusb_BYTE*)malloc(lFwLength);
	if (!pCopyFW)
	{
		gEC = libusb_EC_MallocMemoryFail;
		return libusb_FALSE;
	}
	memcpy(pCopyFW, pFwBuffer, lFwLength);
	libusb_BYTE intBuffer[8] = { 0 };
	memcpy(intBuffer, pCopyFW + 0x160, 8);
	memset(pCopyFW + 0x160, 0xFF, 4);

	//259断电保护
	libusb_BYTE intBuffer_259_P1[2] = { 0 };
	libusb_BYTE intBuffer_259_P2[2] = { 0 };
	libusb_BYTE intBuffer_259_P3[21] = { 0 };
	if (chipID == 0x16)
	{
		memcpy(intBuffer_259_P1, pCopyFW, 2);
		memcpy(intBuffer_259_P2, pCopyFW + 0x6700, 2);
		memcpy(intBuffer_259_P3, pCopyFW + 0x6702, 0x15);
		memset(pCopyFW, 0xFF, 2);
		memset(pCopyFW + 0x6700, 0xFF, 0x17);
	}
	/*********************************************************************************/
	/*********************************************************************************/


	float gProgress = 0;
	for (i = 0; i < fwLen; i += 8){
		if (setProgress && ((i % 0x200) == 0))
		{
			gProgress = (float)i / (float)fwLen;
			if (bFullCheckFW)
				gProgress *= 0.5f;
			setProgress(ptrClass, gProgress);
		}
		memset(data, 0xff, 8);
		memcpy(data, pCopyFW + i, 8);
		if (!libusb_LibUsb_WriteDataToFlash(devh, i, data, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

	}

	/*********************************************************************************/
	/*********************************************************************************/
	/*烧录完成，恢复0x160地址数据*/
	if (!libusb_LibUsb_WriteDataToFlash(devh, 0x160, intBuffer, 8)){
		libusb_SAFE_DELETE_ARRAY(pCopyFW);
		return libusb_FALSE;
	}
	memcpy(pCopyFW + 0x160, intBuffer, 8);

	//259断电保护
	if (chipID == 0x16)
	{
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702, intBuffer_259_P3, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702 + 8, intBuffer_259_P3 + 8, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702 + 16, intBuffer_259_P3 + 16, 5)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}


		if (!libusb_LibUsb_WriteDataToFlash(devh, 0, intBuffer_259_P1, 2)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6700, intBuffer_259_P2, 2)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		memcpy(pCopyFW, intBuffer_259_P1, 2);
		memcpy(pCopyFW + 0x6700, intBuffer_259_P2, 2);
		memcpy(pCopyFW + 0x6702, intBuffer_259_P3, 0x15);
	}
	/*********************************************************************************/
	/*********************************************************************************/


	if (bFullCheckFW)
	{
		if (setProgress)
			setProgress(ptrClass, 0.5f);
	}
	else
	{
		if(setProgress)
			setProgress(ptrClass, 1.0f);
	}

	libusb_LONG step = 1024;
	if (bFullCheckFW)
		step = 8;
	for (i = 0; i < fwLen; i += step){
		memset(&data, 0xff, 8);
		if (!libusb_LibUsb_ReadDataFormFlash(devh, i, data, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (0 != memcmp(data, pCopyFW + i, 8))
		{
			gEC = libusb_EC_BurnerCheckFail;
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (bFullCheckFW && setProgress && ((i % 0x200) == 0))
		{
			gProgress = ((float)i / (float)fwLen) * 0.5;
			gProgress += 0.5f;
			setProgress(ptrClass, gProgress);
		}
	}
	if (bFullCheckFW)
	{
		if (setProgress)
			setProgress(ptrClass, 1.0f);
	}
	return libusb_TRUE;
}

libusb_sonixbool  libusb_SonixCam_WriteFwToFlash(libusb_device_handle *devh, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_BOOL bFullCheckFW)
{
	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE asicArchType;
	libusb_DSP_ROM_TYPE romType = libusb_LibUsb_GetChipRomType(devh, &chipID, &asicArchType);
	if (romType == libusb_DRT_Unknow)
		return libusb_FALSE;
	switch (chipID)
	{
	case 0x85:
		libusb_LibUsb_WriteToASIC(devh, 0x5FF, 0x5A);
		libusb_LibUsb_WriteToASIC(devh, 0xA00, 0x1); // first frame for tw
		libusb_LibUsb_WriteToASIC(devh, 0xA0A, 0x1); // first frame for sz
		break;
	case 0x86:
		libusb_LibUsb_WriteToASIC(devh, 0xA00, 0x1); // first frame for tw
		libusb_LibUsb_WriteToASIC(devh, 0xA0A, 0x1); // first frame for sz
		break;
	default:
		break;
	}

	/*********************************************************************************/
	/*********************************************************************************/
	/* 将0x160位置的四个字节设置为0xFF,在烧录固件过程中拔掉设备后，在插上设备
	dsp首先检查0x160是否是有效数据，如果是0xFF则固件无效，使用dsp rom内的固
	件启动设备，否则加载flash里面的固件启动设备。*/
	libusb_BYTE *pCopyFW = (libusb_BYTE*)malloc(lFwLength);
	libusb_LONG fwLen = lFwLength;
	if (!pCopyFW)
	{
		gEC = libusb_EC_MallocMemoryFail;
		return libusb_FALSE;
	}
	memcpy(pCopyFW, pFwBuffer, lFwLength);
	libusb_BYTE intBuffer[8] = { 0 };
	memcpy(intBuffer, pCopyFW + 0x160, 8);
	memset(pCopyFW + 0x160, 0xFF, 4);

	//259断电保护
	libusb_BYTE intBuffer_259_P1[2] = { 0 };
	libusb_BYTE intBuffer_259_P2[2] = { 0 };
	libusb_BYTE intBuffer_259_P3[21] = { 0 };
	if (chipID == 0x16)
	{
		memcpy(intBuffer_259_P1, pCopyFW, 2);
		memcpy(intBuffer_259_P2, pCopyFW + 0x6700, 2);
		memcpy(intBuffer_259_P3, pCopyFW + 0x6702, 0x15);
		memset(pCopyFW, 0xFF, 2);
		memset(pCopyFW + 0x6700, 0xFF, 0x17);
	}
	/*********************************************************************************/
	/*********************************************************************************/

	float gProgress = 0;
	int i = 0;
	libusb_BYTE data[8];
	for (i = 0; i < fwLen; i += 8){
		if (setProgress && ((i % 0x200) == 0))
		{
			gProgress = (float)i / (float)fwLen;
			if (bFullCheckFW)
				gProgress *= 0.5f;
			setProgress(ptrClass, gProgress);
		}
		memset(data, 0xff, 8);
		memcpy(data, pCopyFW + i, 8);
		if (!libusb_LibUsb_WriteDataToFlash(devh, i, data, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

	}

	/*********************************************************************************/
	/*********************************************************************************/
	/*烧录完成，恢复0x160地址数据*/
	if (!libusb_LibUsb_WriteDataToFlash(devh, 0x160, intBuffer, 8)){
		libusb_SAFE_DELETE_ARRAY(pCopyFW);
		return libusb_FALSE;
	}
	memcpy(pCopyFW + 0x160, intBuffer, 8);

	//259断电保护
	if (chipID == 0x16)
	{
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702, intBuffer_259_P3, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702 + 8, intBuffer_259_P3 + 8, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702 + 16, intBuffer_259_P3 + 16, 5)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}


		if (!libusb_LibUsb_WriteDataToFlash(devh, 0, intBuffer_259_P1, 2)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6700, intBuffer_259_P2, 2)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		memcpy(pCopyFW, intBuffer_259_P1, 2);
		memcpy(pCopyFW + 0x6700, intBuffer_259_P2, 2);
		memcpy(pCopyFW + 0x6702, intBuffer_259_P3, 0x15);
	}
	/*********************************************************************************/
	/*********************************************************************************/

	if (bFullCheckFW)
	{
		if (setProgress)
			setProgress(ptrClass, 0.5f);
	}
	else
	{
		if(setProgress)
			setProgress(ptrClass, 1.0f);
	}

	libusb_LONG step = 1024;
	if (bFullCheckFW)
		step = 8;
	for (i = 0; i < fwLen; i += step){
		memset(&data, 0xff, 8);
		if (!libusb_LibUsb_ReadDataFormFlash(devh, i, data, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (0 != memcmp(data, pCopyFW + i, 8))
		{
			gEC = libusb_EC_BurnerCheckFail;
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (bFullCheckFW && setProgress && ((i % 0x200) == 0))
		{
			gProgress = ((float)i / (float)fwLen) * 0.5;
			gProgress += 0.5f;
			setProgress(ptrClass, gProgress);
		}
	}
	if (bFullCheckFW)
	{
		if (setProgress)
			setProgress(ptrClass, 1.0f);
	}
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_ExportFW(libusb_device_handle *devh, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass)
{
	libusb_BYTE tempData[8];
	libusb_BYTE* pFw = pFwBuffer;
	libusb_LONG fwLen = lFwLength;
	libusb_BOOL sf_hight_addr = libusb_FALSE;
	libusb_BYTE addrLow, addrHigh;
	float gProgress = 0.0;  //(0.0 - 1.0)
	libusb_LONG i;
	for ( i= 0; i < fwLen; i += 8){
		if (setProgress)
		{
			gProgress = (float)i / (float)fwLen;
			//setProgress(ptrClass, gProgress);
		}
		memset(&tempData, 0xff, 8);
		if (libusb_TRUE != libusb_LibUsb_ReadDataFormFlash(devh, i, tempData, 8))
			return libusb_FALSE;

		*(pFw + i) = tempData[0];
		*(pFw + i + 1) = tempData[1];
		*(pFw + i + 2) = tempData[2];
		*(pFw + i + 3) = tempData[3];
		*(pFw + i + 4) = tempData[4];
		*(pFw + i + 5) = tempData[5];
		*(pFw + i + 6) = tempData[6];
		*(pFw + i + 7) = tempData[7];
	}
	sf_hight_addr = libusb_FALSE;
	return libusb_TRUE;
}

libusb_BOOL libusb_SetParamToParamBuffer(libusb_BYTE paramBuffer[], libusb_LONG paramAddr, libusb_BYTE param[], libusb_LONG length)
{
	libusb_BYTE *pParamTable = paramBuffer + paramAddr;
	memset(pParamTable, 0xFF, 64);
	pParamTable[0] = length * 2 + 2;
	pParamTable[1] = 0x03;
	libusb_LONG i = 0;
	for (i = 0; i < length; i++)
	{
		*(pParamTable + 2 + 2 * i) = param[i];
		*(pParamTable + 2 + 2 * i + 1) = 0x0;
	}
	return libusb_TRUE;
}

libusb_BOOL libusb_CheckCRC(libusb_BYTE *pFW, libusb_LONG paraTableStartAddr, libusb_LONG paraTableLength, libusb_LONG crcStartAddr)
{
	libusb_USHORT crc16 = 0xFFFF;
	libusb_BYTE temp;
	libusb_LONG i, j;
	libusb_BYTE *pParaBuffer = pFW + paraTableStartAddr;
	for (i = 0; i < paraTableLength; i++)
	{
		temp = pParaBuffer[i];
		crc16 ^= temp;
		for (j = 0; j < 8; j++)
		{
			if (crc16 & 0x01)
			{
				crc16 >>= 1;
				crc16 ^= 0xA001;
			}
			else
				crc16 >>= 1;
		}
	}
	*(pFW + crcStartAddr + 20) = crc16 >> 8;
	*(pFW + crcStartAddr + 21) = crc16;
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_CustomBurnerFW(libusb_device_handle *devh, const libusb_ChangeParamInfo paramInfo, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_SERIAL_FLASH_TYPE sft, libusb_BOOL bFullCheckFW)
{
	if (sft == libusb_SFT_UNKNOW)
	{
		gEC = libusb_EC_UnKnowSerialFlashType;
		return libusb_FALSE;
	}

	libusb_DWORD dwStringAddr = 0;
	libusb_ULONG dwParaTableStartAddr = 0;
	libusb_ULONG dwParaTableEndAddr = 0;
	libusb_ULONG dwCRCStartAddr = 0;

	if (!libusb_LibUsb_GetParaTableAndCRCAddrFormFW(devh, pFwBuffer, &dwParaTableStartAddr, &dwParaTableEndAddr, &dwCRCStartAddr))
		return libusb_FALSE;

	libusb_LONG fwLen = lFwLength;
	libusb_BYTE *pCopyFW = (libusb_BYTE*)malloc(lFwLength);
	fwLen = lFwLength;
	if (!pCopyFW)
	{
		gEC = libusb_EC_MallocMemoryFail;
		return libusb_FALSE;
	}
	memcpy(pCopyFW, pFwBuffer, lFwLength);

	libusb_BYTE data[8];
	libusb_BYTE temp[8];
	libusb_LONG addIndex = 0;
	float gProgress = 0.0;  //(0.0 - 1.0)

	if (paramInfo.libusb_pVidPid)
	{
		memcpy(pCopyFW + (dwParaTableStartAddr + 0x06), paramInfo.libusb_pVidPid, 4);
	}
	if (paramInfo.libusb_pProduct)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x40), (libusb_BYTE*)paramInfo.libusb_pProduct, paramInfo.libusb_ProductLength);
	}
	if (paramInfo.libusb_pManufacture)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x80), (libusb_BYTE*)paramInfo.libusb_pManufacture, paramInfo.libusb_ManufactureLength);
	}
	if (paramInfo.libusb_pSerialNumber)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0xC0), (libusb_BYTE*)paramInfo.libusb_pSerialNumber, paramInfo.libusb_SerialNumberLength);
	}
	if (paramInfo.libusb_pString3)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x100), (libusb_BYTE*)paramInfo.libusb_pString3, paramInfo.libusb_String3Length);
	}
	if (paramInfo.libusb_pInterface)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x140), (libusb_BYTE*)paramInfo.libusb_pInterface, paramInfo.libusb_InterfaceLength);
	}

	//CRC Check
	libusb_CheckCRC(pCopyFW, dwParaTableStartAddr, dwParaTableEndAddr - dwParaTableStartAddr, dwCRCStartAddr);


	//在285DSP的一些固件中，由于有上电直接开启图像，而开启图形无法烧录，所有要先
	//关闭图像，然后在烧录。
	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE asicArchType;
	libusb_DSP_ROM_TYPE romType = libusb_LibUsb_GetChipRomType(devh, &chipID, &asicArchType);
	if (romType == libusb_DRT_Unknow){
		libusb_SAFE_DELETE_ARRAY(pCopyFW);
		return libusb_FALSE;
	}
	switch (chipID)
	{
	case 0x85:
		libusb_LibUsb_WriteToASIC(devh, 0x5FF, 0x5A);
		libusb_LibUsb_WriteToASIC(devh, 0xA00, 0x1); // first frame for tw
		libusb_LibUsb_WriteToASIC(devh, 0xA0A, 0x1); // first frame for sz
		break;
	case 0x86:
		libusb_LibUsb_WriteToASIC(devh, 0xA00, 0x1); // first frame for tw
		libusb_LibUsb_WriteToASIC(devh, 0xA0A, 0x1); // first frame for sz
		break;
	default:
		break;
	}

	//Diable flash wirte protect
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		return libusb_FALSE;
	}

	//erase flash
	if (!libusb_LibUsb_SerialFlashErase(devh, sft))
	{
		gEC = libusb_EC_EraseFlashFail;
		return libusb_FALSE;
	}
	sleep(1);

	libusb_LONG i = 0;
	//erase check
	memset(temp, 0xFF, sizeof(temp));
	for (i = 0; i < fwLen - 1024; i += 1024){
		memset(&data, 0xff, 8);
		if (!libusb_LibUsb_ReadDataFormFlash(devh, i, data, 8))
			return libusb_FALSE;
		if (0 != memcmp(data, temp, 8))
		{
			gEC = libusb_EC_EraseFlashFail;
			return libusb_FALSE;
		}
	}

	/*********************************************************************************/
	/*********************************************************************************/
	/* 将0x160位置的四个字节设置为0xFF,在烧录固件过程中拔掉设备后，在插上设备
	dsp首先检查0x160是否是有效数据，如果是0xFF则固件无效，使用dsp rom内的固
	件启动设备，否则加载flash里面的固件启动设备。*/
	libusb_BYTE intBuffer[8] = { 0 };
	memcpy(intBuffer, pCopyFW + 0x160, 8);
	memset(pCopyFW + 0x160, 0xFF, 4);

	//259断电保护
	libusb_BYTE intBuffer_259_P1[2] = { 0 };
	libusb_BYTE intBuffer_259_P2[2] = { 0 };
	libusb_BYTE intBuffer_259_P3[21] = { 0 };
	if (chipID == 0x16)
	{
		memcpy(intBuffer_259_P1, pCopyFW, 2);
		memcpy(intBuffer_259_P2, pCopyFW + 0x6700, 2);
		memcpy(intBuffer_259_P3, pCopyFW + 0x6702, 0x15);
		memset(pCopyFW, 0xFF, 2);
		memset(pCopyFW + 0x6700, 0xFF, 0x17);
	}
	/*********************************************************************************/
	/*********************************************************************************/

	libusb_BYTE* pFw = pCopyFW;
	for (i = 0; i < fwLen; i += 8){
		if (setProgress && ((i % 0x200) == 0))
		{
			gProgress = (float)i / (float)fwLen;
			if (bFullCheckFW)
				gProgress *= 0.5f;
			setProgress(ptrClass, gProgress);
		}
		memset(data, 0xff, 8);
		memcpy(data, pFw + i, 8);
		if (!libusb_LibUsb_WriteDataToFlash(devh, i, data, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
	}


		/*********************************************************************************/
	/*********************************************************************************/
	/*烧录完成，恢复0x160地址数据*/
	if (!libusb_LibUsb_WriteDataToFlash(devh, 0x160, intBuffer, 8)){
		libusb_SAFE_DELETE_ARRAY(pCopyFW);
		return libusb_FALSE;
	}
	memcpy(pCopyFW + 0x160, intBuffer, 8);

	//259断电保护
	if (chipID == 0x16)
	{
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702, intBuffer_259_P3, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702 + 8, intBuffer_259_P3 + 8, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6702 + 16, intBuffer_259_P3 + 16, 5)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		if (!libusb_LibUsb_WriteDataToFlash(devh, 0, intBuffer_259_P1, 2)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		if (!libusb_LibUsb_WriteDataToFlash(devh, 0x6700, intBuffer_259_P2, 2)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}

		memcpy(pCopyFW, intBuffer_259_P1, 2);
		memcpy(pCopyFW + 0x6700, intBuffer_259_P2, 2);
		memcpy(pCopyFW + 0x6702, intBuffer_259_P3, 0x15);
	}
	/*********************************************************************************/
	/*********************************************************************************/

	if (bFullCheckFW)
	{
		if (setProgress)
			setProgress(ptrClass, 0.5f);
	}
	else
	{
		if (setProgress)
			setProgress(ptrClass, 1.0f);
	}

	libusb_LONG step = 1024;
	if (bFullCheckFW)
		step = 8;
	for (i = 0; i < fwLen; i += step)
	{
		memset(&data, 0xff, 8);
		if (!libusb_LibUsb_ReadDataFormFlash(devh, i, data, 8)){
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (0 != memcmp(data, pCopyFW + i, 8))
		{
			gEC = libusb_EC_BurnerCheckFail;
			libusb_SAFE_DELETE_ARRAY(pCopyFW);
			return libusb_FALSE;
		}
		if (bFullCheckFW && setProgress && ((i % 0x200) == 0))
		{
			gProgress = ((float)i / (float)fwLen) * 0.5;
			gProgress += 0.5f;
			setProgress(ptrClass, gProgress);
		}
	}
	if (bFullCheckFW)
	{
		if (setProgress)
			setProgress(ptrClass, 1.0f);
	}
	libusb_SAFE_DELETE_ARRAY(pCopyFW);
	return libusb_TRUE;
}

libusb_sonixbool libusb_SonixCam_SetParamTableFormFWFile(libusb_device_handle *devh, unsigned char pFW[], long lFwLength, const libusb_ChangeParamInfo *pParamInfo, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_SERIAL_FLASH_TYPE sft, char* pLogFilePath)
{
	if (sft == libusb_SFT_UNKNOW)
	{
		gEC = libusb_EC_UnKnowSerialFlashType;
		return libusb_false;
	}

	libusb_DWORD dwStringAddr = 0;
	libusb_ULONG dwParaTableStartAddr = 0;
	libusb_ULONG dwParaTableEndAddr = 0;
	libusb_ULONG dwCRCStartAddr = 0;
	if (!libusb_LibUsb_GetParaTableAndCRCAddrFormSF(devh, &dwParaTableStartAddr, &dwParaTableEndAddr, &dwCRCStartAddr))
		return libusb_false;

	printf("dwParaTableStartAddr :%x, dwParaTableEndAddr : %x, dwCRCStartAddr: %x", (int)dwParaTableStartAddr, (int)dwParaTableEndAddr, (int)dwCRCStartAddr);
	libusb_LONG SZ_4K = 4 * 1024;
	libusb_LONG SZ_16K = 16 * 1024;
	libusb_LONG SEA_4K = dwParaTableStartAddr / SZ_4K * SZ_4K;
	libusb_LONG SEA_16K = dwParaTableStartAddr / SZ_16K * SZ_16K;

	libusb_LONG startSectorEraseAddr = SEA_4K < SEA_16K ? SEA_4K : SEA_16K;
	libusb_LONG sectorEraseEndAddr = startSectorEraseAddr + SZ_16K;

	libusb_BYTE *pCopyFW = 0;
	pCopyFW = malloc(lFwLength);
	if (!pCopyFW)
		return libusb_false;
	memcpy(pCopyFW, pFW, lFwLength);

	libusb_LONG startAddr = startSectorEraseAddr;
	libusb_BOOL sf_hight_addr = libusb_FALSE;
	libusb_BYTE temp[8];
	libusb_BYTE addrLow;
	libusb_BYTE addrHigh;
	libusb_LONG addIndex = 0;
	float gProgress = 0.0;  //(0.0 - 1.0)

	if (pParamInfo->libusb_pVidPid)
	{
		libusb_BYTE *pBuffer = pCopyFW + (dwParaTableStartAddr + 0x06);
		memcpy(pBuffer, pParamInfo->libusb_pVidPid, 4);
	}
	if (pParamInfo->libusb_pProduct)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x40), (libusb_BYTE*)pParamInfo->libusb_pProduct, pParamInfo->libusb_ProductLength);
	}
	if (pParamInfo->libusb_pSerialNumber)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0xC0), (libusb_BYTE*)pParamInfo->libusb_pSerialNumber, pParamInfo->libusb_SerialNumberLength);
	}
	if (pParamInfo->libusb_pManufacture)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x80), (libusb_BYTE*)pParamInfo->libusb_pManufacture, pParamInfo->libusb_ManufactureLength);
	}
	if (pParamInfo->libusb_pString3)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x100), (libusb_BYTE*)pParamInfo->libusb_pString3, pParamInfo->libusb_String3Length);
	}
	if (pParamInfo->libusb_pInterface)
	{
		libusb_SetParamToParamBuffer(pCopyFW, (dwParaTableStartAddr + 0x140), (libusb_BYTE*)pParamInfo->libusb_pInterface, pParamInfo->libusb_InterfaceLength);
	}

	//CRC Check
	libusb_CheckCRC(pCopyFW, dwParaTableStartAddr, dwParaTableEndAddr - dwParaTableStartAddr, dwCRCStartAddr);

	//disable flash write protect
	if (!libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft))
	{
		gEC = libusb_EC_DisableFlashWriteProtectFail;
		free(pCopyFW);
		return libusb_false;
	}

	//sector erase
	libusb_LibUsb_EraseSectorForSerialFlash(devh, dwParaTableStartAddr, (libusb_SERIAL_FLASH_TYPE)sft);
	sleep(1);
	libusb_sonixbool bNeedEraseCrcSec = libusb_false;
	if(dwCRCStartAddr < SEA_4K || dwCRCStartAddr > (SEA_4K + SZ_4K)) //need erase crc sector
	{
		bNeedEraseCrcSec = libusb_TRUE;
		libusb_LibUsb_EraseSectorForSerialFlash(devh, dwCRCStartAddr / SZ_4K * SZ_4K, (libusb_SERIAL_FLASH_TYPE)sft);
		sleep(1);
	}

	startAddr = startSectorEraseAddr;
	sf_hight_addr = libusb_FALSE;
	libusb_LONG flashSectorSize = SZ_16K;
	libusb_BOOL eraseCheckArr[4] = { 0 };
	//erase check and get flash sector size
	libusb_LONG i = 0;
	for (i = 0; i < SZ_16K; i += 0x50)
	{
		memset(&temp, 0xff, 8);
		if(!libusb_LibUsb_ReadDataFormFlash(devh, startAddr, temp, 8)){
			free(pCopyFW);
			return libusb_false;
		}
		if (temp[0] != 0xFF || temp[1] != 0xFF ||
			temp[2] != 0xFF || temp[3] != 0xFF ||
			temp[4] != 0xFF || temp[5] != 0xFF ||
			temp[6] != 0xFF || temp[7] != 0xFF)
		{
			libusb_BYTE index = i / SZ_4K;
			eraseCheckArr[index] = libusb_TRUE;
			i = i / SZ_4K * SZ_4K + SZ_4K - 0x50; 
			flashSectorSize -= SZ_4K;
			startAddr = startAddr / SZ_4K * SZ_4K + SZ_4K;
			continue;
		}
		startAddr += 0x50;
	}
	

	if (!flashSectorSize)
	{
		gEC = libusb_EC_EraseFlashFail;
		return libusb_false;
	}

	//burner sector src date
	libusb_BYTE *pData = pCopyFW + startSectorEraseAddr;
	startAddr = startSectorEraseAddr;
	sf_hight_addr = libusb_FALSE;
	libusb_LONG s = 0;
	for (s = 0; s < 4; s++)
	{
		if (eraseCheckArr[s])
		{
			startAddr += SZ_4K;
			pData += SZ_4K;
			continue;
		}
		for (i = 0; i < SZ_4K; i += 8)
		{
			libusb_LONG addr = s * SZ_4K + i;
			if (setProgress && addr % 0x20)
			{
				gProgress = ((float)(addr / 2)) / (float)SZ_16K + 0.5f;
				setProgress(ptrClass, gProgress);
			}
			memcpy(temp, pData, 8);
			if(!libusb_LibUsb_WriteDataToFlash(devh, startAddr, temp, 8)){
				free(pCopyFW);
				return libusb_false;
			}
			startAddr += 8;
			pData += 8;
		}
	}

	if(bNeedEraseCrcSec)
	{
		libusb_LONG CRC_SEA_4K = dwCRCStartAddr / SZ_4K * SZ_4K;
		startAddr = CRC_SEA_4K;
		pData = pCopyFW + CRC_SEA_4K;
		for (i = 0; i < SZ_4K; i += 8)
		{
			//libusb_LONG addr = CRC_SEA_4K + i;
			//if (setProgress && addr % 0x20)
			//{
				//gProgress = ((float)(addr / 2)) / (float)SZ_16K + 0.5f;
				//setProgress(ptrClass, gProgress);
			//}
			
			if(startAddr == 0x11210){
				if(!libusb_LibUsb_ReadDataFormFlash(devh, startAddr, temp, 8)){
					free(pCopyFW);
					return libusb_false;
				}
				printf("read 0x11210 = %x %x %x %x %x %x %x %x\n", 
					temp[0],temp[1],temp[2],temp[3],temp[4],temp[5], temp[6],temp[7]);

			}

			memcpy(temp, pData, 8);
			if(!libusb_LibUsb_WriteDataToFlash(devh, startAddr, temp, 8)){
				free(pCopyFW);
				return libusb_false;
			}

			if(startAddr == 0x11210){
				printf("0x11210 = %x %x %x %x %x %x %x %x\n", 
					temp[0],temp[1],temp[2],temp[3],temp[4],temp[5], temp[6],temp[7]);

				if(!libusb_LibUsb_ReadDataFormFlash(devh, startAddr, temp, 8)){
					free(pCopyFW);
					return libusb_false;
				}
				printf("read 0x11210 = %x %x %x %x %x %x %x %x\n", 
					temp[0],temp[1],temp[2],temp[3],temp[4],temp[5], temp[6],temp[7]);

			}
				
			startAddr += 8;
			pData += 8;

		}
	}

	//burn check
	startAddr = startSectorEraseAddr;
	pData = pCopyFW + startSectorEraseAddr;
	sf_hight_addr = libusb_FALSE;
	i = 0;
	for (i = 0; i < SZ_16K; i += 0x200)
	{
		memset(&temp, 0xFF, 8);
		if(!libusb_LibUsb_ReadDataFormFlash(devh, startAddr, temp, 8)){
			free(pCopyFW);
			return libusb_false;
		}
		if (temp[0] != *(pData + i) || temp[1] != *(pData + i + 1) ||
			temp[2] != *(pData + i + 2) || temp[3] != *(pData + i + 3) ||
			temp[4] != *(pData + i + 4) || temp[5] != *(pData + i + 5) ||
			temp[6] != *(pData + i + 6) || temp[7] != *(pData + i + 7)
			)
		{
			gEC = libusb_EC_BurnerCheckFail;
			free(pCopyFW);
			return libusb_false;
		}
		startAddr += 0x200;
	}
	free(pCopyFW);
	return libusb_true;
}


