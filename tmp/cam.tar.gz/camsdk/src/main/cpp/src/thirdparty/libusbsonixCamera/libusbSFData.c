#include "include/libusbSFData.h"

libusb_BYTE libusb_ubSFLib_CmdID = 0;
libusb_BYTE libusb_sfManufactureID = 0;
libusb_BYTE libusb_sfDeviceID1 = 0;
libusb_BYTE libusb_sfDeviceID2 = 0;

libusb_BYTE libusb_cbSFLib_Cmd[][7] = {
	//READ			  WREN			  PP				 WRSR			 CE				SE				WRDI
	{ libusb_SFCMD_READ_MXIC, libusb_SFCMD_WRDI_MXIC, libusb_SFCMD_READ_MXIC, libusb_SFCMD_RDSR_MXIC, libusb_SFCMD_READ_MXIC, libusb_SFCMD_READ_MXIC, libusb_SFCMD_WRDI_MXIC },	// 0x00
	{ libusb_SFCMD_READ_MXIC, libusb_SFCMD_WREN_MXIC, libusb_SFCMD_PP_MXIC, libusb_SFCMD_WRSR_MXIC, libusb_SFCMD_CE_MXIC, libusb_SFCMD_SE_MXIC, libusb_SFCMD_WRDI_MXIC },	// 0x01
	{ libusb_SFCMD_READ_AT25FS, libusb_SFCMD_WREN_AT25FS, libusb_SFCMD_PP_AT25FS, libusb_SFCMD_WRSR_AT25FS, libusb_SFCMD_CE_AT25FS, libusb_SFCMD_SE_AT25FS, libusb_SFCMD_WRDI_AT25FS },	// 0x02
	{ libusb_SFCMD_READ_PMC, libusb_SFCMD_WREN_PMC, libusb_SFCMD_PP_PMC, libusb_SFCMD_WRSR_PMC, libusb_SFCMD_CE_PMC, libusb_SFCMD_SE_PMC, libusb_SFCMD_WRDI_PMC },	// 0x03
	{ libusb_SFCMD_READ_SST, libusb_SFCMD_WREN_SST, libusb_SFCMD_AAIP_SST, libusb_SFCMD_WRSR_SST, libusb_SFCMD_CE_SST, libusb_SFCMD_SE_SST, libusb_SFCMD_WRDI_SST },	// 0x04
};


libusb_BYTE libusb_cbSFLib_ID[][6] = {
	{ libusb_SF_UNKNOW, 0x00, 0x00, libusb_SF_UNKNOW, 0x00, libusb_SF_OPT_NA },

	{ libusb_SF_MFRID_MXIC, 0x20, 0x10, libusb_SF_MXIC, 0x01, libusb_SF_OPT_SE },				// MXIC MX25L512AMC
	{ libusb_SF_MFRID_MXIC, 0x22, 0x10, libusb_SF_MXIC, 0x01, libusb_SF_OPT_SE },				//MX25L5121E
	{ libusb_SF_MFRID_MXIC, 0x20, 0x13, libusb_SF_MXIC, 0x01, libusb_SF_OPT_SE },				// KH25L4006E

	{ libusb_SF_MFRID_ATMEL, 0x65, 0x01, libusb_SF_ATMEL_AT25F, 0x02, libusb_SF_OPT_SE },		// Atmel AT25F512B

	{ libusb_SF_MFRID_PMC, 0x20, 0xFF, libusb_SF_PMC, 0x03, libusb_SF_OPT_SE },				// PMC Pm25LD512
	{ libusb_SF_MFRID_PMC, 0x7B, 0xFF, libusb_SF_PMC, 0x03, libusb_SF_OPT_SE },				// PMC Pm25LV512
	{ libusb_SF_MFRID_PMC, 0x10, 0xFF, libusb_SF_PMC, 0x03, libusb_SF_OPT_SE },

	{ libusb_SF_MFRID_SST, 0x48, 0xFF, libusb_SF_SST, 0x04, libusb_SF_OPT_SE },				// SST 25VF512
	{ libusb_SF_MFRID_ST, 0x20, 0x11, libusb_SF_ST, 0x01, libusb_SF_OPT_SE },

	{ libusb_SF_MFRID_ESMT, 0x30, 0x10, libusb_SF_ESMT, 0x01, libusb_SF_OPT_SE },				// F25L05PA

	{ libusb_SF_MFRID_GIGA, 0x40, 0x10, libusb_SF_GIGA, 0x01, libusb_SF_OPT_SE },				// GD25Q512
	{ libusb_SF_MFRID_GIGA, 0x40, 0x13, libusb_SF_GIGA, 0x01, libusb_SF_OPT_SE },				//MK25D40

	{ libusb_SF_MFRID_WINBOND, 0x30, 0x10, libusb_SF_WINBOND, 0x01, libusb_SF_OPT_SE },		//W25X05CL
	{ libusb_SF_MFRID_WINBOND, 0x30, 0x11, libusb_SF_WINBOND, 0x01, libusb_SF_OPT_SE },

	//special
	{ libusb_SF_MFRID_FENTECH, 0x60, 0x13, libusb_SF_FENTECH, 0x01, libusb_SF_OPT_SE },				//FH25VQ40
	{ libusb_SF_MFRID_FENTECH, 0x60, 0x12, libusb_SF_FENTECH, 0x01, libusb_SF_OPT_SE },				//FH25VQ20

	{ libusb_SF_MFRID_MXIC, 0x20, 0x11, libusb_SF_MXIC, 0x01, libusb_SF_OPT_SE },				// MX25L1006E

};

libusb_LONG libusb_ubSFLib_GetIDSize()
{
	return sizeof(libusb_cbSFLib_ID) / 6;
}

