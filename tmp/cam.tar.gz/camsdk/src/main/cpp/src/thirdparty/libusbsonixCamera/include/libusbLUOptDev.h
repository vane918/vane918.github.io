#ifndef __LIBUSBLUOPTDEV_H__
#define __LIBUSBLUOPTDEV_H__

#include "libusbutil.h"
#include "libusbROMData.h"
#include "libusbSFData.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "../../libusb/libusb/libusb.h"

#define libusbUSB_RQ			0x85
#define libusbCTRL_IN			0xa1
#define libusbCTRL_OUT		0x21
#define libusbASIC_RW			0x0100
#define libusbI2C_RW			0x0200
#define libusbFLASH_RW		0x0300
#define libusbROM_RW 			0x0400

#define libusbMAX_CAM_NUM		8

libusb_BOOL libusb_VidPidStringToInt(char *vidpid, libusb_USHORT *vid, libusb_USHORT *pid);

libusb_BOOL libusb_LibUsb_RestartDevice(libusb_device_handle * devh);

libusb_BOOL libusb_LibUsb_GetChipID(libusb_device_handle *devh, libusb_LONG idAddr, libusb_BYTE *pChipID);
libusb_DSP_ROM_TYPE libusb_LibUsb_GetChipRomType(libusb_device_handle * devh, libusb_BYTE *chipID, libusb_DSP_ARCH_TYPE *dspArchType);
libusb_USHORT libusb_GetUVCExtendUnitID(libusb_device_handle *devh);

libusb_BOOL libusb_LibUsb_EnableAsicRegisterBit(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE bit);
libusb_BOOL libusb_LibUsb_DisableAsicRegisterBit(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE bit);
libusb_BOOL libusb_LibUsb_SFWaitReady(libusb_device_handle *devh);

libusb_BOOL libusb_LibUsb_ReadFromASIC(libusb_device_handle *devh, libusb_USHORT addr, libusb_BYTE *pValue);
libusb_BOOL libusb_LibUsb_WriteToASIC(libusb_device_handle *devh, libusb_USHORT addr, libusb_BYTE value);

libusb_BOOL libusb_LibUsb_GetMemType(libusb_device_handle *devh, libusb_BYTE *pMemType);
libusb_BOOL libusb_LibUsb_ReadFromROM(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE data[]);

libusb_BOOL libusb_LibUsb_ReadFromSensor(libusb_BYTE slaveID, libusb_USHORT addr, libusb_BYTE pData[], libusb_LONG len);
libusb_BOOL libusb_LibUsb_WriteToSensor(libusb_BYTE slaveID, libusb_USHORT addr, libusb_BYTE pData[], libusb_LONG len);
libusb_BOOL libusb_LibUsb_CustomReadFromSensor(libusb_device_handle *devh, libusb_BYTE slaveID, libusb_USHORT addr, libusb_USHORT addrByteNum, libusb_USHORT *pData, libusb_LONG dataByteNum, libusb_sonixbool pollSCL);
libusb_BOOL libusb_LibUsb_CustomWriteToSensor(libusb_device_handle *devh, libusb_BYTE slaveID, libusb_USHORT addr, libusb_USHORT addrByteNum, libusb_USHORT data, libusb_LONG dataByteNum, libusb_sonixbool pollSCL);

libusb_BOOL libusb_LibUsb_Read(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs);
libusb_BOOL libusb_LibUsb_Write(libusb_device_handle *evh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs);
libusb_BOOL libusb_XU_Read(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs);
libusb_BOOL libusb_XU_Write(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs);

libusb_BOOL libusb_LibUsb_GetSerialFlashType(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE *sft, libusb_sonixbool check);

libusb_BOOL libusb_LibUsb_ReadFormSF(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_LONG len);
libusb_BOOL libusb_LibUsb_WriteToSF(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_LONG le, libusb_SERIAL_FLASH_TYPE sft);

libusb_BOOL libusb_LibUsb_ReadDataFormFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_BYTE dataLen);
libusb_BOOL libusb_LibUsb_WriteDataToFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_BYTE dataLen);

libusb_BOOL libusb_LibUsb_DisableSerialFlashWriteProtect(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft);

libusb_BOOL libusb_LibUsb_EraseSectorForSerialFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_SERIAL_FLASH_TYPE sft);
libusb_BOOL libusb_LibUsb_EraseBlockForSerialFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_SERIAL_FLASH_TYPE sft);
libusb_BOOL libusb_LibUsb_SerialFlashErase(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft);

libusb_BOOL libusb_LibUsb_DefGetAsicRomVersion(libusb_device_handle *devh, libusb_BYTE romVersion[]);
libusb_BOOL libusb_LibUsb_GetAsicRomVersion(libusb_device_handle *devh, libusb_BYTE romVersion[]);
libusb_BOOL libusb_LibUsb_SFCMDreadStatus(libusb_device_handle *devh);

libusb_BOOL libusb_LibUsb_GetParaTableAndCRCAddrFormFW(libusb_device_handle *devh, libusb_BYTE *pFW, libusb_ULONG* paraTableStartAddr, libusb_ULONG* paraTableEndAddr, libusb_ULONG* crcAddr);
libusb_BOOL libusb_LibUsb_GetParaTableAndCRCAddrFormSF(libusb_device_handle *devh, libusb_ULONG *paraTableStartAddr, libusb_ULONG *paraTableEndAddr, libusb_ULONG *crcAddr);
libusb_BOOL libusb_LibUsb_GetStringSettingFormSF(libusb_device_handle *devh, libusb_BYTE* pbyString, libusb_DWORD stringSize, libusb_DWORD StringOffset, libusb_BOOL bIsCRCProtect);

#endif





