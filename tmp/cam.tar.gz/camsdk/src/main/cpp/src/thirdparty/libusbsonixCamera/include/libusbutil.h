#ifndef __LIBUSBUTIL_H__
#define __LIBUSBUTIL_H__


#ifndef libusb_true
#define libusb_true 1
#endif
#ifndef libusb_false
#define libusb_false 0
#endif
#ifndef libusb_TRUE
#define libusb_TRUE 1
#endif
#ifndef libusb_FALSE
#define libusb_FALSE 0
#endif

typedef int libusb_sonixbool;
typedef int libusb_BOOL;
typedef long libusb_LONG;
typedef unsigned long libusb_ULONG;
typedef unsigned char libusb_BYTE;
typedef unsigned short libusb_USHORT;
typedef unsigned int libusb_DWORD;

#define libusb_SAFE_DELETE_ARRAY(x) { if (x) free(x); x = NULL; }

typedef enum
{
	libusb_EC_UnKnow,
	libusb_EC_EnumDeviceFail,
	libusb_EC_DisableFlashWriteProtectFail,
	libusb_EC_EraseFlashFail,
	libusb_EC_EraseFlashSectorFail,
	libusb_EC_GetAsicIdFail,
	libusb_EC_GetAsicRomVersionFail,
	libusb_EC_GetAsicRomTypeFail,
	libusb_EC_ReadAsicRegisterFail,
	libusb_EC_WriteAsicRegisterFail,
	libusb_EC_UnKnowSerialFlashType,
	libusb_EC_BurnerCheckFail,
	libusb_EC_CoInitializeFail,
	libusb_EC_NoFindDevice,
	libusb_EC_MallocMemoryFail,
}libusb_ERROR_CODE;


typedef enum
{
	libusb_SFT_UNKNOW,
	libusb_SFT_MXIC,
	libusb_SFT_ST,
	libusb_SFT_SST,
	libusb_SFT_ATMEL_AT25F,
	libusb_SFT_ATMEL_AT25FS,
	libusb_SFT_ATMEL_AT45DB,
	libusb_SFT_WINBOND,
	libusb_SFT_PMC,
	libusb_SFT_MXIC_LIKE,
	libusb_SFT_AMIC,
	libusb_SFT_EON,
	libusb_SF_ESMT,
	libusb_SFT_GIGA,
	libusb_SFT_FENTECH
}libusb_SERIAL_FLASH_TYPE;

typedef enum
{
	libusb_DRT_Unknow,
	libusb_DRT_32K,
	libusb_DRT_64K,
	libusb_DRT_128K,
	libusb_DRT_256K
}libusb_DSP_ROM_TYPE;

#endif

