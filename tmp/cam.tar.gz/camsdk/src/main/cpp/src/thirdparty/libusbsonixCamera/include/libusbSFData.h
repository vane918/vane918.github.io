#ifndef __LIBUSBSFDATE_H__
#define __LIBUSBSFDATE_H__
#include "libusbutil.h"

#define libusb_SF_OPT_NA		0x00
#define libusb_SF_OPT_SE		0x01
#define libusb_SF_OPT_BIGSZ	0x02		//Big size  > 64KB


#define libusb_SF_UNKNOW		0
#define libusb_SF_MXIC			1
#define libusb_SF_ST			2
#define libusb_SF_SST			3
#define libusb_SF_ATMEL_AT25F		4
#define libusb_SF_ATMEL_AT25FS		5
#define libusb_SF_ATMEL_AT2DBF		6
#define libusb_SF_WINBOND		7
#define libusb_SF_PMC			8
#define libusb_SF_MXIC_LIKE		9
#define libusb_SF_AMIC			10
#define libusb_SF_EON			11
#define libusb_SF_ESMT			12
#define libusb_SF_GIGA			13
#define libusb_SF_FENTECH		14

#define libusb_SFCMD_WREN_MXIC				0x06
#define libusb_SFCMD_WRDI_MXIC				0x04
#define libusb_SFCMD_RDID_MXIC				0x9f
#define libusb_SFCMD_RDSR_MXIC				0x05
#define libusb_SFCMD_WRSR_MXIC				0x01
#define libusb_SFCMD_READ_MXIC				0x03
#define libusb_SFCMD_SE_MXIC				0x20
#define libusb_SFCMD_BE_MXIC				0x52
#define libusb_SFCMD_CE_MXIC				0x60
#define libusb_SFCMD_PP_MXIC				0x02
#define libusb_SFCMD_DP_MXIC				0xb9
#define libusb_SFCMD_RDP_MXIC				0xab
#define libusb_SFCMD_RES_MXIC				0xab
#define libusb_SFCMD_REMS_MXIC				0x90

#define libusb_SFCMD_WREN_ST				0x06
#define libusb_SFCMD_WRDI_ST				0x04
#define libusb_SFCMD_RDID_ST				0x9f
#define libusb_SFCMD_RDSR_ST				0x05
#define libusb_SFCMD_WRSR_ST				0x01
#define libusb_SFCMD_READ_ST				0x03
#define libusb_SFCMD_PP_ST				0x02
#define libusb_SFCMD_SE_ST				0xd8					//different with MXIC
#define libusb_SFCMD_BE_ST				0xc7					//different with MXIC
#define libusb_SFCMD_DP_ST				0xb9
#define libusb_SFCMD_RES_ST				0xab

#define libusb_SFCMD_WREN_SST				0x06
#define libusb_SFCMD_WRDI_SST				0x04
#define libusb_SFCMD_RDSR_SST				0x05
#define libusb_SFCMD_WRSR_SST				0x01
#define libusb_SFCMD_EWSR_SST				0x50
#define libusb_SFCMD_READ_SST				0x03
#define libusb_SFCMD_SE_SST				0x20
#define libusb_SFCMD_BE_SST				0x52
#define libusb_SFCMD_CE_SST				0x60
#define libusb_SFCMD_BP_SST				0x02					//byte program
#define libusb_SFCMD_AAIP_SST				0xaf					//not support in MXIC
#define libusb_SFCMD_REMS_SST				0x90

#define libusb_SFCMD_WREN_AT25F			0x06
#define libusb_SFCMD_WRDI_AT25F			0x04
#define libusb_SFCMD_RDSR_AT25F			0x05
#define libusb_SFCMD_WRSR_AT25F			0x01
#define libusb_SFCMD_READ_AT25F			0x03
#define libusb_SFCMD_PP_AT25F				0x02
#define libusb_SFCMD_SE_AT25F				0x52					//different with MXIC
#define libusb_SFCMD_CE_AT25F				0x62					//different with MXIC
#define libusb_SFCMD_RDID_AT25F			0x15					//different with MXIC

#define libusb_SFCMD_WREN_AT25FS			0x06
#define libusb_SFCMD_WRDI_AT25FS			0x04
#define libusb_SFCMD_RDSR_AT25FS			0x05
#define libusb_SFCMD_WRSR_AT25FS			0x01
#define libusb_SFCMD_READ_AT25FS			0x03
#define libusb_SFCMD_PP_AT25FS				0x02
#define libusb_SFCMD_SE_AT25FS				0x20
#define libusb_SFCMD_BE_AT25FS				0x52
#define libusb_SFCMD_CE_AT25FS				0x60
#define libusb_SFCMD_RDID_AT25FS			0x9f

#define libusb_SFCMD_WREN_WINBOND			0x06
#define libusb_SFCMD_WRDI_WINBOND			0x04
#define libusb_SFCMD_RDSR_WINBOND			0x05
#define libusb_SFCMD_WRSR_WINBOND			0x01
#define libusb_SFCMD_READ_WINBOND			0x03
#define libusb_SFCMD_PP_WINBOND			0x02
#define libusb_SFCMD_BE_WINBOND			0xd8					//different with MXIC
#define libusb_SFCMD_CE_WINBOND			0xc7					//different with MXIC
#define libusb_SFCMD_SE_WINBOND			0x20
#define libusb_SFCMD_RES_WINBOND			0xab
#define libusb_SFCMD_REMS_WINBOND			0x90
#define libusb_SFCMD_RDID_WINBOND			0x9f					//W25P80, W25P16, W25P32

#define libusb_SFCMD_WREN_PMC				0x06
#define libusb_SFCMD_WRDI_PMC				0x04
#define libusb_SFCMD_RDSR_PMC				0x05
#define libusb_SFCMD_WRSR_PMC				0x01
#define libusb_SFCMD_READ_PMC				0x03
#define libusb_SFCMD_PP_PMC				0x02
#define libusb_SFCMD_SE_PMC				0xd7					//different with MXIC
#define libusb_SFCMD_BE_PMC				0xd8					//different with MXIC
#define libusb_SFCMD_CE_PMC				0xc7					//different with MXIC
#define libusb_SFCMD_RES_PMC				0xab
#define libusb_SFCMD_RDID_PMC				0x9f					//Pm25LV010, Pm25LV020, Pm25LV040

#define libusb_SFCMD_WREN_AMIC				0x06
#define libusb_SFCMD_WRDI_AMIC				0x04
#define libusb_SFCMD_RDSR_AMIC				0x05
#define libusb_SFCMD_WRSR_AMIC				0x01
#define libusb_SFCMD_READ_AMIC				0x03
#define libusb_SFCMD_PP_AMIC				0x02
#define libusb_SFCMD_SE_AMIC				0xd8					//different with MXIC
#define libusb_SFCMD_BE_AMIC				0xc7					//different with MXIC
#define libusb_SFCMD_CE_AMIC				0xc7					//different with MXIC
#define libusb_SFCMD_RES_AMIC				0xab
#define libusb_SFCMD_RDID_AMIC				0x9f					//Pm25LV010, Pm25LV020, Pm25LV040

#define libusb_SFCMD_WREN_EON				0x06
#define libusb_SFCMD_WRDI_EON				0x04
#define libusb_SFCMD_RDSR_EON				0x05
#define libusb_SFCMD_WRSR_EON				0x01
#define libusb_SFCMD_READ_EON				0x03
#define libusb_SFCMD_PP_EON				0x02
#define libusb_SFCMD_SE_EON				0x20
#define libusb_SFCMD_BE_EON				0x52
#define libusb_SFCMD_CE_EON				0x60
#define libusb_SFCMD_DP_EON				0xB9
#define libusb_SFCMD_RDP_EON				0xAB
#define libusb_SFCMD_REMS_EON				0x90
#define libusb_SFCMD_RDID_EON				0x9F

// special type
#define libusb_SFCMD_RDSR_AT45DB			0xd7
#define libusb_SFCMD_READ_AT45DB			0xe8

// manufacturer ID
#define libusb_SF_MFRID_CONT				0x7f
#define libusb_SF_MFRID_MXIC				0xc2
#define libusb_SF_MFRID_ST					0x20
#define libusb_SF_MFRID_SST				0xbf
#define libusb_SF_MFRID_ATMEL				0x1f
#define libusb_SF_MFRID_WINBOND			0xef
#define libusb_SF_MFRID_PMC				0x9d
#define libusb_SF_MFRID_AMIC				0x37
#define libusb_SF_MFRID_EON				0x1C
#define libusb_SF_MFRID_ESMT				0x8C
#define libusb_SF_MFRID_GIGA				0xC8
//special manufacturer id 
#define libusb_SF_MFRID_FENTECH			0x5E
// product type
//#define SF_UNKNOWN				0x00

#define libusb_MX25L512					0x01
#define libusb_MX25L1005					0x02
#define libusb_MX25L2005					0x03
#define libusb_MX25L4005					0x04
#define libusb_MX25L8005					0x05
#define libusb_MX25L1605					0x06
#define libusb_MX25L3205					0x07
#define libusb_MX25L6405					0x08

#define libusb_STM25P05					0x10
#define libusb_STM25P10					0x11

#define libusb_AT25F512					0x20
#define libusb_AT25F1024					0x21
#define libusb_AT25F2048					0x22
#define libusb_AT25F4096					0x23
#define libusb_AT25FS040					0x30
#define libusb_AT45DB011					0x40
#define libusb_AT45DB041					0x41

#define libusb_SST25VF512					0x50
#define libusb_SST25VF010					0x51

#define libusb_W25P10						0x70
#define libusb_W25P20						0x71
#define libusb_W25P40						0x72
#define libusb_W25P80						0x73
#define libusb_W25P16						0x74
#define libusb_W25P32						0x75
#define libusb_W25B40_BB					0x76
#define libusb_W25B40_TB					0x77
#define libusb_W25X10						0x78
#define libusb_W25X20						0x79
#define libusb_W25X40						0x7a
#define libusb_W25X80						0x7b

#define libusb_PM25LV512					0x80
#define libusb_PM25LV010					0x81
#define libusb_PM25LV020					0x82
#define libusb_PM25LV040					0x83

#define libusb_A25L05PT					0x90
#define libusb_A25L05PU					0x91
#define libusb_A25L10PT					0x92
#define libusb_A25L10PU					0x93
#define libusb_A25L20PT					0x94
#define libusb_A25L20PU					0x95

#define libusb_EN25F05						0xA0

#define libusb_SF_OPT_NA					0x00
#define libusb_SF_OPT_SE					0x01
#define libusb_SF_OPT_BIGSZ					0x02		//Big size  > 64KB



enum
{
	libusb_SFCMD_IDX_READ = 0,
	libusb_SFCMD_IDX_WREN,
	libusb_SFCMD_IDX_PP,
	libusb_SFCMD_IDX_WRSR,
	libusb_SFCMD_IDX_CE,
	libusb_SFCMD_IDX_SE,
	libusb_SFCMD_IDX_WRDI
};

enum
{
	libusb_SFCMD_INFO_MFR = 0,
	libusb_SFCMD_INFO_DEVID1,
	libusb_SFCMD_INFO_DEVID2,
	libusb_SFCMD_INFO_TYPE,
	libusb_SFCMD_INFO_CMD_ID,
	libusb_SFCMD_INFO_SF_OPT,
};


extern  libusb_BYTE libusb_cbSFLib_Cmd[][7];
extern  libusb_BYTE libusb_cbSFLib_ID[][6];
extern  libusb_BYTE libusb_cbSFLib_Ver[];

extern libusb_BYTE libusb_ubSFLib_CmdID;

extern libusb_LONG libusb_ubSFLib_GetIDSize();

extern libusb_BYTE libusb_sfManufactureID;
extern libusb_BYTE libusb_sfDeviceID1;
extern libusb_BYTE libusb_sfDeviceID2;

#endif
