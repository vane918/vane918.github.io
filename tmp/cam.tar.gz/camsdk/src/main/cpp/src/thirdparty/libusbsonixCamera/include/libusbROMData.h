#ifndef __LIBUSBROMDATA_H__
#define __LIBUSBROMDATA_H__

#include "libusbutil.h"

enum
{
	libusb_ADDR_9FF8,
	libusb_ADDR_D2B2,
	libusb_ADDR_DFF8,
	libusb_ADDR_BFF8,
	libusb_ADDR_C7F8,
	libusb_ADDR_AFF8,
	libusb_ROMSTRADDRCNT
};


enum {
	libusb_ROM220,
	libusb_ROM225,
	libusb_ROM250V1,
	libusb_ROM250V2,
	libusb_ROM230V1,
	libusb_ROM230V2,
	libusb_ROM230V3,
	libusb_ROM231V1,
	libusb_ROM216V1,
	libusb_ROM215V1,
	libusb_ROM236V1,
	libusb_ROM236V2,
	libusb_ROM256V1,
	libusb_ROM231V2,
	libusb_ROM266V1,
	libusb_ROM276V1,
	libusb_ROM275V1,
	libusb_ROM290V1,	// shawn 2010/08/11 add
	libusb_ROM290V2,	// shawn 2011/01/31 add
	libusb_ROM286V1,	// shawn 2010/12/30 add
	libusb_ROM288V1,	// shawn 2011/06/10 add
	libusb_ROM289V1,	// shawn 2011/08/23 add
	libusb_ROM270V1,	// shawn 2012/02/08 add
	libusb_ROM271V1,	// shawn 2012/02/08 add
	libusb_ROM280V1,	// Daniel 2012/09/13 add
	libusb_ROM281V1,	// Daniel 2012/09/13 add
	libusb_ROM232V1,
	libusb_ROM232V2,
	libusb_ROM272V1,	// Jyh 2015/2/5
	libusb_ROM273V0,
	libusb_ROM275V2,
	libusb_ROM283,//wei add 283
	libusb_ROM292,//wei add 292
	libusb_ROM287,//wei add 287
	libusb_ROM267,//yiling add 267
	libusb_ROM276V2,//liwei add 276V2
	libusb_ROM285,//liwei add 285V0
	libusb_ROM286,//liwei add 286V0
	libusb_ROMCOUNT
};

typedef struct
{
	libusb_USHORT libusb_RomStringAddr;
	unsigned char RomString[8];
	libusb_USHORT SFTypeAddr;
	libusb_USHORT CodeVerAddr1;
	libusb_USHORT CodeVerAddr2;
	unsigned long Bypass;
	libusb_sonixbool IsNewestVer;		// for Lib compatibility
	libusb_sonixbool IsSWErase;			// shawn 2009/04/03 add
	libusb_sonixbool IsDisSFWriteCmd;	// shawn 2009/04/03 add
	libusb_sonixbool IsGeneric;			// shawn 2010/04/14 add
	libusb_sonixbool IsCompactMode;		// shawn 2010/05/11 add
	libusb_sonixbool IsLCVer;			// sha
} libusb_ROM_INFO;

extern libusb_USHORT libusb_RomStringAddr[libusb_ROMSTRADDRCNT];

extern libusb_ROM_INFO libusb_RomInfo[libusb_ROMCOUNT];

extern unsigned int libusb_uiRomID;

typedef enum
{
	libusb_DAT_UNKNOW = -1,
	libusb_DAT_FIRST,
	libusb_DAT_SECOND,
	libusb_DSP_ARCH_COUNT
}libusb_DSP_ARCH_TYPE;

typedef struct
{
	libusb_USHORT libusb_asicIdAddr;
	libusb_USHORT libusb_sfRdyAddr;
	libusb_USHORT libusb_usbResetAddr;
	libusb_USHORT libusb_gpioInputAddr;
	libusb_USHORT libusb_gpioOutputAddr;
	libusb_USHORT libusb_gpioOEAddr;
	libusb_USHORT libusb_sfModeAddr;
	libusb_USHORT libusb_sfCSAddr;
	libusb_USHORT libusb_sfWriteDataAddr;
	libusb_USHORT libusb_sfReadDataAddr;
	libusb_USHORT libusb_sfReadWriteTriggerAddr;

	libusb_USHORT libusb_i2cDev;
	libusb_USHORT libusb_i2cMode;
	libusb_USHORT libusb_i2cTrg;
	libusb_USHORT libusb_i2cSclSelOD;
	libusb_USHORT libusb_i2cSlaveID;
	libusb_USHORT libusb_i2cDataArrStartAddr;

}libusb_DSP_ARCH_INFO;

extern libusb_USHORT libusb_dspIdAddr;
extern libusb_USHORT libusb_sfRdyAddr;
extern libusb_USHORT libusb_usbResetAddr;
extern libusb_USHORT libusb_usbResetAddr;
extern libusb_USHORT libusb_gpioOutputAddr;
extern libusb_USHORT libusb_gpioOEAddr;
extern libusb_USHORT libusb_sfModeAddr;
extern libusb_USHORT libusb_sfCSAddr;
extern libusb_USHORT libusb_sfWriteDataAddr;
extern libusb_USHORT libusb_sfReadDataAddr;
extern libusb_USHORT libusb_sfReadWriteTriggerAddr;

extern libusb_USHORT libusb_i2cDev;
extern libusb_USHORT libusb_i2cMode;
extern libusb_USHORT libusb_i2cTrg;
extern libusb_USHORT libusb_i2cSclSelOD;
extern libusb_USHORT libusb_i2cSlaveID;
extern libusb_USHORT libusb_i2cDataArrStartAddr;


extern libusb_DSP_ARCH_INFO libusb_g_AsicArchInfo[libusb_DSP_ARCH_COUNT];
extern libusb_USHORT libusb_g_CurDspExtendUnitID;
extern libusb_DSP_ARCH_INFO libusb_g_CurDspArchInfo;

libusb_BOOL libusb_LibUsb_SetAsicArchInfo(libusb_DSP_ARCH_TYPE dspArchType);

#endif
