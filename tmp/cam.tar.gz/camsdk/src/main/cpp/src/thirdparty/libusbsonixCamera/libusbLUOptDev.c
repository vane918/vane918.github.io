#include "libusbLUOptDev.h"

libusb_ERROR_CODE gEC = libusb_EC_UnKnow;

long libusb_g_nDevNum = 0;
struct usb_device* 	libusb_g_pAllDevice[libusbMAX_CAM_NUM];

unsigned char libusb_chr2hex(char chr)
{
	if(chr >= '0' && chr <= '9')
		return (chr - '0');
	if(chr >= 'A' && chr <= 'F')
		return (chr - 'A' + 10);
	if(chr >= 'a' && chr <= 'f')
		return (chr - 'a' + 10);
	return 0;
}

unsigned int libusb_cal_pow(int src, int v)
{
	int i;
	unsigned int ret = 1;
	if(v == 0)
	return  1;
	for(i = 0; i < v; i++)
	{
		ret *= src;
	}
	return ret;
}

libusb_BOOL libusb_VidPidStringToInt(char *vidpid, libusb_USHORT *vid, libusb_USHORT *pid)
{
    if(!vidpid)
        return libusb_TRUE;
    libusb_LONG len = strlen(vidpid);
    if(len != 8)
        return libusb_FALSE;
    libusb_LONG i = 0;
    *vid = 0;
    *pid = 0;
	for(i = len; i > 0; i--)
	{
        unsigned char var = libusb_chr2hex(vidpid[len - i]);
        if(i <= 4)
		*pid += var * libusb_cal_pow(16, i - 1);
        else
        *vid += var * libusb_cal_pow(16, i - 5);
	}
	return libusb_TRUE;
}


libusb_USHORT libusb_GetUVCExtendUnitID(libusb_device_handle *devh)
{
	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE dspArchType;

	libusb_g_CurDspExtendUnitID = 0x300;
	libusb_DSP_ROM_TYPE romType = libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType);
	if(libusb_DRT_Unknow != romType){
		return 0x300;
	 }

	libusb_g_CurDspExtendUnitID = 0x400;
	romType = libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType);
	if(libusb_DRT_Unknow != romType)
		return 0x400;
	
	printf("Get uvc extend unit id fail\n");
	return 0;
}

libusb_BOOL libusb_LibUsb_RestartDevice(libusb_device_handle *devh)
{
	libusb_BYTE romVersion[10] = { 0 };
	if (libusb_TRUE != libusb_LibUsb_GetAsicRomVersion(devh, romVersion))
	{
		gEC = libusb_EC_GetAsicRomVersionFail;
		return libusb_FALSE;
	}
	if ((libusb_uiRomID == libusb_ROM220) || (libusb_uiRomID == libusb_ROM225)){
		return libusb_FALSE;
	}
	else if ((libusb_uiRomID == libusb_ROM283) || (libusb_uiRomID == libusb_ROM292)){
		libusb_BYTE TempVar = 0;
		if (libusb_TRUE != libusb_LibUsb_ReadFromASIC(devh, libusb_usbResetAddr , &TempVar)){
			return libusb_FALSE;
		}
		TempVar &= 0xFE;
		libusb_LibUsb_WriteToASIC(devh, libusb_usbResetAddr , TempVar);		//Always Error because of HW reset, Ignore it.
		usleep(1000);
		return libusb_TRUE;
	}
	else{
		libusb_LibUsb_WriteToASIC(devh, libusb_usbResetAddr , 0x00);
		return libusb_TRUE;
	}
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_GetChipID(libusb_device_handle *devh, libusb_LONG idAddr, libusb_BYTE *pChipID)
{
	libusb_BYTE chipID = 0;
	if(!libusb_LibUsb_ReadFromASIC(devh, idAddr, &chipID))
		return libusb_FALSE;

	*pChipID = chipID;
    return libusb_TRUE;
}


libusb_DSP_ROM_TYPE libusb_LibUsb_GetChipRomType(libusb_device_handle *devh, libusb_BYTE *dspChipID, libusb_DSP_ARCH_TYPE *dspArchType)
{
	libusb_LONG i = 0;
	libusb_DSP_ROM_TYPE ret = libusb_DRT_Unknow;
	libusb_BYTE chipId = 0;
	libusb_DSP_ARCH_TYPE dspArchIndex = libusb_DAT_UNKNOW;
	for(i = 0; i < libusb_DSP_ARCH_COUNT; i++)
	{
		if(!libusb_LibUsb_GetChipID(devh, libusb_g_AsicArchInfo[i].libusb_asicIdAddr, &chipId))
			return ret;
		switch (chipId)
		{
		case 0x15:
		case 0x16:
		case 0x22:
		case 0x23:
		case 0x25:
		case 0x32:
		case 0x33:
		case 0x56:
		case 0x70:
		case 0x71:
		case 0x75:
		case 0x88:
		case 0x90:
			ret = libusb_DRT_64K;
			dspArchIndex = libusb_DAT_FIRST;
			break;
		case 0x85:
			dspArchIndex = libusb_DAT_SECOND;
			ret = libusb_DRT_128K;
			break;
		case 0x86:
			dspArchIndex = libusb_DAT_SECOND;
			ret = libusb_DRT_256K;
			break;
		case 0x76:
		case 0x83:
		case 0x87:
		case 0x92:
			ret = libusb_DRT_128K;
			dspArchIndex = libusb_DAT_FIRST;
			break;
		case 0x67:
			ret = libusb_DRT_32K;
			dspArchIndex = libusb_DAT_FIRST;
			break;
		default:
			ret = libusb_DRT_Unknow;
			break;
		}
		if (ret != libusb_DRT_Unknow)
		{
			*dspChipID = chipId;
			*dspArchType = dspArchIndex;
			libusb_LibUsb_SetAsicArchInfo(dspArchIndex);
			return ret;
		}
	}
	return ret;
}

libusb_BOOL libusb_LibUsb_EnableAsicRegisterBit(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE bit)
{
	libusb_BYTE bufs;
	libusb_BYTE bufd;
	if (!libusb_LibUsb_ReadFromASIC(devh, addr, &bufs))
		return libusb_FALSE;
	switch (bit)
	{
	case 0:
		bufd = bufs | 0x01;
		break;
	case 1:
		bufd = bufs | 0x02;
		break;
	case 2:
		bufd = bufs | 0x04;
		break;
	case 3:
		bufd = bufs | 0x08;
		break;
	case 4:
		bufd = bufs | 0x10;
		break;
	case 5:
		bufd = bufs | 0x20;
		break;
	case 6:
		bufd = bufs | 0x40;
		break;
	case 7:
		bufd = bufs | 0x80;
		break;
	default:
		break;
	}
    return libusb_LibUsb_WriteToASIC(devh, addr, bufd);
}

libusb_BOOL libusb_LibUsb_DisableAsicRegisterBit(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE bit)
{
libusb_BYTE bufs;
	libusb_BYTE bufd;

	if (!libusb_LibUsb_ReadFromASIC(devh, addr, &bufs))
		return libusb_FALSE;
	switch (bit)
	{
	case 0:
		bufd = bufs & 0xfe;
		break;
	case 1:
		bufd = bufs & 0xfd;
		break;
	case 2:
		bufd = bufs & 0xfb;
		break;
	case 3:
		bufd = bufs & 0xf7;
		break;
	case 4:
		bufd = bufs & 0xef;
		break;
	case 5:
		bufd = bufs & 0xdf;
		break;
	case 6:
		bufd = bufs & 0xbf;
		break;
	case 7:
		bufd = bufs & 0x7f;
		break;
	default:
		break;
	}
	return libusb_LibUsb_WriteToASIC(devh, addr, bufd);
}

libusb_BOOL libusb_LibUsb_ReadFromASIC(libusb_device_handle *devh, libusb_USHORT addr, libusb_BYTE *pValue)
{
	unsigned char data[0x04];
	int r;
	unsigned int i;
	data[0] = (char)addr;
	data[1] = (char)(addr >> 8);
	data[2] = 00;
	data[3] = 0xff;
	// Dummy Write

	r = libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, libusbASIC_RW, libusb_g_CurDspExtendUnitID, data,
		4, 1000);
	// Read
	r = libusb_control_transfer(devh, libusbCTRL_IN, 0x81, libusbASIC_RW, libusb_g_CurDspExtendUnitID, data,
		4, 1000);

	if (r < 0) {
		fprintf(stderr, "F0 error %d\n", r);
		return libusb_FALSE;
	}

	*pValue = data[2];

    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_WriteToASIC(libusb_device_handle *devh, libusb_USHORT addr, libusb_BYTE value)
{
	int r;
	unsigned char data[0x04];
	int i=0;

	data[0] = (char)addr;
	data[1] = (char)(addr >> 8);
	data[2] = value;
	data[3] = 0x00;		
	r = libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, libusbASIC_RW, libusb_g_CurDspExtendUnitID, data,
		4, 1000);
	if (r < 0) {
		fprintf(stderr, "F1 error %d\n", r);
		return libusb_FALSE;
	}
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_ReadFromROM(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE data[])
{
	int r;
	libusb_BYTE temp[0x0b];
	int i=0;

	temp[0] = (char)addr;
	temp[1] = (char)(addr >> 8);
	temp[2] = 0x8;


	// Dummy Write
	r = libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, libusbROM_RW, libusb_g_CurDspExtendUnitID, temp,
		11, 1000);
	// Read
	r = libusb_control_transfer(devh, libusbCTRL_IN, 0x81, libusbROM_RW, libusb_g_CurDspExtendUnitID, temp,
		11, 1000);

	if (r < 0) {
		fprintf(stderr, "F2 error %d\n", r);
		return libusb_FALSE;
	}

	memcpy(data, temp + 3, 8);
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_ReadFromSensor(libusb_BYTE slaveID, libusb_USHORT addr, libusb_BYTE pData[], libusb_LONG len)
{
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_WriteToSensor(libusb_BYTE slaveID, libusb_USHORT addr, libusb_BYTE pData[], libusb_LONG len)
{
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_CustomReadFromSensor(libusb_device_handle *devh, libusb_BYTE slaveID, libusb_USHORT addr, libusb_USHORT addrByteNum, libusb_USHORT *pData, libusb_LONG dataByteNum, libusb_sonixbool pollSCL)
{
	if (dataByteNum == 0)
		return libusb_FALSE;

	if (addrByteNum > 2) addrByteNum = 2;
	if (dataByteNum > 2) dataByteNum = 2;

	// IIC dummy write
	libusb_USHORT dataBuffer = 0;
	if (!libusb_LibUsb_CustomWriteToSensor(devh, slaveID, addr, addrByteNum, dataBuffer, 0, pollSCL))
		return libusb_FALSE;

	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cMode, 0x01))
		return libusb_FALSE;
	libusb_BYTE status;
	if (pollSCL)
	{
		libusb_LibUsb_ReadFromASIC(devh, libusb_i2cMode, &status);
		libusb_LibUsb_WriteToASIC(devh, libusb_i2cMode, status | 0x03);
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cSclSelOD, 0x01))	// SCL_SEL_OD=0
		return libusb_FALSE;
	libusb_BYTE I2C_Speed = 0;
	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDev, &I2C_Speed))
		return libusb_FALSE;
	if (I2C_Speed & 0x01){
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDev, 0x83 | (dataByteNum << 4)))	// I2C_DEV=1, I2C_SEL_RD=1(R)
			return libusb_FALSE;
	}
	else{
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDev, 0x82 | (dataByteNum << 4)))	// I2C_DEV=1, I2C_SEL_RD=1(R)
			return libusb_FALSE;
	}

	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cSlaveID, slaveID))
		return libusb_FALSE;
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDataArrStartAddr, 0x00))
		return libusb_FALSE;
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDataArrStartAddr + 1, 0x00))
		return libusb_FALSE;
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDataArrStartAddr + 2, 0x00))
		return libusb_FALSE;
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDataArrStartAddr + 3, 0x00))
		return libusb_FALSE;
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDataArrStartAddr + 4, 0x00))
		return libusb_FALSE;
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cTrg, 0x10))	// libusbI2C_RW_TRG=1
		return libusb_FALSE;
	// wait I2C ready (time-out 10ms)
	libusb_BYTE value = 0x00;
	int i;
	for (i = 0; (i < 10) && !(value & 0x04); ++i)
	{
		if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDev, &value))
			return libusb_FALSE;
		usleep(1000);
	}
	if ((value & 0x0C) != 0x04){
		return libusb_FALSE;
	}

	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDataArrStartAddr, &value))
		return libusb_FALSE;
	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDataArrStartAddr + 1, &value))
		return libusb_FALSE;
	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDataArrStartAddr + 2, &value))
		return libusb_FALSE;
	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDataArrStartAddr + 3, &value))
		return libusb_FALSE;
	if (dataByteNum == 2)
		*pData = (libusb_USHORT)value << 8;
	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDataArrStartAddr + 4, &value))
		return libusb_FALSE;
	if (dataByteNum == 2)
		*pData |= value;
	else if (dataByteNum == 1)
		*pData = value;

    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_CustomWriteToSensor(libusb_device_handle *devh, libusb_BYTE slaveID, libusb_USHORT addr, libusb_USHORT addrByteNum, libusb_USHORT data, libusb_LONG dataByteNum, libusb_sonixbool pollSCL)
{
	libusb_USHORT i2c_data_addr;
	libusb_BYTE status;

	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cMode, 0x01))
		return libusb_FALSE;
	if (pollSCL)
	{
		libusb_LibUsb_ReadFromASIC(devh, libusb_i2cMode, &status);
		libusb_LibUsb_WriteToASIC(devh, libusb_i2cMode, status | 0x03);
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cSclSelOD, 0x01))
		return libusb_FALSE;
	libusb_BYTE I2C_Speed = 0;
	if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDev, &I2C_Speed))
		return libusb_FALSE;
	if (I2C_Speed & 0x01){
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDev, 0x81 | ((addrByteNum + dataByteNum) << 4)))	// I2C_DEV=1, I2C_SEL_RD=0(W)
			return libusb_FALSE;
	}
	else{
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cDev, 0x80 | ((addrByteNum + dataByteNum) << 4)))	// I2C_DEV=1, I2C_SEL_RD=0(W)
			return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cSlaveID, slaveID))
		return libusb_FALSE;

	//write addr
	i2c_data_addr = libusb_i2cDataArrStartAddr;
	if (addrByteNum > 1){
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, (libusb_BYTE)(addr >> 8)))
			return libusb_FALSE;
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, (libusb_BYTE)addr))
			return libusb_FALSE;
	}
	else{
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, (libusb_BYTE)addr))
			return libusb_FALSE;
	}


	// write data
	if (dataByteNum > 1)
	{
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, (libusb_BYTE)(data >> 8)))
			return libusb_FALSE;
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, (libusb_BYTE)data))
			return libusb_FALSE;
	}
	else{
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, (libusb_BYTE)data))
			return libusb_FALSE;
	}

	while (i2c_data_addr < (libusb_i2cDataArrStartAddr + 5)){
		if (!libusb_LibUsb_WriteToASIC(devh, i2c_data_addr++, 0x00))
			return libusb_FALSE;
	}


	//trigger to start i2c interface read/write
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_i2cTrg, 0x10))
		return libusb_FALSE;

	// wait I2C ready (time-out 10ms)
	libusb_BYTE value = 0x00;
	int i;
	for (i = 0; (i < 10) && !(value & 0x04); ++i)
	{
		if (!libusb_LibUsb_ReadFromASIC(devh, libusb_i2cDev, &value))
			return libusb_FALSE;
		usleep(1000);
	}

	if ((value & 0x0C) == 0x04)
		return libusb_TRUE;
	else
		return libusb_FALSE;
}

libusb_SERIAL_FLASH_TYPE LibUsb_SerialFlashSearch()
{
	libusb_BYTE i, ubID_Num;
	libusb_BYTE ubSFType = libusb_SF_UNKNOW;
	ubID_Num = libusb_ubSFLib_GetIDSize();
	for (i = 1; i<ubID_Num; i++)
	{
		if (libusb_cbSFLib_ID[i][libusb_SFCMD_INFO_MFR] == libusb_sfManufactureID &&
			(libusb_cbSFLib_ID[i][libusb_SFCMD_INFO_DEVID1] == libusb_sfDeviceID1 || libusb_cbSFLib_ID[i][libusb_SFCMD_INFO_DEVID1] == 0xFF) &&
			(libusb_cbSFLib_ID[i][libusb_SFCMD_INFO_DEVID2] == libusb_sfDeviceID2 || libusb_cbSFLib_ID[i][libusb_SFCMD_INFO_DEVID2] == 0xFF))
		{
			break;
		}
	}
	if (i == ubID_Num)
		i = 0;
	ubSFType = libusb_cbSFLib_ID[i][libusb_SFCMD_INFO_TYPE];
	return (libusb_SERIAL_FLASH_TYPE)ubSFType;
}


libusb_BOOL LibUsb_ReadBitFormAsic(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE bit)
{
	libusb_BYTE bufs;
	libusb_BYTE data;
	libusb_LibUsb_ReadFromASIC(devh, addr, &bufs);

	switch (bit)
	{
	case 0:
		data = bufs & 0x01;
		break;
	case 1:
		data = bufs & 0x02;
		break;
	case 2:
		data = bufs & 0x04;
		break;
	case 3:
		data = bufs & 0x08;
		break;
	case 4:
		data = bufs & 0x10;
		break;
	case 5:
		data = bufs & 0x20;
		break;
	case 6:
		data = bufs & 0x40;
		break;
	case 7:
		data = bufs & 0x80;
		break;
	default:
		break;
	}
	return data;
}


libusb_BOOL libusb_LibUsb_SFWaitReady(libusb_device_handle *devh)
{
	libusb_BYTE i;
	libusb_LONG data = 0;
	for (i = 0; i < 50; i++)										//pooling ready; 500us timeout
	{
		if (LibUsb_ReadBitFormAsic(devh, libusb_sfRdyAddr, 0))                      //aISP_RDY
		{
			return libusb_TRUE;
		}
		usleep(1000);
	}
	return libusb_FALSE;
}

libusb_BOOL libusb_LibUsb_SFCMDreadStatus(libusb_device_handle *devh)
{
	int i;
	unsigned char ucData;
	for (i = 0; i < 10000; ++i){
		// chip select to low
		if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0)){
			return libusb_FALSE;
		}
		// Read status cmd
		if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x05)){
			return libusb_FALSE;
		}
		// Write trig
		if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01)){
			return libusb_FALSE;
		}
		if (libusb_TRUE != libusb_LibUsb_SFWaitReady(devh)){
			return libusb_FALSE;
		}
		// Read reg cmd 
		if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, libusb_sfReadDataAddr, 0x0)){
			return libusb_FALSE;;
		}
		// 2: Trigger for read data to Serial Flash in SF_MODE
		if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x02)){
			return libusb_FALSE;
		}
		if (libusb_TRUE != libusb_LibUsb_SFWaitReady(devh)){
			return libusb_FALSE;
		}
		// Data read from Serial Flash
		if (libusb_TRUE != libusb_LibUsb_ReadFromASIC(devh, libusb_sfReadDataAddr, &ucData)){
			return libusb_FALSE;
		}
		// chip select to high
		if ((ucData & 0x01) != 0x01){
			if (libusb_TRUE != libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1)){
				return libusb_FALSE;
			}
			return libusb_TRUE;
		}
		usleep(1000);
	}
	return libusb_FALSE;
}


void LibUsb_ReadSFID(libusb_device_handle *devh, libusb_BYTE cmd, libusb_BYTE dummyNum, libusb_BYTE devIdNum)
{
	libusb_LONG data;
	data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, 0x1080, data);
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, 0x1091, data);
	data = cmd;
	libusb_LibUsb_WriteToASIC(devh, 0x1082, data);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, 0x1081, data);
	libusb_LibUsb_SFWaitReady(devh);

	while (dummyNum > 0)
	{
		data = 0x00;
		libusb_LibUsb_WriteToASIC(devh, 0x1082, data);
		data = 0x01;
		libusb_LibUsb_WriteToASIC(devh, 0x1081, data);
		libusb_LibUsb_SFWaitReady(devh);
		dummyNum--;
	}

	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, 0x1083, data);
	data = 0x02;
	libusb_LibUsb_WriteToASIC(devh, 0x1081, data);
	libusb_LibUsb_SFWaitReady(devh);
	libusb_LibUsb_ReadFromASIC(devh, 0x1083, &libusb_sfManufactureID);
	if (libusb_sfManufactureID == libusb_SF_MFRID_CONT)
	{
		data = 0x0;
		libusb_LibUsb_WriteToASIC(devh, 0x1083, data);
		data = 0x02;
		libusb_LibUsb_WriteToASIC(devh, 0x1081, data);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_ReadFromASIC(devh, 0x1083, &libusb_sfManufactureID);
	}

	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, 0x1083, data);
	data = 0x02;
	libusb_LibUsb_WriteToASIC(devh, 0x1081, data);
	libusb_LibUsb_SFWaitReady(devh);
	libusb_LibUsb_ReadFromASIC(devh, 0x1083, &libusb_sfDeviceID1);
	if (devIdNum == 2)
	{
		data = 0x0;
		libusb_LibUsb_WriteToASIC(devh, 0x1083, data);
		data = 0x02;
		libusb_LibUsb_WriteToASIC(devh, 0x1081, data);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_ReadFromASIC(devh, 0x1083, &libusb_sfDeviceID2);
	}
	else
		libusb_sfDeviceID2 = 0xFF;

	data = 0x00;
	libusb_LibUsb_WriteToASIC(devh, 0x1080, data);
}

libusb_SERIAL_FLASH_TYPE LibUsb_SerialFlashIdentify(libusb_device_handle *devh)
{
	// MXIC-like series
	LibUsb_ReadSFID(devh, libusb_SFCMD_RDID_MXIC, 0, 2);
	libusb_SERIAL_FLASH_TYPE sfType = LibUsb_SerialFlashSearch();
	if (sfType != libusb_SF_UNKNOW)
		goto sfIndetifyExit;

	// Atmel AT25F series
	LibUsb_ReadSFID(devh, libusb_SFCMD_RDID_AT25F, 0, 1);
	sfType = LibUsb_SerialFlashSearch();
	if (sfType != libusb_SF_UNKNOW)
		goto sfIndetifyExit;

	// SST/Winbond/Other MXIC-like
	LibUsb_ReadSFID(devh, libusb_SFCMD_REMS_SST, 3, 1);
	sfType = LibUsb_SerialFlashSearch();
	if (sfType != libusb_SF_UNKNOW)
		goto sfIndetifyExit;
	
	// ST/PMC
	LibUsb_ReadSFID(devh, libusb_SFCMD_RES_ST, 3, 1);
	sfType = LibUsb_SerialFlashSearch();
	if (sfType != libusb_SF_UNKNOW)
		goto sfIndetifyExit;
	
sfIndetifyExit:
	return sfType;
}

libusb_BOOL libusb_LibUsb_GetSerialFlashType(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE *sft, libusb_sonixbool check)
{
	*sft = LibUsb_SerialFlashIdentify(devh);
	libusb_BYTE sfType = 0;
	if(check){
		if(*sft == libusb_SFT_UNKNOW){
			libusb_BYTE romVersion[8] = { 0 };
			if (!libusb_LibUsb_GetAsicRomVersion(devh, romVersion)){
				return libusb_FALSE;
			}
			libusb_BYTE chipID = 0;
			libusb_DSP_ARCH_TYPE archType = libusb_DAT_UNKNOW;
			if(libusb_DRT_Unknow == libusb_LibUsb_GetChipRomType(devh, &chipID, &archType)){
				return libusb_FALSE;
			}
			if (!libusb_LibUsb_ReadFromASIC(devh, libusb_RomInfo[libusb_uiRomID].SFTypeAddr, &sfType))
				return libusb_FALSE;
			if (sfType <= libusb_SFT_FENTECH)
				*sft = (libusb_SERIAL_FLASH_TYPE)sfType;
			else
				return libusb_FALSE;
		}
	}

    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_ReadFormSF(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_LONG len)
{
	libusb_BOOL addr128k = libusb_FALSE;
	libusb_BYTE tempData[8];
	libusb_BYTE AddressLow, AddressHigh;
	libusb_LONG startAddr = addr;
	libusb_LONG loop = len / 8;
	libusb_LONG ram = len % 8;
	libusb_BOOL hr = libusb_TRUE;
	startAddr = addr;
	libusb_LONG addrIndex = 0;
	libusb_LONG i = 0;
	for (i= 0; i < loop; i++){
		memset(&tempData, 0xff, 8);
		hr = libusb_LibUsb_ReadDataFormFlash(devh, startAddr, tempData, 8);
		if (libusb_TRUE != hr){
			return hr;
		}
		memcpy(pData + addrIndex, tempData, 8);
		addrIndex += 8;
		startAddr += 8;
	}

	if (ram > 0){
		memset(&tempData, 0xff, 8);
		hr = libusb_LibUsb_ReadDataFormFlash(devh, startAddr, tempData, ram);
		if (libusb_TRUE != hr){
			return hr;
		}
		memcpy(pData + addrIndex, tempData, ram);
	}
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_WriteToSF(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_LONG len, libusb_SERIAL_FLASH_TYPE sft)
{
	if (sft == libusb_SFT_UNKNOW)
	{
		gEC = libusb_EC_UnKnowSerialFlashType;
		return libusb_FALSE;
	}
	//disable serial flash wirte protect
	libusb_BOOL hr = libusb_LibUsb_DisableSerialFlashWriteProtect(devh, sft);
	if (libusb_TRUE != hr)
		return hr;

	//erase serial flash sector 
	hr = libusb_LibUsb_EraseSectorForSerialFlash(devh, addr, sft);
	if (libusb_TRUE != hr)
	{
		return hr;
	}
	sleep(1);

	//write data to serial flash
	libusb_LONG startAddr = addr;
	libusb_LONG loop = len / 8;
	libusb_LONG ram = len % 8;
	libusb_BYTE tempData[8];
	libusb_BOOL addr128k = libusb_FALSE;
	libusb_BYTE addrHigh;
	libusb_BYTE addrLow;
	libusb_LONG i = 0;
	for (i = 0; i < loop; i++)
	{
		memcpy(tempData, pData + i * 8, 8);
		hr = libusb_LibUsb_WriteDataToFlash(devh, startAddr, tempData, 8);
		if (!hr)
			return hr;
		startAddr += 8;
		
	}

	if (ram > 0)
	{
		memset(&tempData, 0xFF, 8);
		memcpy(tempData, pData + (loop * 8), ram);
		hr = libusb_LibUsb_WriteDataToFlash(devh, startAddr, tempData, ram);
		if (libusb_TRUE != hr){
			return hr;
		}
	}
	return hr;
}


libusb_BOOL libusb_LibUsb_ReadDataFormFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_BYTE dataLen)
{
  	unsigned char data[11];
	if (dataLen > 8)
		dataLen = 8;

	data[1] = (libusb_BYTE)(addr >> 8);
	data[0] = (libusb_BYTE)((addr << 8) >> 8);

	if (addr < 0x10000)
		data[2] = 0x88;
	else if (addr < 0x20000)
		data[2] = 0x98;
	else if (addr < 0x30000)
		data[2] = 0xA8;
	else
		data[2] = 0xB8;
	data[2] &= 0xF0;
	data[2] |= dataLen;

	int r = libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, libusbFLASH_RW, libusb_g_CurDspExtendUnitID, data,
		11, 1000);

	// Read
	r = libusb_control_transfer(devh, libusbCTRL_IN, 0x81, libusbFLASH_RW, libusb_g_CurDspExtendUnitID, data,
		11, 1000);
	if (r < 0) {
		fprintf(stderr, "F3 error %d\n", r);
		return 0;
	}

	memcpy(pData, data + 3, dataLen);
	
	return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_WriteDataToFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_BYTE pData[], libusb_BYTE dataLen)
{
	unsigned char data[11];
	if(dataLen > 8)
		dataLen = 8;

	data[1] = (libusb_BYTE)(addr >> 8);
	data[0] = (libusb_BYTE)((addr << 8) >> 8);

	if (addr < 0x10000)
		data[2] = 0x08;
	else if (addr < 0x20000)
		data[2] = 0x18;
	else if (addr < 0x30000)
		data[2] = 0x28;
	else
		data[2]= 0x38;
	data[2] &= 0xf0;
	data[2] |= dataLen;

	memcpy(data + 3, pData, dataLen);
	int r = libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, libusbFLASH_RW, libusb_g_CurDspExtendUnitID, data,
		11, 1000);
	if (r < 0) {
		fprintf(stderr, "F4 error %d\n", r);
		return 0;
	}
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_DisableSerialFlashWriteProtect(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft)
{
	if (sft == libusb_SFT_UNKNOW)
	{
		gEC = libusb_EC_UnKnowSerialFlashType;
		return libusb_FALSE;
	}

	libusb_BYTE romVersion[8] = { 0 };
	if (libusb_TRUE != libusb_LibUsb_GetAsicRomVersion(devh, romVersion))
	{
		gEC = libusb_EC_GetAsicRomTypeFail;
		return libusb_FALSE;
	}
	
	libusb_BYTE chipID;
	libusb_DSP_ARCH_TYPE dspArchType;
	libusb_DSP_ROM_TYPE drt = libusb_LibUsb_GetChipRomType(devh, &chipID, &dspArchType);
	if (libusb_DRT_Unknow == drt)
	{
		gEC = libusb_EC_GetAsicRomTypeFail;
		return libusb_FALSE;
	}

	//setp 1 : disable hardware wirete protect
	libusb_BYTE data[2] = { 0 };
	if (drt == libusb_DRT_64K)
	{
		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOEAddr, &data[1]);
		data[1] = data[1] | 0x1F;
		libusb_LibUsb_WriteToASIC(devh, libusb_gpioOEAddr, data[1]);
		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOEAddr, &data[1]);

		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOutputAddr, &data[0]);
		data[0] = data[0] | 0x1F;
		libusb_LibUsb_WriteToASIC(devh, libusb_gpioOutputAddr, data[0]);
		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOutputAddr, &data[0]);
	}
	else
	{
		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOEAddr, &data[1]);
		data[1] = data[1] | 0xFF;
		libusb_LibUsb_WriteToASIC(devh, libusb_gpioOEAddr, data[1]);
		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOEAddr, &data[1]);

		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOutputAddr, &data[0]);
		data[0] = data[0] | 0xFF;
		libusb_LibUsb_WriteToASIC(devh, libusb_gpioOutputAddr, data[0]);
		libusb_LibUsb_ReadFromASIC(devh, libusb_gpioOutputAddr, &data[0]);
	}

	libusb_BYTE wpData = 0;
	switch (chipID)
	{
	case 0x16:
		libusb_LibUsb_ReadFormSF(devh, 0x5834, &wpData, 1);
		break;
	case 0x33:
		libusb_LibUsb_ReadFormSF(devh, 0x000f, &wpData, 1);
		break;
	default:
		wpData = 0xFF;
		break;
	}
	

	libusb_BYTE byTmpAddr = 0;
	libusb_BYTE byMemType = 0;
	libusb_BYTE wpGPIO = 0;
	libusb_BOOL isNewWPVer = libusb_FALSE;
	libusb_USHORT wpAddr = 0xFFFF;
	libusb_BYTE sfWriteEnable = 0;
	libusb_BYTE sfWriteCommand = 0;

	if (libusb_RomInfo[libusb_uiRomID].IsCompactMode)	// shawn 2010/05/14 modify
	{
		libusb_LibUsb_GetMemType(devh, &byMemType);
	}

	wpGPIO = (wpData >> 4) & 0x7;
	if ((libusb_uiRomID != libusb_ROM283) && (libusb_uiRomID != libusb_ROM292) && (libusb_uiRomID != libusb_ROM275V2) && (libusb_uiRomID != libusb_ROM287)){
		if ((wpData & 0x0C) == 0x08){
			isNewWPVer = libusb_TRUE;
		}
	}
	if (isNewWPVer){
		if ((wpData & 0x03) == 0x02){
			wpData = 1;
		}
		else if ((wpData & 0x03) == 0x03){
			wpData = 2;
		}
	}
	else{
		wpData = wpData & 0x03;
	}
	if (libusb_RomInfo[libusb_uiRomID].IsDisSFWriteCmd)
	{
		if (!libusb_LibUsb_ReadFromASIC(devh, 0x05F3, &sfWriteEnable)){
			return libusb_FALSE;
		}
		if (isNewWPVer)
		{
			if (!libusb_LibUsb_WriteToASIC(devh, 0x05F3, libusb_cbSFLib_Cmd[libusb_ubSFLib_CmdID][libusb_SFCMD_IDX_WREN]))	// SF write enable
				return libusb_FALSE;
		}
		else
		{
			if (!libusb_LibUsb_WriteToASIC(devh, 0x05F3, 0x06))	// SF write enable(ubSFWREN)
				return libusb_FALSE;
		}
		//// SF write enable(ubSFWREN)
		//if (!libusb_LibUsb_WriteToASIC(0x05F3, 0x06)){
		//	return libusb_FALSE;
		//}
		// Memkey1 low
		if (!libusb_LibUsb_WriteToASIC(devh, 0x05F8, 0x12))	{
			return libusb_FALSE;
		}
		// MemKey1 high
		if (!libusb_LibUsb_WriteToASIC(devh, 0x05F9, 0x12))	{
			return libusb_FALSE;
		}
		//memkey2 low
		if (!libusb_LibUsb_WriteToASIC(devh, 0x05FA, 0xED))  {
			return libusb_FALSE;
		}
		//memkey2 high
		if (!libusb_LibUsb_WriteToASIC(devh, 0x05FB, 0xED))  {
			return libusb_FALSE;
		}
		//ubsfwrite
		if (!libusb_LibUsb_ReadFromASIC(devh, 0x05F5, &sfWriteCommand))  {
			return libusb_FALSE;
		}
		if (isNewWPVer){
			//SF write command
			if (!libusb_LibUsb_WriteToASIC(devh, 0x05F5, libusb_cbSFLib_Cmd[libusb_ubSFLib_CmdID][libusb_SFCMD_IDX_PP])){
				return libusb_FALSE;
			}
		}
		else{
			if (sft == libusb_SFT_SST){
				//SF write command for SST
				if (!libusb_LibUsb_WriteToASIC(devh, 0x05F5, 0xAF)){
					return libusb_FALSE;
				}
			}
			else{
				if (!libusb_LibUsb_WriteToASIC(devh, 0x05F5, 0x02)){
					return libusb_FALSE;
				}
			}
		}
	}

	if (libusb_RomInfo[libusb_uiRomID].IsCompactMode && byMemType == 2){
		return libusb_TRUE;
	}
	//disable write protect @ flash status register (bp0, bp1)
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x06)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_SFWaitReady(devh)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_SFCMDreadStatus(devh)){
		return libusb_FALSE;
	}
	if (sft == libusb_SFT_SST)
	{
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0)){
			return libusb_FALSE;
		}
		// Enable-Write-Status-Register(EWSR)
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x50)){
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x1)){
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_SFWaitReady(devh)){
			return libusb_FALSE;
		}
		if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1)){
			return libusb_FALSE;
		}
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_SFWaitReady(devh)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x0)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_SFWaitReady(devh)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_SFCMDreadStatus(devh)){
		return libusb_FALSE;
	}
	if (!libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x0)){
		return libusb_FALSE;
	}

    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_EraseSectorForSerialFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_SERIAL_FLASH_TYPE sft)
{
		// disable serial falsh write protect
	libusb_BYTE sectorEraseCode = 0x20;
	switch (sft)
	{
	case libusb_SFT_ST:
		sectorEraseCode = 0xd8;
		break;
	case libusb_SFT_SST:
	case libusb_SFT_MXIC:
	case libusb_SFT_GIGA:
	case libusb_SFT_WINBOND:
	case libusb_SFT_MXIC_LIKE:
	case libusb_SFT_ATMEL_AT25F:
	case libusb_SFT_ATMEL_AT25FS:
	case libusb_SFT_ATMEL_AT45DB:
	case libusb_SFT_AMIC:
	case libusb_SFT_EON:
	case libusb_SFT_FENTECH:
		sectorEraseCode = 0x20;
		break;
	case libusb_SFT_PMC:
		sectorEraseCode = 0xd7;
		break;
	case libusb_SFT_UNKNOW:
		return libusb_FALSE;
		break;
	default:
		break;
	}

	libusb_BYTE data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, data);//flash mode
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=0
	data = 0x06;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//WREN
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=1
	//sector erase
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=0
	data = sectorEraseCode;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);	// for chip sector erase
	//SetRegData(0x1082,0x20);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	//ldata = 0x00;
	data = addr >> 16;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//addr
	//SetRegData(0x1082,0x00);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = addr >> 8;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
	//SetRegData(0x1082,SectorNum);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = (libusb_BYTE)addr;//ldata = 0x00;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
	//SetRegData(0x1082,0x00);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=1
	//SF_CMDread_Status
	libusb_LibUsb_SFWaitReady(devh);//SF_CMDread_Status(iDevIndex);
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, data);//flash mode disable
	return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_EraseBlockForSerialFlash(libusb_device_handle *devh, libusb_LONG addr, libusb_SERIAL_FLASH_TYPE sft)
{
// disable serial falsh write protect
	libusb_BYTE sectorEraseCode = 0x52;
	switch (sft)
	{
	case libusb_SFT_ST:
	case libusb_SFT_GIGA:
	case libusb_SFT_FENTECH:
		sectorEraseCode = 0xd8;
		break;
	case libusb_SFT_SST:
	case libusb_SFT_MXIC:
	case libusb_SFT_WINBOND:
	case libusb_SFT_MXIC_LIKE:
	case libusb_SFT_ATMEL_AT25F:
	case libusb_SFT_ATMEL_AT25FS:
	case libusb_SFT_ATMEL_AT45DB:
	case libusb_SFT_AMIC:
	case libusb_SFT_EON:
		sectorEraseCode = 0x52;
		break;
	case libusb_SFT_PMC:
		sectorEraseCode = 0x52;
		break;
	case libusb_SFT_UNKNOW:
		return libusb_FALSE;
		break;
	default:
		break;
	}

	libusb_BYTE data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, data);//flash mode
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=0
	data = 0x06;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//WREN
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=1
	//sector erase
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=0
	data = sectorEraseCode;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);	// for chip sector erase
	//SetRegData(0x1082,0x20);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	//ldata = 0x00;
	data = addr >> 16;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);//addr
	//SetRegData(0x1082,0x00);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = addr >> 8;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
	//SetRegData(0x1082,SectorNum);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = (libusb_BYTE)addr;//ldata = 0x00;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, data);
	//SetRegData(0x1082,0x00);
	data = 0x01;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, data);
	libusb_LibUsb_SFWaitReady(devh);
	data = 0x1;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, data);//CS=1
	//SF_CMDread_Status
	libusb_LibUsb_SFWaitReady(devh);//SF_CMDread_Status(iDevIndex);
	data = 0x0;
	libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, data);//flash mode disable
	return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_SerialFlashErase(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft)
{
	libusb_BOOL ret = libusb_TRUE;
	switch (sft){
	case libusb_SF_WINBOND:
	case libusb_SF_PMC:
	case libusb_SF_ST:
	case libusb_SF_AMIC:
		libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x1);
		//SF_Set_WEL_Bit
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x06);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//chip erase
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0xc7);	// for PMC chip erase
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		libusb_LibUsb_SFCMDreadStatus(devh);
		ret = libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x0);
		break;
	case libusb_SF_SST:
		libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x1);	// serial flash mode
		//SF_Set_EWSR_Bit
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);	// chip select
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x50);	// write data
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);	// trigger for write
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//SF_Set_WRSR_Bit
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);	// chip select
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x01);	// write data
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);	// trigger for write
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x00);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);	// trigger for write
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//SF_Set_WEL_Bit
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);	// chip select
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x06);	// write data
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);	// trigger for write
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//chip erase
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x60);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//SF_CMDread_Status
		libusb_LibUsb_SFCMDreadStatus(devh);
		ret = libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x0);
		break;
	case libusb_SF_UNKNOW:
	case libusb_SF_MXIC:
	case libusb_SF_ATMEL_AT25FS:
	case libusb_SF_MXIC_LIKE:
	case libusb_SF_FENTECH:
	default:
		libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x1);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);//CS#
		//SF_Set_WEL_Bit
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x06);//write enable cmd
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);
		libusb_LibUsb_SFWaitReady(devh);
		//disable BP0 BP1
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//chip erase
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x0);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfWriteDataAddr, 0x60);//chip erase cmd
		//SetRegData(0x1082,0xc7);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfReadWriteTriggerAddr, 0x01);
		libusb_LibUsb_SFWaitReady(devh);
		libusb_LibUsb_WriteToASIC(devh, libusb_sfCSAddr, 0x1);
		//SF_CMDread_Status
		libusb_LibUsb_SFCMDreadStatus(devh);
		ret = libusb_LibUsb_WriteToASIC(devh, libusb_sfModeAddr, 0x0);
		break;
	}
    return libusb_TRUE;
}


libusb_BOOL libusb_LibUsb_DefGetAsicRomVersion(libusb_device_handle *devh, libusb_BYTE romVersion[])
{
	libusb_BYTE romString[8];
	memset(romString, 0, 8);
	int i = 0, j = 0;
	for (i = 0; i < libusb_ROMSTRADDRCNT; i++)
	{
		libusb_LibUsb_ReadFromROM(devh, libusb_RomStringAddr[i], romString);

		for (j = 0; j < libusb_ROMCOUNT; j++)
		{
			if (libusb_RomInfo[j].libusb_RomStringAddr == libusb_RomStringAddr[i])
			{
				if (libusb_RomInfo[j].IsNewestVer)
				{
					if (memcmp(romString, libusb_RomInfo[j].RomString, 4) == 0 &&
						romString[5] >= libusb_RomInfo[j].RomString[5])
					{
						memcpy(romVersion, romString, 8);
						libusb_uiRomID = j;	// shawn 2010/05/14 add
						return libusb_TRUE;
					}
				}
				else
				{
					if (memcmp(romString, libusb_RomInfo[j].RomString, 4) == 0 &&	// shawn 2009/06/10 modify
						romString[5] == libusb_RomInfo[j].RomString[5])				// shawn 2010/04/12 only compare 6 bytes
					{
						memcpy(romVersion, romString, 8);
						libusb_uiRomID = j;	// shawn 2010/05/14 add
						return libusb_TRUE;
					}
				}
			}

		}
	}
	romVersion = 0;
	return libusb_FALSE;
}

libusb_BOOL libusb_LibUsb_GetAsicRomVersion(libusb_device_handle *devh, libusb_BYTE romVersion[])
{
	if (libusb_TRUE == libusb_LibUsb_DefGetAsicRomVersion(devh, romVersion)){
		if (libusb_uiRomID == libusb_ROM266V1){
			libusb_BYTE byTmp1 = 0;
			libusb_BYTE byTmp2 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1185, &byTmp1);
			byTmp1 |= 0x70;
			libusb_LibUsb_WriteToASIC(devh, 0x1185, byTmp1);
			libusb_LibUsb_ReadFromASIC(devh, 0x1185, &byTmp2);
			if ((byTmp2 & 0x70) == (byTmp1 & 0x70)){
				romVersion[4] = 0x31;
			}
		}
		if (libusb_uiRomID == libusb_ROM288V1){
			libusb_BYTE byTmp1 = 0;
			libusb_BYTE byTmp2 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x101f, &byTmp1);
			if (byTmp1 == 0x89){
				romVersion[2] = 0x39;
				libusb_uiRomID = libusb_ROM289V1;
			}
			else{
				byTmp1 = 0;
				libusb_LibUsb_ReadFromASIC(devh, 0x1007, &byTmp1);
				byTmp1 &= 0xDF;
				libusb_LibUsb_ReadFromASIC(devh, 0x1006, &byTmp2);
				byTmp2 |= 0x20;
				libusb_LibUsb_WriteToASIC(devh, 0x1007, byTmp1);
				libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
				byTmp1 = 0;
				libusb_LibUsb_ReadFromASIC(devh, 0x1005, &byTmp1);
				if ((byTmp1 & 0x20) == 0x20){
					romVersion[4] = 0x31;
				}
				else{
					byTmp2 &= 0xDF;
					libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
				}
			}
		}
		if (libusb_uiRomID == libusb_ROM271V1){
			libusb_BYTE byTmp1 = 0;
			libusb_BYTE byTmp2 = 0;
			libusb_BYTE byTmp3 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x100A, &byTmp1);
			byTmp2 = (byTmp1 & 0x10);
			byTmp1 &= 0xEF;
			libusb_LibUsb_WriteToASIC(devh, 0x100A, byTmp1);
			libusb_LibUsb_ReadFromASIC(devh, 0x101F, &byTmp3);
			byTmp1 |= byTmp2;
			libusb_LibUsb_WriteToASIC(devh, 0x100A, byTmp1);
			if (byTmp3 == 0x70){
				romVersion[2] = 0x30;
				libusb_uiRomID = libusb_ROM270V1;
			}
			byTmp1 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1007, &byTmp1);
			byTmp1 &= 0xF7;
			byTmp2 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1006, &byTmp2);
			byTmp2 |= 0x08;
			libusb_LibUsb_WriteToASIC(devh, 0x1007, byTmp1);
			libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
			byTmp1 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1005, &byTmp1);
			if ((byTmp1 & 0x08) == 0x08){
				romVersion[4] = 0x31;	// 270M, 271M
				byTmp2 &= 0xF7;
				libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
			}
			else{
				byTmp1 = 0;
				libusb_LibUsb_ReadFromASIC(devh, 0x1007, &byTmp1);
				byTmp1 &= 0xEF;
				byTmp2 = 0;
				libusb_LibUsb_ReadFromASIC(devh, 0x1006, &byTmp2);
				byTmp2 |= 0x10;
				libusb_LibUsb_WriteToASIC(devh, 0x1007, byTmp1);
				libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
				byTmp1 = 0;
				libusb_LibUsb_ReadFromASIC(devh, 0x1005, &byTmp1);

				if ((byTmp1 & 0x10) == 0x10){
					// 270A, 271A
					romVersion[4] = 0x30;
				}
				else{
					if (libusb_uiRomID == libusb_ROM270V1){
						romVersion[4] = 0x32;	// 270B
						byTmp2 &= 0xEF;
						libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
					}
				}
			}
		}
		if (libusb_uiRomID == libusb_ROM281V1){
			libusb_BYTE byTmp1 = 0;
			libusb_BYTE byTmp2 = 0;
			libusb_BYTE byTmp3 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x100A, &byTmp1);
			byTmp2 = (byTmp1 & 0x10);
			byTmp1 &= 0xEF;
			libusb_LibUsb_WriteToASIC(devh, 0x100A, byTmp1);
			libusb_LibUsb_ReadFromASIC(devh, 0x101F, &byTmp3);
			byTmp1 |= byTmp2;
			libusb_LibUsb_WriteToASIC(devh, 0x100A, byTmp1);
			if (byTmp3 == 0x80){
				romVersion[2] = 0x30;
				libusb_uiRomID = libusb_ROM280V1;
			}
			byTmp1 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1007, &byTmp1);
			byTmp1 &= 0xF7;
			byTmp2 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1006, &byTmp2);
			byTmp2 |= 0x08;
			libusb_LibUsb_WriteToASIC(devh, 0x1007, byTmp1);
			libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
			byTmp1 = 0;
			libusb_LibUsb_ReadFromASIC(devh, 0x1005, &byTmp1);
			if ((byTmp1 & 0x08) == 0x08){
				romVersion[4] = 0x31;	// 280M, 281M
				byTmp2 &= 0xF7;
				libusb_LibUsb_WriteToASIC(devh, 0x1006, byTmp2);
			}
			else{
				romVersion[4] = 0x30;	// 280A, 281A
			}
		}
		return libusb_TRUE;
	}
	romVersion = 0;
	return libusb_FALSE;
}

libusb_BOOL libusb_LibUsb_GetParaTableAndCRCAddrFormFW(libusb_device_handle *devh, libusb_BYTE *pFW, libusb_ULONG* paraTableStartAddr, libusb_ULONG* paraTableEndAddr, libusb_ULONG* crcAddr)
{
	libusb_BYTE romVersion[8] = { 0 };
	if (!libusb_LibUsb_GetAsicRomVersion(devh, romVersion))
		return libusb_FALSE;

	if (memcmp(romVersion, "231R0", 4) == 0 && romVersion[5] >= 2) // 231R0_V2
	{
		return libusb_FALSE;
	}
	else if (((memcmp(romVersion, "232R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "275R0", 4) == 0 && romVersion[5] == 1 && romVersion[6] == 0x30)) ||
		((memcmp(romVersion, "276R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "290R0", 4) == 0 && romVersion[5] == 1)))
	{
		*paraTableStartAddr = 0xC000;
		*paraTableEndAddr = *paraTableStartAddr + 0xF00;
		*crcAddr = *paraTableStartAddr + 0xF00;
	}
	else if (((memcmp(romVersion, "232R0", 4) == 0 && romVersion[5] == 2)) ||
		((memcmp(romVersion, "290R0", 4) == 0 && romVersion[5] == 2)) ||
		((memcmp(romVersion, "288R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "289R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "270R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "271R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "280R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "281R0", 4) == 0 && romVersion[5] == 1)))
	{
		libusb_BYTE sectorTable[32];
		memcpy(sectorTable, pFW + 0x160, sizeof(sectorTable));

		// pbySectorTable[8] is parameter start address for deivce
		// pbySectorTable[9] is parameter size for deivce
		*paraTableStartAddr = (libusb_ULONG)sectorTable[0x08] << 8;
		*paraTableEndAddr = *paraTableStartAddr + ((libusb_ULONG)sectorTable[0x09] << 8);
		*crcAddr = (libusb_ULONG)sectorTable[0xE] << 8;
	}
	else if (((memcmp(romVersion, "272R0", 4) == 0) && (romVersion[5] == 1)) ||
		((memcmp(romVersion, "273R0", 4) == 0) && (romVersion[5] == 1)) ||
		((memcmp(romVersion, "275R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "283R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "285R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "286R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "287R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "267R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "292R0", 4) == 0) && (romVersion[5] == 1)))//wei add 292
	{
		// Get Parameter table start address
		// Parameter table start address is stored at 0x16F 
		libusb_BYTE sectorTable[0x2B];
		memcpy(sectorTable, pFW + 0x160, sizeof(sectorTable));

		*paraTableStartAddr = ((libusb_ULONG)sectorTable[0x0F] << 24) + ((libusb_ULONG)sectorTable[0x10] << 16) + ((libusb_ULONG)sectorTable[0x11] << 8) + sectorTable[0x12];
		libusb_ULONG dwParaTableSize = ((libusb_ULONG)sectorTable[0x13] << 24) + ((libusb_ULONG)sectorTable[0x14] << 16) + ((libusb_ULONG)sectorTable[0x15] << 8) + sectorTable[0x16];
		*paraTableEndAddr = *paraTableStartAddr + dwParaTableSize;
		*crcAddr = ((libusb_ULONG)sectorTable[0x27] << 24) + ((libusb_ULONG)sectorTable[0x28] << 16) + ((libusb_ULONG)sectorTable[0x29] << 8) + sectorTable[0x2a];
	}
	else if ((memcmp(romVersion, "216R0", 4) == 0))
	{
		*paraTableStartAddr = 0x5800;
		*paraTableEndAddr = *paraTableStartAddr + 0xF00;
		*crcAddr = *paraTableStartAddr + 0xF00;
	}
	else
	{
		*paraTableStartAddr = 0x8000;
		*paraTableEndAddr = *paraTableStartAddr + 0x800;
		*crcAddr = 0;
	}
	return libusb_TRUE;
}


libusb_BOOL libusb_LibUsb_GetParaTableAndCRCAddrFormSF(libusb_device_handle *devh, libusb_ULONG *paraTableStartAddr, libusb_ULONG *paraTableEndAddr, libusb_ULONG *crcAddr)
{
	libusb_BYTE romVersion[8] = { 0 };
	if (libusb_TRUE != libusb_LibUsb_GetAsicRomVersion(devh, romVersion))
		return libusb_FALSE;

	if (memcmp(romVersion, "231R0", 4) == 0 && romVersion[5] >= 2) // 231R0_V2
	{
		return libusb_FALSE;
	}
	else if (((memcmp(romVersion, "232R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "275R0", 4) == 0 && romVersion[5] == 1 && romVersion[6] == 0x30)) ||
		((memcmp(romVersion, "276R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "290R0", 4) == 0 && romVersion[5] == 1)))
	{
		*paraTableStartAddr = 0xC000;
		*paraTableEndAddr = *paraTableStartAddr + 0xF00;
		*crcAddr = *paraTableStartAddr + 0xF00;
	}
	else if (((memcmp(romVersion, "232R0", 4) == 0 && romVersion[5] == 2)) ||
		((memcmp(romVersion, "290R0", 4) == 0 && romVersion[5] == 2)) ||
		((memcmp(romVersion, "288R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "289R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "270R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "271R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "280R0", 4) == 0 && romVersion[5] == 1)) ||
		((memcmp(romVersion, "281R0", 4) == 0 && romVersion[5] == 1)))
	{
		libusb_BYTE sectorTable[32];
		if (libusb_TRUE != libusb_LibUsb_ReadFormSF(devh, 0x160, sectorTable, sizeof(sectorTable)))
			return libusb_FALSE;

		// pbySectorTable[8] is parameter start address for deivce
		// pbySectorTable[9] is parameter size for deivce
		*paraTableStartAddr = (libusb_ULONG)sectorTable[0x08] << 8;
		*paraTableEndAddr = *paraTableStartAddr + ((libusb_ULONG)sectorTable[0x09] << 8);
		*crcAddr = (libusb_ULONG)sectorTable[0xE] << 8;
	}
	else if (((memcmp(romVersion, "272R0", 4) == 0) && (romVersion[5] == 1)) ||
		((memcmp(romVersion, "273R0", 4) == 0) && (romVersion[5] == 1)) ||
		((memcmp(romVersion, "275R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "283R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "285R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "286R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "287R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "267R0", 4) == 0) && (romVersion[5] == 1) && (romVersion[6] == 0x46)) ||
		((memcmp(romVersion, "292R0", 4) == 0) && (romVersion[5] == 1)))//wei add 292
	{
		// Get Parameter table start address
		// Parameter table start address is stored at 0x16F
		libusb_BYTE sectorTable[0x2B];
		if (libusb_TRUE != libusb_LibUsb_ReadFormSF(devh, 0x160, sectorTable, sizeof(sectorTable)))
			return libusb_FALSE;

		*paraTableStartAddr = ((libusb_ULONG)sectorTable[0x0F] << 24) + ((libusb_ULONG)sectorTable[0x10] << 16) + ((libusb_ULONG)sectorTable[0x11] << 8) + sectorTable[0x12];
		libusb_ULONG dwParaTableSize = ((libusb_ULONG)sectorTable[0x13] << 24) + ((libusb_ULONG)sectorTable[0x14] << 16) + ((libusb_ULONG)sectorTable[0x15] << 8) + sectorTable[0x16];
		*paraTableEndAddr = *paraTableStartAddr + dwParaTableSize;
		*crcAddr = ((libusb_ULONG)sectorTable[0x27] << 24) + ((libusb_ULONG)sectorTable[0x28] << 16) + ((libusb_ULONG)sectorTable[0x29] << 8) + sectorTable[0x2a];
	}
	else if ((memcmp(romVersion, "216R0", 4) == 0))
	{
		*paraTableStartAddr = 0x5800;
		*paraTableEndAddr = *paraTableStartAddr + 0xF00;
		*crcAddr = *paraTableStartAddr + 0xF00;
	}
	else
	{
		*paraTableStartAddr = 0x8000;
		*paraTableEndAddr = *paraTableStartAddr + 0x800;
		*crcAddr = 0;
	}
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_GetStringSettingFormSF(libusb_device_handle *devh, libusb_BYTE* pbyString, libusb_DWORD stringSize, libusb_DWORD StringOffset, libusb_BOOL bIsCRCProtect)
{
	libusb_DWORD dwStringAddr = 0;
	libusb_ULONG dwParaTableStartAddr = 0;
	libusb_ULONG dwParaTableEndAddr = 0;
	libusb_ULONG dwCRCStartAddr = 0;

	if (libusb_TRUE != libusb_LibUsb_GetParaTableAndCRCAddrFormSF(devh, &dwParaTableStartAddr, &dwParaTableEndAddr, &dwCRCStartAddr))
		return libusb_FALSE;

	dwStringAddr = StringOffset;
	if (bIsCRCProtect)
		dwStringAddr += dwParaTableStartAddr;
	else
		dwStringAddr += dwCRCStartAddr;

	libusb_BYTE pbyStringBuf[0x40] = { 0 };
	if (libusb_TRUE != libusb_LibUsb_ReadFormSF(devh, dwStringAddr, pbyStringBuf, sizeof(pbyStringBuf)))
		return libusb_FALSE;

	// Calculate string length
	libusb_DWORD dwStringLength = 0;
	if (bIsCRCProtect)
		dwStringLength = (pbyStringBuf[0] - 2) / 2;
	else
	for (; (dwStringLength < 0x40 / 2) && (pbyStringBuf[dwStringLength] != 0xFF); ++dwStringLength);

	if (stringSize < dwStringLength)
		return libusb_FALSE;

	// Copy string to output buffer
	libusb_DWORD i;
	if (bIsCRCProtect)
	{
		for (i = 0; i<dwStringLength; ++i)
			pbyString[i] = pbyStringBuf[2 + i * 2];
	}
	else
	{
		memcpy(pbyString, pbyStringBuf, dwStringLength);
	}

    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_Read(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs)
{
	int r;
	r = libusb_control_transfer(devh, libusbCTRL_IN, 0x81, cs << 8, unitID << 8 , pData,
		length, 1000);
	if (r < 0) {
		return libusb_FALSE;
	}
	return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_Write(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs)
{
	int r;
	r = libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, cs << 8, unitID << 8, pData,
		length, 1000);
	if (r < 0) {
		return libusb_FALSE;
	}
    return libusb_TRUE;
}

libusb_BOOL libusb_LibUsb_GetMemType(libusb_device_handle *devh, libusb_BYTE *pMemType)
{

	unsigned char data[11] = {0};
	int r;
	// Read
	r = libusb_control_transfer(devh, libusbCTRL_IN, 0x81, 5, libusb_g_CurDspExtendUnitID, data,
		11, 1000);
	if (r < 0) {
		return libusb_FALSE;
	}

	*pMemType = data[2];
    return libusb_TRUE;
}

libusb_BOOL libusb_XU_Read(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs)
{
	int ret;
	ret=libusb_control_transfer(devh, libusbCTRL_IN, 0x81, cs, unitID, pData, length, 1000);
	if(ret < 0)
		return libusb_FALSE;
	return libusb_TRUE;
}

libusb_BOOL libusb_XU_Write(libusb_device_handle *devh, unsigned char pData[], unsigned int length, libusb_BYTE unitID, libusb_BYTE cs)
{
	int ret;
	ret=libusb_control_transfer(devh, libusbCTRL_OUT, 0x01, cs, unitID, pData, length, 1000);
	if(ret < 0)
		return libusb_FALSE;
	return libusb_TRUE;
}