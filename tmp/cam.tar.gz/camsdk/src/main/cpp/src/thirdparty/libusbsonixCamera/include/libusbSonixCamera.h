#ifndef __LIBUSBSONIXCAMERA_H__
#define __LIBUSBSONIXCAMERA_H__
#ifdef __cplusplus
extern "C" {
#endif
#include "libusbutil.h"
#include "libusbLUOptDev.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	重启设备
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_RestartDevice
*	Description:		
*	Parameters:
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_RestartDevice(libusb_device_handle *devh);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得错误代码
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetErrorCode
*	Description:
*	Parameters:
*	Return :		成功返回	libusb_TRUE
*/
libusb_ERROR_CODE libusb_SonixCam_GetErrorCode();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Dsp寄存器读
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_AsicRegisterRead
*	Description:
*	Parameters:		addr:dsp寄存器地址，pData读取数据缓存，len：要读取的数据字节数。
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_AsicRegisterRead(libusb_device_handle *devh, unsigned short addr, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Dsp寄存器写
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_AsicRegisterWrite
*	Description:
*	Parameters:		addr:dsp寄存器地址，pData：写数据缓存，len：要写的数据字节数。
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_AsicRegisterWrite(libusb_device_handle *devh, unsigned short addr, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	I2C读
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SensorRegisterCustomRead
*	Description:
*	Parameters:		slaveId:I2c子设备ID,addr:要读的地址,addrByteNumber: 地址字节数,最大2字节, pData:读数据缓存, dataByteNumber:要读的数据字节数,最大2字节, pollSCL:SCL 拉高
*	Return :			成功返回	libusb_true
*/
libusb_sonixbool  libusb_SonixCam_SensorRegisterCustomRead(libusb_device_handle *devh, unsigned char slaveId, unsigned short  addr, unsigned short  addrByteNumber, unsigned char pData[], long dataByteNumber, libusb_sonixbool pollSCL); //bool pollSCL = libusb_false

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	I2C写
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SensorRegisterCustomWrite
*	Description:
*	Parameters:		slaveId:I2c子设备ID,addr:要写的地址,addrByteNumber: 地址字节数,最大2字节, pData:写数据缓存, dataByteNumber:要写的数据字节数,最大2字节, pollSCL:SCL 拉高
*	Return :			成功返回	libusb_true
*/
libusb_sonixbool  libusb_SonixCam_SensorRegisterCustomWrite(libusb_device_handle *devh, unsigned char slaveId, unsigned short addr, unsigned short  addrByteNumber, unsigned char pData[], long dataByteNumber, libusb_sonixbool pollSCL);

// XU read
libusb_sonixbool libusb_SonixCam_XuRead(libusb_device_handle *devh, unsigned char pData[], unsigned int length, unsigned char unitID, unsigned char cs);
// XU write
libusb_sonixbool libusb_SonixCam_XuWrite(libusb_device_handle *devh, unsigned char pData[], unsigned int length, unsigned char unitID, unsigned char cs);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FLASH读，如果获得的DSP_ROM_TYPE是DRT_64K，则可以读取Flash的范围是0-64K, 否则如果DSP_ROM_TYPE是DRT_128K， 读取范围是0-128K
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SerialFlashRead
*	Description:	
*	Parameters:		addr：要写的地址，pData：写缓存， len：写数据长度
*	Return :		成功返回	S_OK
*/
libusb_sonixbool  libusb_SonixCam_SerialFlashRead(libusb_device_handle *devh, long addr, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FLASH读，和SonixCam_SerialFlashRead功能相似，读取Flash的范围不受DSP_ROM_TYPE影响，速度比SonixCam_SerialFlashRead慢
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SerialFlashCustomRead
*	Description:	
*	Parameters:		addr：要写的地址，pData：写缓存， len：写数据长度
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_SerialFlashCustomRead(libusb_device_handle *devh, long addr, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FLASH写
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SerialFlashWrite
*	Description:	与SonixCam_SerialFlashSectorWrite的区别是它不擦除addr地址所在的扇区，需要确保调用该函数之前
*					已经关闭Flash的写保护并且addr地址要写的区域已经擦除。
*	Parameters:		addr：写的地址，pData：写缓存， len：写数据长度，sft: FLASH的类型
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_SerialFlashWrite(libusb_device_handle *devh, long addr, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FLASH写，写地址最大范围是0-256k空间，不要在开图的情况下调用该函数。
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SerialFlashSectorWrite
*	Description:	先关闭FLASH的写保护，并擦除参数addr地址所在的Flash的扇区，然后写入数据。
*	Parameters:		addr：写的地址，pData：写缓存， len：写数据长度，sft: FLASH的类型
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_SerialFlashSectorWrite(libusb_device_handle *devh, long addr, unsigned char pData[], long len, libusb_SERIAL_FLASH_TYPE sft);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	FLASH写，和SonixCam_SerialFlashWrite功能相似，写lash的范围不受DSP_ROM_TYPE影响，速度比SonixCam_SerialFlashWrite慢
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_SerialFlashSectorCustomWrite
*	Description:	
*	Parameters:		addr：要写的地址，pData：写缓存， len：写数据长度
*	Return :		成功返回	S_OK
*/
libusb_sonixbool  libusb_SonixCam_SerialFlashSectorCustomWrite(libusb_device_handle *devh, long addr, unsigned char pData[], long len, libusb_SERIAL_FLASH_TYPE sft);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得FLASH的类型
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetSerialFlashType
*	Description:
*	Parameters:		sft：成功返回flash的类型，check：设为true，在flash读取flash类型
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetSerialFlashType(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE *sft, libusb_sonixbool check);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得FW Code版本号
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		SonixCam_GetFWVersion
*	Description:
*	Parameters:		pData：FW Code版本号缓存数组指针，len：缓存数组最大字节数，bNormalExport：为TRUE以默认方式排列版本号字符串，为FALSH，以第二种方式排列版本号字符串, 和原始固件名相同。
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetFwVersion(libusb_device_handle *devh, unsigned char pData[], long len, libusb_BOOL bNormalExport); //libusb_BOOL bNormalExport = libusb_TRUE

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	从固件文件缓存中获得FW Code版本号
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetFwVersionFromFile
*	Description:
*	Parameters:		pFwFile:固件缓存无符号字符指针, pData:FW Code版本号缓存数组指针,len:缓存数组最大字节数,bNormalExport:为true以默认方式排列版本号字符串,为FALSH,以第二种方式排列版本号字符串,和原始固件名相同。
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetFwVersionFromFile(libusb_device_handle *devh, unsigned char pFwFile[], unsigned char pData[], long len, libusb_sonixbool bNormalExport); //libusb_BOOL bNormalExport = libusb_TRUE


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得FW Code版本号， 如果是271设备，则需要调用该函数获得FW版本号
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		SonixCam_GetFWVersion
*	Description:
*	Parameters:		romType： DSP的ROM大小， pData：FW Code版本号缓存数组指针，len：缓存数组最大字节数，bNormalExport：为TRUE以默认方式排列版本号字符串，为FALSH，以第二种方式排列版本号字符串, 和原始固件名相同。
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetFwVersionEx(libusb_device_handle *devh, libusb_DSP_ROM_TYPE romType, unsigned char pData[], long len, libusb_BOOL bNormalExport); //libusb_BOOL bNormalExport = libusb_TRUE

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得设备Manufacturer
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetManufacturer
*	Description:
*	Parameters:		pData：Manufacturer缓存数组指针，len：缓存数组最大字节数
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetManufacturer(libusb_device_handle *devh, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得设备Product
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetProduct
*	Description:
*	Parameters:		pData：Product缓存数组指针，len：缓存数组最大字节数
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetProduct(libusb_device_handle *devh, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得设备vidpid
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetVidPid
*	Description:
*	Parameters:		pData：vidpid缓存数组指针，len：缓存数组最大字节数
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetVidPid(libusb_device_handle *devh, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得设备String3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetString3
*	Description:
*	Parameters:		pData：String3缓存数组指针，len：缓存数组最大字节数
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_GetString3(libusb_device_handle *devh, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得设备Interface
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetInterface
*	Description:
*	Parameters:		pData：Interface缓存数组指针，len：缓存数组最大字节数
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_GetInterface(libusb_device_handle *devh, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得设备序列号
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_GetSerialNumber
*	Description:
*	Parameters:		pData：序列号缓存数组指针，len：缓存数组最大字节数
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_GetSerialNumber(libusb_device_handle *devh, unsigned char pData[], long len);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	进度回调函数指针
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Description:	libusb_SonixCam_BurnerFW， libusb_SonixCam_WriteFwToFlash， libusb_SonixCam_ExportFW，SonixCam_FullCheckFW， libusb_SonixCam_CustomBurnerFW，
*					SonixCam_SetParamTableFromFWFile中可以传递函数指针来更新烧录进度
*	Parameters:		ptrClass：类指针，fProcess：当前进度值
*	Return :		成功返回	libusb_TRUE
*/
typedef void(*libusb_SonixCam_SetProgress)(void *ptrClass, float fProcess);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	关闭FLASH的写保护
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_DisableSerialFlashWriteProtect
*	Description:
*	Parameters:		sft：FLASH类型
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_DisableSerialFlashWriteProtect(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	擦除FLASH
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		libusb_SonixCam_EraseSerialFlash
*	Description:
*	Parameters:		sft： FLASH类型
*	Return :		成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_EraseSerialFlash(libusb_device_handle *devh, libusb_SERIAL_FLASH_TYPE sft);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	擦除FLASH的一个扇区
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_EraseSectorFlash
*	Description:
*	Parameters:	addr：要擦除的扇区地址，sft：FLASH类型
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_EraseSectorFlash(libusb_device_handle *devh, long addr, libusb_SERIAL_FLASH_TYPE sft);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	擦除FLASH的一个块区
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_EraseBlockFlash
*	Description:
*	Parameters:	addr：要擦除的块区地址，sft：FLASH类型
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_EraseBlockFlash(libusb_device_handle *devh, long addr, libusb_SERIAL_FLASH_TYPE sft);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	获得rom类型
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_GetAsicRomType
*	Description:	
*	Parameters:	romType：返回rom类型，chipID：当前dsp的芯片id值
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_GetAsicRomType(libusb_device_handle *devh, libusb_DSP_ROM_TYPE *romType);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	烧录固件，不要在开图的情况下调用该函数。
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_BurnerFW
*	Description: 首先会关闭Flash的写保护，然后擦除整个Flash区域，然后将固件写入到Flash
*	Parameters:	pFwBuffer：要烧录的固件缓存指针，lFwLength：固件缓存长度， setProgress：烧录进度回调函数指针， ptrClass：当前类， sft：flash类型， bFullCheckFW：烧录完成后是否进行全校验
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_BurnerFW(libusb_device_handle *evh, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_SERIAL_FLASH_TYPE sft, libusb_BOOL bFullCheckFW);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	烧录固件，不要在开图的情况下调用该函数。
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_WriteFwToFlash
*	Description: 该函数与SonixCam_BurnerFW的区别是它不会调用关闭写保护和擦除Flash，需要在调用该函数之前自己关闭Flash写保护和擦除Flash相应区域
*	Parameters:	pFwBuffer：要烧录的固件缓存指针，lFwLength：固件缓存长度， setProgress：烧录进度回调函数指针， ptrClass：当前类， bFullCheckFW：烧录完成后是否进行全校验
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_WriteFwToFlash(libusb_device_handle *devh, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_BOOL bFullCheckFW); //libusb_BOOL bFullCheckFW = libusb_FALSE

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	导出固件
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_ExportFW
*	Description:
*	Parameters:	pFwBuffer：要保存固件缓存指针，lFwLength：固件缓存长度， setProgress：导出进度回调函数指针， ptrClass：当前类
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool  libusb_SonixCam_ExportFW(libusb_device_handle *devh, unsigned char  pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass);

//extend burner fw
typedef struct
{
	unsigned int libusb_SerialNumberLength;
	unsigned int libusb_ProductLength;
	unsigned int libusb_ManufactureLength;
	unsigned int libusb_VidPidLength;
	unsigned int libusb_InterfaceLength;
	unsigned int libusb_String3Length;
	char* libusb_pSerialNumber;
	char* libusb_pProduct;
	char* libusb_pManufacture;
	char* libusb_pVidPid;
	char* libusb_pString3;
	char* libusb_pInterface;
}libusb_ChangeParamInfo;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	自定义烧录固件，不要在开图的情况下调用该函数。
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	libusb_SonixCam_SetParamTableFormFWFile
*	Description:	该函数和SonixCam_BurnerFW的区别是它可以更改设备的一些参数
*	Parameters:	paramInfo：要更改的参数信息，pFwBuffer：固件缓存指针，lFwLength：缓存长度，setProgress：烧录进度回调函数指针， ptrClass：当前类， sft:FLASH类型，bFullCheckFW：是否烧录完成后进行全校验
*	Return :	成功返回	libusb_TRUE
*/
libusb_sonixbool libusb_SonixCam_CustomBurnerFW(libusb_device_handle *devh, const libusb_ChangeParamInfo paramInfo, unsigned char pFwBuffer[], libusb_LONG lFwLength, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_SERIAL_FLASH_TYPE sft, libusb_BOOL bFullCheckFW);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	修改设备参数表信息，不要在开图的情况下调用该函数。
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:	SonixCam_SetParamTableFromFWFile
*	Description:	该函数和SonixCam_BurnerFW的区别是它不需要把整个FW烧录到Flash，只需要烧录参数表所在的扇区数据，pFW固件缓存内容必须和设备FLASH中的固件相同
*	Parameters:	pFW：固件缓存指针，lFwLength：缓存长度，setProgress：烧录进度回调函数指针， ptrClass：当前类， sft:FLASH类型，pLogFilePath: 打印的Log文件路径，可以为空，则不打印Log信息， bFullCheckFW：是否烧录完成后进行全校验
*	Return :		成功返回S_OK
*/
libusb_sonixbool libusb_SonixCam_SetParamTableFormFWFile(libusb_device_handle *devh, unsigned char pFW[], long lFwLength, const libusb_ChangeParamInfo *pParamInfo, libusb_SonixCam_SetProgress setProgress, void *ptrClass, libusb_SERIAL_FLASH_TYPE sft, char* pLogFilePath);

#ifdef __cplusplus
}
#endif

#endif
