#include "include/libusbROMData.h"

unsigned short libusb_RomStringAddr[libusb_ROMSTRADDRCNT] = { 0x9FF8, 0xD2B2, 0xDFF8, 0xBFF8, 0xC7F8, 0xAFF8 };	// shawn 2009/05/04 add 232R0 v1

unsigned int libusb_uiRomID = 0;

libusb_ROM_INFO libusb_RomInfo[libusb_ROMCOUNT] =
{
	{ 0x9FF8, { 0x32, 0x32, 0x30, 0x52, 0x30, 0x01, 0x00, 0x00 }, 0x03C5,	// 220R0 (21x, 21xA, 21xB)
	0x0000, 0x0000, 40 * 1024, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0x9FF8, { 0x32, 0x32, 0x35, 0x52, 0x30, 0x03, 0x00, 0x00 }, 0x031D,	// 225R0
	0x0000, 0x01E8, 40 * 1024, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0x9FF8, { 0x32, 0x35, 0x30, 0x52, 0x30, 0x01, 0x00, 0x00 }, 0x0530,	// 250R0 v1
	0x0000, 0x01E8, 40 * 1024, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0x9FF8, { 0x32, 0x35, 0x30, 0x52, 0x30, 0x02, 0x00, 0x00 }, 0x05F0,	// 250R0 v2 and new version
	0x0000, 0x01E8, 40 * 1024, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xD2B2, { 0x32, 0x33, 0x30, 0x52, 0x30, 0x01, 0x00, 0x00 }, 0x0530,	// 230R0 v1
	0x0000, 0x01E8, 56 * 1024, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xDFF8, { 0x32, 0x33, 0x30, 0x52, 0x30, 0x02, 0x00, 0x00 }, 0x05E0,	// 230R0 v2
	0x0000, 0x01E8, 56 * 1024, libusb_false, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xDFF8, { 0x32, 0x33, 0x30, 0x52, 0x30, 0x03, 0x00, 0x03 }, 0x05F0,	// 230R0 v3 and new version
	0x0000, 0x01E8, 56 * 1024, libusb_true, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xDFF8, { 0x32, 0x33, 0x31, 0x52, 0x30, 0x01, 0x00, 0x01 }, 0x05F0,	// 231R0 v1
	0x0000, 0x01E8, 56 * 1024, libusb_false, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xDFF8, { 0x32, 0x31, 0x36, 0x52, 0x30, 0x01, 0x00, 0x01 }, 0x05F0,	// shawn 2009/10/15 add 216R0
	0x0000, 0x0148, 56 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x31, 0x35, 0x52, 0x30, 0x01, 0x00, 0x00 }, 0x05F0,	// 215R0
	0x0000, 0x01E8, 48 * 1024, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x33, 0x36, 0x52, 0x30, 0x01, 0x00, 0x00 }, 0x0690,	// 236R0 v1
	0x0000, 0x01E8, 48 * 1024, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x33, 0x36, 0x52, 0x30, 0x02, 0x00, 0x02 }, 0x05F0,	// 236R0 v2 and new version
	0x0000, 0x01E8, 48 * 1024, libusb_true, libusb_true, libusb_false, libusb_false, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x35, 0x36, 0x52, 0x30, 0x01, 0x00, 0x01 }, 0x05F0,	// 256R0 
	0x0000, 0x01E8, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x33, 0x31, 0x52, 0x30, 0x02, 0x10, 0x01 }, 0x05F0,	// 231R0 v2 and new version 
	0x6000, 0x61E8, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x36, 0x36, 0x52, 0x30, 0x01, 0x00, 0x01 }, 0x05F0,	// shawn 2009/05/18 add 266R0
	0x0000, 0x01E8, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x37, 0x36, 0x52, 0x30, 0x01, 0x40, 0x06 }, 0x05F0,	// shawn 2009/02/18 add 276R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x37, 0x35, 0x52, 0x30, 0x01, 0x30, 0x05 }, 0x05F0,	// shawn 2009/07/09 add 275R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x39, 0x30, 0x52, 0x30, 0x01, 0x60, 0x07 }, 0x05F0, 	// shawn 2010/08/11 add 290R0 v1
	0x0000, 0x0148, 48 * 1024, libusb_false, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false },
	{ 0xBFF8, { 0x32, 0x39, 0x30, 0x52, 0x30, 0x02, 0x61, 0x20 }, 0x05F0,	// shawn 2011/01/31 add 290R0 v2
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_false },
	{ 0xBFF8, { 0x32, 0x38, 0x36, 0x52, 0x30, 0x01, 0x41, 0x19 }, 0x05F0, 	// shawn 2010/12/30 add 286R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xBFF8, { 0x32, 0x38, 0x38, 0x52, 0x30, 0x01, 0x42, 0x21 }, 0x05F0, 	// shawn 2011/06/10 add 288R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xBFF8, { 0x32, 0x38, 0x38, 0x52, 0x30, 0x01, 0x42, 0x21 }, 0x05F0, 	// shawn 2011/08/23 add 289R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xBFF8, { 0x32, 0x37, 0x30, 0x52, 0x30, 0x01, 0x43, 0x22 }, 0x05F0, 	// shawn 2012/02/08 add 270R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xBFF8, { 0x32, 0x37, 0x31, 0x52, 0x30, 0x01, 0x43, 0x22 }, 0x05F0, 	// shawn 2012/02/08 add 271R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xBFF8, { 0x32, 0x38, 0x30, 0x52, 0x30, 0x01, 0x45, 0x23 }, 0x05F0,	// Daniel 2012/09/13 add 280R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xBFF8, { 0x32, 0x38, 0x31, 0x52, 0x30, 0x01, 0x45, 0x23 }, 0x05F0, 	// Daniel 2012/09/13 add 281R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xC7F8, { 0x32, 0x33, 0x32, 0x52, 0x30, 0x01, 0x20, 0x05 }, 0x05F0, 	// shawn 2009/04/03 add 232R0 v1
	0x0000, 0x0148, 56 * 1024, libusb_false, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false },
	{ 0xC7F8, { 0x32, 0x33, 0x32, 0x52, 0x30, 0x02, 0x50, 0x07 }, 0x05F0, 	// shawn 2010/05/11 add 232R0 v2 (L232)
	0x0000, 0x0148, 56 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xAFF8, { 0x32, 0x37, 0x32, 0x52, 0x30, 0x01, 0x46, 0x25 }, 0x05F0, 	// Jyh 2015/02/05 add 272R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xAFF8, { 0x32, 0x37, 0x33, 0x52, 0x30, 0x01, 0x46, 0x25 }, 0x05F0, 	// Tzsiang 2015/06/04 add 273R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xAFF8, { 0x32, 0x37, 0x35, 0x52, 0x30, 0x01, 0x46, 0x25 }, 0x05F0, 	// Tzsiang 2015/06/04 add 275R0
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xAFF8, { 0x32, 0x38, 0x33, 0x52, 0x30, 0x01, 0x46, 0x24 }, 0x05F0, 	// wei add 283R0
	0x0000, 0x0148, 48 * 1024, libusb_false, libusb_true, libusb_true, libusb_false, libusb_true, libusb_false },
	{ 0x9FF8, { 0x32, 0x39, 0x32, 0x52, 0x30, 0x01, 0x61, 0x08 }, 0x05F0,	// 292R0 wei add 292
	0x0000, 0x0148, 48 * 1024, libusb_false, libusb_true, libusb_true, libusb_false, libusb_true, libusb_false },
	{ 0xAFF8, { 0x32, 0x38, 0x37, 0x52, 0x30, 0x01, 0x46, 0x31 }, 0x05F0,	// 287R0 wei add 287
	0x0000, 0x0148, 48 * 1024, libusb_false, libusb_true, libusb_true, libusb_false, libusb_true, libusb_false },
	{ 0xAFF8, { 0x32, 0x36, 0x37, 0x52, 0x30, 0x01, 0x46, 0x32 }, 0x05F0,   //yiling add 267
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true, libusb_true },
	{ 0xAFF8, { 0x32, 0x37, 0x36, 0x52, 0x30, 0x01, 0x46, 0x35 }, 0x05F0,   //liwei add 276R0 v2
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_true, libusb_false, libusb_false },
	{ 0xAFF8, { 0x32, 0x38, 0x35, 0x52, 0x30, 0x01, 0x46, 0x36 }, 0x05F0,   //liwei add 285R0 
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_false, libusb_true, libusb_false },
	{ 0xAFF8, { 0x32, 0x38, 0x36, 0x52, 0x30, 0x01, 0x46, 0x36 }, 0x05F0,   //liwei add 286R0 
	0x0000, 0x0148, 48 * 1024, libusb_true, libusb_true, libusb_true, libusb_false, libusb_true, libusb_false }
};


libusb_DSP_ARCH_INFO libusb_g_DspArchInfo[libusb_DSP_ARCH_COUNT] =
{
	{ 0x101f, 0x1084, 0x1073, 0x1005, 0x1006, 0x1007, 0x1080, 0x1091, 0x1082, 0x1083, 0x1081 },
	{ 0x80f0, 0x8e04, 0x8c00, 0x8200, 0x8201, 0x8202, 0x8e00, 0x8e11, 0x8e02, 0x8e03, 0x8e01 },
};

libusb_USHORT libusb_dspIdAddr = 0x101f;
libusb_USHORT libusb_sfRdyAddr = 0x1084;
libusb_USHORT libusb_usbResetAddr = 0x1073;
libusb_USHORT libusb_gpioInputAddr = 0x1005;
libusb_USHORT libusb_gpioOutputAddr = 0x1006;
libusb_USHORT libusb_gpioOEAddr = 0x1007;
libusb_USHORT libusb_sfModeAddr = 0x1080;
libusb_USHORT libusb_sfCSAddr = 0x1091;
libusb_USHORT libusb_sfWriteDataAddr = 0x1082;
libusb_USHORT libusb_sfReadDataAddr = 0x1083;
libusb_USHORT libusb_sfReadWriteTriggerAddr = 0x1081;

libusb_USHORT libusb_i2cDev = 0x10d0;
libusb_USHORT libusb_i2cMode = 0x10d9;
libusb_USHORT libusb_i2cTrg = 0x10d7;
libusb_USHORT libusb_i2cSclSelOD = 0x10d8;
libusb_USHORT libusb_i2cSlaveID = 0x10d1;
libusb_USHORT libusb_i2cDataArrStartAddr = 0x10d2;

libusb_BOOL libusb_LibUsb_SetAsicArchInfo(libusb_DSP_ARCH_TYPE dspArchType)
{
	if (dspArchType <= libusb_DAT_UNKNOW || dspArchType >= libusb_DSP_ARCH_COUNT)
		return libusb_FALSE;

	libusb_dspIdAddr = libusb_g_AsicArchInfo[dspArchType].libusb_asicIdAddr;
	libusb_sfRdyAddr = libusb_g_AsicArchInfo[dspArchType].libusb_sfRdyAddr;
	libusb_usbResetAddr = libusb_g_AsicArchInfo[dspArchType].libusb_usbResetAddr;
	libusb_usbResetAddr = libusb_g_AsicArchInfo[dspArchType].libusb_usbResetAddr;
	libusb_gpioOutputAddr = libusb_g_AsicArchInfo[dspArchType].libusb_gpioOutputAddr;
	libusb_gpioOEAddr = libusb_g_AsicArchInfo[dspArchType].libusb_gpioOEAddr;
	libusb_sfModeAddr = libusb_g_AsicArchInfo[dspArchType].libusb_sfModeAddr;
	libusb_sfCSAddr = libusb_g_AsicArchInfo[dspArchType].libusb_sfCSAddr;
	libusb_sfWriteDataAddr = libusb_g_AsicArchInfo[dspArchType].libusb_sfWriteDataAddr;
	libusb_sfReadDataAddr = libusb_g_AsicArchInfo[dspArchType].libusb_sfReadDataAddr;
	libusb_sfReadWriteTriggerAddr = libusb_g_AsicArchInfo[dspArchType].libusb_sfReadWriteTriggerAddr;

	libusb_i2cDev = libusb_g_AsicArchInfo[dspArchType].libusb_i2cDev;
	libusb_i2cMode = libusb_g_AsicArchInfo[dspArchType].libusb_i2cMode;
	libusb_i2cTrg = libusb_g_AsicArchInfo[dspArchType].libusb_i2cTrg;
	libusb_i2cSclSelOD = libusb_g_AsicArchInfo[dspArchType].libusb_i2cSclSelOD;
	libusb_i2cSlaveID = libusb_g_AsicArchInfo[dspArchType].libusb_i2cSlaveID;
	libusb_i2cDataArrStartAddr = libusb_g_AsicArchInfo[dspArchType].libusb_i2cDataArrStartAddr;
	return libusb_TRUE;
}

libusb_USHORT libusb_g_CurDspExtendUnitID = 0x300;

libusb_DSP_ARCH_INFO libusb_g_AsicArchInfo[libusb_DSP_ARCH_COUNT] =
{
	{ 0x101f, 0x1084, 0x1073, 0x1005, 0x1006, 0x1007, 0x1080, 0x1091, 0x1082, 0x1083, 0x1081, 
		0x10d0, 0x10d9, 0x10d7, 0x10d8, 0x10d1, 0x10d2},
	{ 0x80f0, 0x8e04, 0x8c00, 0x8200, 0x8201, 0x8202, 0x8e00, 0x8e11, 0x8e02, 0x8e03, 0x8e01, 
		0x8600, 0x8609, 0x8607, 0x8608, 0x8601, 0x8602},
};
