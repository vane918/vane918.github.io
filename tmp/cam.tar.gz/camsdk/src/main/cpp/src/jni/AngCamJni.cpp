/*****************************************************************************
*  This file is part of the Angstrong camera SDK                             *
*  Copyright (C) 2022 Angstrong                                              *
*                                                                            *                                                                           *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*****************************************************************************/

#include <jni.h>
#include <string>
#include <map>
#include <vector>
#include <atomic>

#include "AngContext.h"
#include "AngTypes.h"
#include "AngLog.hpp"
#include "AngDevice.h"
#include "AngSensor.h"
#include "AngStreamConfig.h"

static const char* JNI_REG_CLASS = "com/ang/camera/NativeApi";

static constexpr int MAX_TRANSFER_PACKET = 60 * 2;
static constexpr int MAX_TRANSFER_LARGE_PACKET = 1024 * 8;
static constexpr int MCU_INFO_SIZE = 1024;
static char *firmwareInfo = static_cast<char *>(malloc(MAX_TRANSFER_PACKET));
static char *firmwareLargeInfo = static_cast<char *>(malloc(MAX_TRANSFER_LARGE_PACKET));
static char *mcuInfo = static_cast<char *>(malloc(MCU_INFO_SIZE));

using namespace ang;

static Context *g_contextPtr{nullptr};

static std::shared_ptr<DeviceList> g_deviceListPtr{nullptr};

static std::atomic<bool> g_initialized = {false};

static std::vector<std::shared_ptr<CameraSession>> g_session_list;

JavaVM *g_pVm = nullptr;

jclass g_frameCallbackCls;

jclass g_deviceCls;

jclass g_frameRefCls;

jclass g_deviceWatcherCls;

static void frameCallback(long sensorHandle, std::shared_ptr<Frame> frame);

static void deviceOnUpgradeCallback(const AngDeviceUpgradeInfo *pInfo, void *);

class JniEnvSupplier {
public:
    JniEnvSupplier() : m_p_env_(nullptr), m_b_should_detach_(false) {
        if (JNI_EDETACHED == g_pVm->GetEnv((void **) &m_p_env_, JNI_VERSION_1_6)) {
            g_pVm->AttachCurrentThread(&m_p_env_, nullptr);

            m_b_should_detach_ = true;
        }
    }

    ~JniEnvSupplier() {
        if (m_b_should_detach_) {
            g_pVm->DetachCurrentThread();
        }
    }

    JNIEnv *get_env() { return m_p_env_; }

private:
    JNIEnv *m_p_env_;
    bool m_b_should_detach_;
};

static void onDeviceChangedCallback(void* ptr, std::string action, AngDevInfo devInfo) {
    JniEnvSupplier suplier;
    jmethodID methodID = suplier.get_env()->GetStaticMethodID(g_deviceWatcherCls, "onDeviceChangeCallback",
                                                              "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
    JNIEnv *env = suplier.get_env();

    env->CallStaticVoidMethod(g_deviceWatcherCls, methodID, env->NewStringUTF(devInfo.usb.uid.c_str()),
                              env->NewStringUTF(action.c_str()), env->NewStringUTF(devInfo.usb.devpath.c_str()));
    suplier.get_env()->ExceptionClear();
}

extern "C" JNIEXPORT jint JNICALL
jInitialize(
        JNIEnv *env, jclass clazz) {

    ANG_LOGI("jni initialize");

    if (g_initialized) {
        ANG_LOGE("jni already initialize");
        return ANG_STATUS_FAILED;
    }

    g_contextPtr = new Context();
    g_initialized = true;

    return g_contextPtr->initialize();
}

extern "C" JNIEXPORT jint JNICALL
jShutdown(
        JNIEnv *env,
        jclass clazz) {
    ANG_LOGI("jni shutdown");

    if (!g_initialized) {
        ANG_LOGE("jni shutdown failed, please initialize first");
        return ANG_STATUS_FAILED;
    }

    AngStatus rc = g_contextPtr->shutdown();
    g_initialized = false;

    g_deviceListPtr = nullptr;

    delete g_contextPtr;
    g_contextPtr = nullptr;

    return rc;
}

extern "C" JNIEXPORT jlong JNICALL
jEnumerateDevices(
        JNIEnv *env, jclass clazz, jobjectArray string_array, jobject obj) {

    ANG_LOGI("jni enumerateDevices");
    if (!g_initialized) {
        ANG_LOGE("jni enumerateDevices failed, please initialize first");
        return ANG_STATUS_FAILED;
    }

    jint len_uid = env->GetArrayLength(string_array);

    jclass jcs_alist = env->GetObjectClass(obj);
    jmethodID alist_size = env->GetMethodID(jcs_alist, "size", "()I");
    jmethodID alist_get = env->GetMethodID(jcs_alist, "get", "(I)Ljava/lang/Object;");
    jint len_bytes = env->CallIntMethod(obj, alist_size);
    if (len_uid != len_bytes) {
        ANG_LOGE("jni initialize failed! len_uid[%d] != len_bytes[%d]", len_uid, len_bytes);
        return false;
    }

    std::map<std::string, unsigned char*> map_raw;
    for (int i = 0; i < len_uid; ++i) {
        jstring str = static_cast<jstring>(env->GetObjectArrayElement(string_array, i));
        const char* uid = env->GetStringUTFChars(str, NULL);
        jobject _obj = env->CallObjectMethod(obj, alist_get, i);
        jbyteArray byte_array = static_cast<jbyteArray>(_obj);
        jbyte* jbytes = env->GetByteArrayElements(byte_array, NULL);
        int nArrLen = env->GetArrayLength(byte_array);
        unsigned char* des_bytes = new unsigned char[nArrLen];
        memcpy(des_bytes, jbytes, nArrLen);
        std::string key = std::to_string(nArrLen) + "#" + uid;
        map_raw.insert(std::make_pair(key, des_bytes));
        env->ReleaseStringUTFChars(str, uid);
        env->ReleaseByteArrayElements(byte_array, jbytes, 0);
    }

    g_deviceListPtr = g_contextPtr->enumerateDevices(&map_raw);
    for (auto& it : map_raw) {
        delete[] it.second;
    }
    map_raw.clear();
    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());
    return handle_ptr;
}

extern "C" JNIEXPORT jlong JNICALL
jGetDeviceList(
        JNIEnv *env,
        jclass clazz) {

    if (!g_initialized) {
        ANG_LOGE("jni getDeviceList failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();
    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());
    return handle_ptr;
}

extern "C" JNIEXPORT jstring JNICALL
jGetSDKVersion(
        JNIEnv *env,
        jclass clazz) {
    std::string version = Context::getSDKVersion();
    return env->NewStringUTF(version.c_str());
}

extern "C" JNIEXPORT jlong JNICALL
jCreateCameraSession(
        JNIEnv *env,
        jclass clazz, jlong deviceHandle) {
    if (!g_initialized) {
        ANG_LOGE("jni createCameraSession failed, please initialize first");
        return ANG_STATUS_FAILED;
    }

    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto device_ptr = g_deviceListPtr->getDevice(i);
        long device_handle = reinterpret_cast<long>(device_ptr.get());
        if (deviceHandle == device_handle) {
            auto session_ptr = g_contextPtr->createCameraSession(device_ptr);
            g_session_list.emplace_back(session_ptr);
            return reinterpret_cast<long>(session_ptr.get());
        }
    }

    return -1L;
}

extern "C" JNIEXPORT jint JNICALL
jDestroyCameraSession(
        JNIEnv *env,
        jclass clazz, jlong sessionHandle) {
    if (!g_initialized) {
        ANG_LOGE("jni destroyCameraSession failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    auto cameraSession = reinterpret_cast<CameraSession *>(sessionHandle);
    for (int i = 0; i < g_session_list.size(); ++i) {
        if (g_session_list.at(i).get() == cameraSession) {
            g_session_list.erase(g_session_list.begin() + i);
            break;
        }
    }
    return 0;
}

static char* ptr = new char();

extern "C" JNIEXPORT jint JNICALL
jRegisterDeviceListener(
        JNIEnv *env,
        jclass clazz) {
    if (!g_initialized) {
        ANG_LOGE("jni registerDeviceListener failed, please initialize first");
        return ANG_STATUS_FAILED;
    }

    return g_contextPtr->registerDeviceChangeCallback(ptr, onDeviceChangedCallback);
}

extern "C" JNIEXPORT jint JNICALL
jUnregisterDeviceListener(
        JNIEnv *env,
        jclass clazz) {
    if (!g_initialized) {
        ANG_LOGE("jni unregisterDeviceListener failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    return g_contextPtr->unregisterDeviceChangeCallback(ptr);
}

extern "C" JNIEXPORT jint JNICALL
jEnableLogToFile(
        JNIEnv *env,
        jclass clazz, jboolean enable) {
    return Context::enableLogToFile(enable);
}

extern "C" JNIEXPORT jint JNICALL
jEnableAutoReconnect(
        JNIEnv *env,
        jclass clazz, jboolean enable) {
    if (!g_initialized) {
        ANG_LOGE("jni unregisterDeviceListener failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    return g_contextPtr->enableAutoReconnect(enable);
}

/**********************CameraSession**************************/
extern "C" JNIEXPORT jint JNICALL
jCameraSessionStart(
        JNIEnv *env,
        jclass clazz, jlong handle, jint uvc_fd, jint mcu_fd, jint width, jint height, jint format, jlong clientHandle) {
    if (!g_initialized) {
        ANG_LOGE("jni cameraSessionStart failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    auto cameraSession = reinterpret_cast<CameraSession *>(handle);
    return cameraSession->start(uvc_fd, mcu_fd, width, height, static_cast<AngFormat>(format), clientHandle, frameCallback);
}

extern "C" JNIEXPORT jint JNICALL
jCameraSessionStop(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized) {
        ANG_LOGE("jni cameraSessionStop failed, please initialize first");
        return ANG_STATUS_FAILED;
    }

    auto cameraSession = reinterpret_cast<CameraSession *>(handle);
    return cameraSession->stop();
}

/**********************DeviceList**************************/
extern "C" JNIEXPORT jint JNICALL
jGetDeviceCount(
        JNIEnv *env,
        jclass clazz, jlong handle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceCount failed, please initialize first");
        return ANG_STATUS_FAILED;
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return ANG_STATUS_FAILED;

    return g_deviceListPtr->getDeviceCount();
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceName(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceName failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDeviceName(index).c_str());
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceBus(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceBus failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDeviceBus(index).c_str());
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceDevId(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceDevId failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDeviceDevId(index).c_str());
}

extern "C" JNIEXPORT jstring JNICALL
jGetDevicePid(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDevicePid failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDevicePid(index).c_str());
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceVid(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceVid failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDeviceVid(index).c_str());
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceUid(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceUid failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDeviceUid(index).c_str());
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceSN(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceSN failed, please initialize first");
        return env->NewStringUTF("");
    }

    long handle_ptr = reinterpret_cast<long>(g_deviceListPtr.get());

    if (handle_ptr != handle)
        return env->NewStringUTF("");

    return env->NewStringUTF(g_deviceListPtr->getDeviceSerialNumber(index).c_str());
}

extern "C" JNIEXPORT jlong JNICALL
jGetDevice(
        JNIEnv *env,
        jclass clazz, jlong handle, jint index) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDevice failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    auto dev = g_deviceListPtr->getDevice(index);

    long handle_ptr = reinterpret_cast<long>(dev.get());
    return handle_ptr;
}

extern "C" JNIEXPORT jlong JNICALL
jGetDeviceBySN(
        JNIEnv *env,
        jclass clazz, jlong handle, jstring sn) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceBySN failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();
    const char *sn_c = env->GetStringUTFChars(sn, JNI_FALSE);
    auto dev = g_deviceListPtr->getDeviceBySN(sn_c);
    env->ReleaseStringUTFChars(sn, sn_c);
    long handle_ptr = reinterpret_cast<long>(dev.get());
    return handle_ptr;
}

extern "C" JNIEXPORT jlong JNICALL
jGetDeviceByUid(
        JNIEnv *env,
        jclass clazz, jlong handle, jstring uid) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceByUid failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();
    const char *uid_c = env->GetStringUTFChars(uid, JNI_FALSE);
    auto dev = g_deviceListPtr->getDeviceByUid(uid_c);
    env->ReleaseStringUTFChars(uid, uid_c);

    long handle_ptr = reinterpret_cast<long>(dev.get());
    return handle_ptr;
}

/**********************Device**************************/
extern "C" JNIEXPORT jint JNICALL
jAngOpen(
        JNIEnv *env,
        jclass clazz, jlong handle, jint fd) {
    ANG_LOGI("jni angOpen");

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni angOpen failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            return dev->angOpen(fd);
        }
    }
    return ANG_STATUS_FAILED;
}

/**********************Device**************************/
extern "C" JNIEXPORT jint JNICALL
jAngOpenMcu(
        JNIEnv *env,
        jclass clazz, jlong handle, jint fd) {
    ANG_LOGI("jni angOpenMcu");

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni angOpenMcu failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            return dev->angOpenMcu(fd);
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jAngClose(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    ANG_LOGI("jni angClose");

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni angClose failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            return dev->angClose();
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jAngReboot(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    ANG_LOGI("jni angReboot");

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni angReboot failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            return dev->angReboot();
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jobject JNICALL
jGetDeviceInfo(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceInfo failed, please initialize first");
        return nullptr;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto devInfo = dev->getDeviceInfo();
            jclass deviceInfoCls = env->FindClass("com/ang/camera/DeviceInfo");
            return (*env).NewObject(deviceInfoCls,
                                    (*env).GetMethodID(deviceInfoCls, "<init>", "(J)V"), handle);
        }
    }
    return nullptr;
}

extern "C" JNIEXPORT jlongArray JNICALL
jGetSensorList(
        JNIEnv *env,
        jclass clazz, jlong handle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getSensorList failed, please initialize first");
        return nullptr;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto sensors = dev->getSensorList();
            int num = sensors->getSensorCount();
            jlongArray jArray = env->NewLongArray(num);
            jlong *arr = env->GetLongArrayElements(jArray, NULL);
            for (int j = 0; j < num; ++j) {
                auto sensor = sensors->getSensor(j);
                long sensor_ptr = reinterpret_cast<long>(sensor.get());
                arr[j] = sensor_ptr;
            }
            env->ReleaseLongArrayElements(jArray, arr, 0);
            return jArray;
        }
    }
    return nullptr;
}

extern "C" JNIEXPORT jstring JNICALL
jCommunicateWithMcu(
        JNIEnv *env,
        jclass clazz, jlong handle, jstring cmd) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni communicateWithMcu failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            int cmd_len = env->GetStringLength(cmd);
            const char *cmd_c = env->GetStringUTFChars(cmd, JNI_FALSE);
            int len = cmd_len;
            if (len > MCU_INFO_SIZE) {
                ANG_LOGE("CommunicateWithMcu len is > 1024");
                return env->NewStringUTF("");
            }
            memset(mcuInfo, 0, MCU_INFO_SIZE);
            memcpy(mcuInfo, cmd_c, cmd_len);
            int result = dev->communicateWithMcu(&mcuInfo, len);
            env->ReleaseStringUTFChars(cmd, cmd_c);
            if (result != 0)
                return env->NewStringUTF("");

            std::string respond_Ok = "OK";
            std::string respond_data = mcuInfo;
            if (respond_data.find(respond_Ok) != std::string::npos) {
                return env->NewStringUTF(mcuInfo);
            }
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetFirmwareInfo(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getFirmwareInfo failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            memset(firmwareInfo, 0, MAX_TRANSFER_PACKET);
            int result = dev->getFirmwareInfo(static_cast<AngPropertyID>(id), &firmwareInfo);
            if (result != 0)
                return env->NewStringUTF("");

            return env->NewStringUTF(firmwareInfo);
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jint JNICALL
jSetFirmwareInfo(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id, jstring value) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni setFirmwareInfo failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            const char *value_c = env->GetStringUTFChars(value, JNI_FALSE);
            jsize size = env->GetStringUTFLength(value);
            int rc = dev->setFirmwareInfo(static_cast<AngPropertyID>(id),value_c, size);
            env->ReleaseStringUTFChars(value, value_c);
            return rc;
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jstring JNICALL
jGetChipSeInfo(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getChipSeInfo failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            memset(firmwareLargeInfo, 0, MAX_TRANSFER_LARGE_PACKET);
            int result = dev->getChipSeInfo(static_cast<AngPropertyID>(id), &firmwareLargeInfo);
            if (result != 0)
                return env->NewStringUTF("");

            return env->NewStringUTF(firmwareLargeInfo);
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jint JNICALL
jSetChipSeInfo(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id, jstring value) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni setChipSeInfo failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            const char *value_c = env->GetStringUTFChars(value, JNI_FALSE);
            jsize size = env->GetStringUTFLength(value);
            int rc = dev->setChipSeInfo(static_cast<AngPropertyID>(id),value_c, size);
            env->ReleaseStringUTFChars(value, value_c);
            return rc;
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jbyteArray JNICALL
jGetChipSeInfoByArray(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getChipSeInfoByArray failed, please initialize first");
        return nullptr;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            memset(firmwareLargeInfo, 0, MAX_TRANSFER_LARGE_PACKET);
            int result = dev->getChipSeInfo(static_cast<AngPropertyID>(id), &firmwareLargeInfo);
            auto getFirmwareLength = []() {
                return static_cast<char>((firmwareLargeInfo[0] | (firmwareLargeInfo[1] << 8) |
                                          (firmwareLargeInfo[2] << 16) |
                                          (firmwareLargeInfo[3] << 24)));
            };

            int len = getFirmwareLength();
            jbyteArray array = env->NewByteArray(len + 4);
            env->SetByteArrayRegion(array, 0, len + 4,
                                    reinterpret_cast<const jbyte *>(firmwareLargeInfo + 4));
            //不是返回值需要调用DeleteLocalRef删除
            return array;
        }
    }
    return nullptr;
}

extern "C" JNIEXPORT jint JNICALL
jSetChipSeInfoByArray(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id, jbyteArray src, jint len) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni setChipSeInfoByArray failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            jbyte *bytes;
            bytes = env->GetByteArrayElements(src, 0);
            memset(firmwareLargeInfo, 0, MAX_TRANSFER_LARGE_PACKET);
            memcpy(firmwareLargeInfo, bytes, len);
            env->ReleaseByteArrayElements(src, bytes, 0);
            return dev->setChipSeInfo(static_cast<AngPropertyID>(id), firmwareLargeInfo, (int) len);
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jUpgradeCamera(
        JNIEnv *env,
        jclass clazz, jlong handle, jint id, jstring upgradeFile) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni upgradeCamera failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            const char *value_c = env->GetStringUTFChars(upgradeFile, JNI_FALSE);
            int rc = dev->upgradeCamera(id, value_c, deviceOnUpgradeCallback);
            env->ReleaseStringUTFChars(upgradeFile, value_c);
            return rc;
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jCancelUpgradeCamera(
        JNIEnv *env, jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni cancelUpgradeCamera failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            return dev->cancelUpgradeCamera();
        }
    }
    return ANG_STATUS_FAILED;
}

/**********************DeviceInfo**************************/

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceName2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceName2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceName().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceBus2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceBus2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceBus().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceDevId2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceDevId2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceDevId().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDevicePid2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDevicePid2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDevicePid().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceVid2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceVid2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceVid().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceUid2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceUid2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceUid().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceMcuUid(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceMcuUid failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceMcuUid().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDevicePath(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceMcuUid failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceDevPath().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceSN2(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceSN2 failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceSerialNumber().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceFirmwareVersion(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceFirmwareVersion failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceFirmwareVersion().c_str());
        }
    }
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jstring JNICALL
jGetDeviceHardwareVersion(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getDeviceHardwareVersion failed, please initialize first");
        return env->NewStringUTF("");
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        long handle_ptr = reinterpret_cast<long>(dev.get());
        if (handle == handle_ptr) {
            auto info = dev->getDeviceInfo();
            return env->NewStringUTF(info->getDeviceHardwareVersion().c_str());
        }
    }
    return env->NewStringUTF("");
}

/**********************Sensor**************************/
extern "C" JNIEXPORT jint JNICALL
jGetSensorType(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getSensorType failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            long handle_ptr = reinterpret_cast<long>(sensor.get());
            if (handle == handle_ptr) {
                return sensor->getSensorType();
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jlongArray JNICALL
jGetStreamConfigList(
        JNIEnv *env,
        jclass clazz, jlong handle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getStreamConfigList failed, please initialize first");
        return nullptr;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            long handle_ptr = reinterpret_cast<long>(sensor.get());
            if (handle == handle_ptr) {
                std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
                int num = streamConfigs.size();
                jlongArray rv = env->NewLongArray(num);
                jlong fill[num];
                for (int k = 0; k < num; ++k) {
                    long config_handle = reinterpret_cast<long>(streamConfigs[k]);
                    fill[k] = config_handle;
                }
                env->SetLongArrayRegion(rv, 0, num, fill);
                return rv;
            }
        }
    }
    return nullptr;
}


static void frameCallback(long clientHandle, std::shared_ptr<Frame> frame) {
    JniEnvSupplier suplier;
    jmethodID methodID = suplier.get_env()->GetStaticMethodID(g_frameCallbackCls, "onFrameCallback",
                                                              "(Lcom/ang/camera/Frame;)V");
    jfieldID fieldID;
    JNIEnv *env = suplier.get_env();
    jmethodID frameCtor = env->GetMethodID(g_frameRefCls, "<init>", "(J)V");
    jobject frameRefObj = env->NewObject(g_frameRefCls, frameCtor, (jlong)clientHandle);

    fieldID = env->GetFieldID(g_frameRefCls, "mType", "I");
    env->SetIntField(frameRefObj, fieldID, (jint) frame->getType());

    fieldID = env->GetFieldID(g_frameRefCls, "mFormat", "I");
    env->SetIntField(frameRefObj, fieldID, (jint) frame->getFormat());

    fieldID = env->GetFieldID(g_frameRefCls, "mIndex", "J");
    env->SetLongField(frameRefObj, fieldID, (jlong) frame->getIndex());

    jobject buffer = env->NewDirectByteBuffer(frame->getData(), frame->getDataSize());
    fieldID = env->GetFieldID(g_frameRefCls, "mData", "Ljava/nio/ByteBuffer;");
    env->SetObjectField(frameRefObj, fieldID, buffer);

    fieldID = env->GetFieldID(g_frameRefCls, "mDataSize", "I");
    env->SetIntField(frameRefObj, fieldID, (jint) frame->getDataSize());

    fieldID = env->GetFieldID(g_frameRefCls, "mTimeStamp", "J");
    env->SetLongField(frameRefObj, fieldID, (jlong) frame->getTimeStamp());

    fieldID = env->GetFieldID(g_frameRefCls, "mWidth", "I");
    env->SetIntField(frameRefObj, fieldID, (jint) frame->getWidth());

    fieldID = env->GetFieldID(g_frameRefCls, "mHeight", "I");
    env->SetIntField(frameRefObj, fieldID, (jint) frame->getHeight());

    suplier.get_env()->CallStaticVoidMethod(g_frameCallbackCls, methodID, frameRefObj);
    suplier.get_env()->ExceptionClear();
}

static void deviceOnUpgradeCallback(const AngDeviceUpgradeInfo *pInfo, void *) {
    JniEnvSupplier suplier;
    jmethodID methodID = suplier.get_env()->GetStaticMethodID(g_deviceCls, "onUpgradeCallback",
                                                              "(II)V");
    JNIEnv *env = suplier.get_env();

    jint type = (jint) pInfo->type;
    jint result = (jint) pInfo->value;
    env->CallStaticVoidMethod(g_deviceCls, methodID, type, result);
    suplier.get_env()->ExceptionClear();
}

extern "C" JNIEXPORT jint JNICALL
jStart(
        JNIEnv *env,
        jclass clazz, jlong handle, jlong streamConfigHandle) {
    ANG_LOGI("jni start handle:%u, streamConfigHandle:%u", handle, streamConfigHandle);

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni start failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            long handle_ptr = reinterpret_cast<long>(sensor.get());
            if (handle == handle_ptr) {
                std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
                for (int k = 0; k < streamConfigs.size(); ++k) {
                    ang_stream_config *streamConfig = streamConfigs[k];
                    long config_ptr = reinterpret_cast<long>(streamConfig);
                    if (config_ptr == streamConfigHandle) {
                        int rc = sensor->start(handle, streamConfig, frameCallback);
                        return rc;
                    }
                }
                return ANG_STATUS_FAILED;
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jStop(
        JNIEnv *env,
        jclass clazz, jlong handle) {
    ANG_LOGI("jni stop");

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni start failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            long handle_ptr = reinterpret_cast<long>(sensor.get());
            if (handle == handle_ptr) {
                return sensor->stop();
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jSwitchConfig(
        JNIEnv *env,
        jclass clazz, jlong handle, jlong streamConfigHandle) {
    ANG_LOGI("jni switchConfig");

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni switchConfig failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            long handle_ptr = reinterpret_cast<long>(sensor.get());
            if (handle == handle_ptr) {
                std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
                for (int k = 0; k < streamConfigs.size(); ++k) {
                    auto streamConfig = streamConfigs[k];
                    long config_ptr = reinterpret_cast<long>(streamConfig);
                    if (config_ptr == streamConfigHandle) {
                        return sensor->switchConfig(streamConfig);
                    }
                }

            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jGetStreamFormat(
        JNIEnv *env,
        jclass clazz, jlong streamConfigHandle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getStreamFormat failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
            for (int k = 0; k < streamConfigs.size(); ++k) {
                auto streamConfig = streamConfigs[k];
                long config_ptr = reinterpret_cast<long>(streamConfig);
                if (config_ptr == streamConfigHandle) {
                    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
                    return stream_config->getStreamFormat();
                }
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jGetStreamType(
        JNIEnv *env,
        jclass clazz, jlong streamConfigHandle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getStreamType failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
            for (int k = 0; k < streamConfigs.size(); ++k) {
                auto streamConfig = streamConfigs[k];
                long config_ptr = reinterpret_cast<long>(streamConfig);
                if (config_ptr == streamConfigHandle) {
                    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
                    return stream_config->getStreamType();
                }
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jGetFps(
        JNIEnv *env,
        jclass clazz, jlong streamConfigHandle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getFps failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
            for (int k = 0; k < streamConfigs.size(); ++k) {
                auto streamConfig = streamConfigs[k];
                long config_ptr = reinterpret_cast<long>(streamConfig);
                if (config_ptr == streamConfigHandle) {
                    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
                    return stream_config->getFps();
                }
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jGetWidth(
        JNIEnv *env,
        jclass clazz, jlong streamConfigHandle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getWidth failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
            for (int k = 0; k < streamConfigs.size(); ++k) {
                auto streamConfig = streamConfigs[k];
                long config_ptr = reinterpret_cast<long>(streamConfig);
                if (config_ptr == streamConfigHandle) {
                    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
                    return stream_config->getWidth();
                }
            }
        }
    }
    return ANG_STATUS_FAILED;
}

extern "C" JNIEXPORT jint JNICALL
jGetHeight(
        JNIEnv *env,
        jclass clazz, jlong streamConfigHandle) {

    if (!g_initialized || !g_deviceListPtr) {
        ANG_LOGE("jni getHeight failed, please initialize first");
        return ANG_STATUS_FAILED;
    }
    g_deviceListPtr = g_contextPtr->getDeviceList();

    for (int i = 0; i < g_deviceListPtr->getDeviceCount(); ++i) {
        auto dev = g_deviceListPtr->getDevice(i);
        auto sensors = dev->getSensorList();
        for (int j = 0; j < sensors->getSensorCount(); ++j) {
            auto sensor = sensors->getSensor(j);
            std::vector<ang_stream_config *> streamConfigs = sensor->getStreamConfigList();
            for (int k = 0; k < streamConfigs.size(); ++k) {
                auto streamConfig = streamConfigs[k];
                long config_ptr = reinterpret_cast<long>(streamConfig);
                if (config_ptr == streamConfigHandle) {
                    auto stream_config = reinterpret_cast<StreamConfig *>(streamConfig);
                    return stream_config->getHeight();
                }
            }
        }
    }
    return ANG_STATUS_FAILED;
}

static JNINativeMethod methods[] = {
        {"nInitialize",               "()I",                            (void *) jInitialize},
        {"nShutdown",                 "()I",                            (void *) jShutdown},
        {"nEnumerateDevices",         "([Ljava/lang/String;Ljava/util/ArrayList;)J",             (void *) jEnumerateDevices},
        {"nGetDeviceList",            "()J",                            (void *) jGetDeviceList},
        {"nGetSDKVersion",            "()Ljava/lang/String;",           (void *) jGetSDKVersion},
        {"nCreateCameraSession",      "(J)J",                           (void *) jCreateCameraSession},
        {"nDestroyCameraSession",     "(J)I",                           (void *) jDestroyCameraSession},
        {"nRegisterDeviceListener",   "()I",                            (void *) jRegisterDeviceListener},
        {"nUnregisterDeviceListener", "()I",                            (void *) jUnregisterDeviceListener},
        {"nEnableLogToFile",          "(Z)I",                           (void *) jEnableLogToFile},
        {"nEnableAutoReconnect",      "(Z)I",                           (void *) jEnableAutoReconnect},

        {"nCameraSessionStart",       "(JIIIIIJ)I",                      (void *) jCameraSessionStart},
        {"nCameraSessionStop",        "(J)I",                           (void *) jCameraSessionStop},

        {"nGetDeviceCount",           "(J)I",                           (void *) jGetDeviceCount},
        {"nGetDeviceName",            "(JI)Ljava/lang/String;",         (void *) jGetDeviceName},
        {"nGetDeviceBus",             "(JI)Ljava/lang/String;",         (void *) jGetDeviceBus},
        {"nGetDeviceDevId",           "(JI)Ljava/lang/String;",         (void *) jGetDeviceDevId},
        {"nGetDevicePid",             "(JI)Ljava/lang/String;",         (void *) jGetDevicePid},
        {"nGetDeviceVid",             "(JI)Ljava/lang/String;",         (void *) jGetDeviceVid},
        {"nGetDeviceUid",             "(JI)Ljava/lang/String;",         (void *) jGetDeviceUid},
        {"nGetDeviceSN",              "(JI)Ljava/lang/String;",         (void *) jGetDeviceSN},
        {"nGetDevice",                "(JI)J",                          (void *) jGetDevice},
        {"nGetDeviceBySN",            "(JLjava/lang/String;)J",         (void *) jGetDeviceBySN},
        {"nGetDeviceByUid",           "(JLjava/lang/String;)J",         (void *) jGetDeviceByUid},

        {"nOpen",                     "(JI)I",                          (void *) jAngOpen},
        {"nOpenMcu",                  "(JI)I",                          (void *) jAngOpenMcu},
        {"nClose",                    "(J)I",                           (void *) jAngClose},
        {"nReboot",                   "(J)I",                           (void *) jAngReboot},
        {"nGetDeviceInfo",            "(J)Lcom/ang/camera/DeviceInfo;", (void *) jGetDeviceInfo},
        {"nGetSensorList",            "(J)[J",                          (void *) jGetSensorList},
        {"nCommunicateWithMcu",       "(JLjava/lang/String;)Ljava/lang/String;",  (void *) jCommunicateWithMcu},
        {"nGetFirmwareInfo",          "(JI)Ljava/lang/String;",         (void *) jGetFirmwareInfo},
        {"nSetFirmwareInfo",          "(JILjava/lang/String;)I",        (void *) jSetFirmwareInfo},
        {"nGetChipSeInfo",            "(JI)Ljava/lang/String;",         (void *) jGetChipSeInfo},
        {"nSetChipSeInfo",            "(JILjava/lang/String;)I",        (void *) jSetChipSeInfo},
        {"nGetChipSeInfoByArray",     "(JI)[B",                         (void *) jGetChipSeInfoByArray},
        {"nSetChipSeInfoByArray",     "(JI[BI)I",                       (void *) jSetChipSeInfoByArray},
        {"nUpgradeCamera",            "(JILjava/lang/String;)I",        (void *) jUpgradeCamera},
        {"nCancelUpgradeCamera",      "(J)I",                           (void *) jCancelUpgradeCamera},

        {"nGetDeviceName2",           "(J)Ljava/lang/String;",          (void *) jGetDeviceName2},
        {"nGetDeviceBus2",            "(J)Ljava/lang/String;",          (void *) jGetDeviceBus2},
        {"nGetDeviceDevId2",          "(J)Ljava/lang/String;",          (void *) jGetDeviceDevId2},
        {"nGetDevicePid2",            "(J)Ljava/lang/String;",          (void *) jGetDevicePid2},
        {"nGetDeviceVid2",            "(J)Ljava/lang/String;",          (void *) jGetDeviceVid2},
        {"nGetDeviceUid2",            "(J)Ljava/lang/String;",          (void *) jGetDeviceUid2},
        {"nGetDeviceMcuUid",          "(J)Ljava/lang/String;",          (void *) jGetDeviceMcuUid},
        {"nGetDevicePath",            "(J)Ljava/lang/String;",          (void *) jGetDevicePath},
        {"nGetDeviceSN2",             "(J)Ljava/lang/String;",          (void *) jGetDeviceSN2},
        {"nGetDeviceFirmwareVersion", "(J)Ljava/lang/String;",          (void *) jGetDeviceFirmwareVersion},
        {"nGetDeviceHardwareVersion", "(J)Ljava/lang/String;",          (void *) jGetDeviceHardwareVersion},

        {"nGetSensorType",            "(J)I",                           (void *) jGetSensorType},
        {"nGetStreamConfigList",      "(J)[J",                          (void *) jGetStreamConfigList},
        {"nStart",                    "(JJ)I",                          (void *) jStart},
        {"nStop",                     "(J)I",                           (void *) jStop},
        {"nSwitchConfig",             "(JJ)I",                          (void *) jSwitchConfig},
        {"nGetStreamFormat",          "(J)I",                           (void *) jGetStreamFormat},
        {"nGetStreamType",            "(J)I",                           (void *) jGetStreamType},
        {"nGetFps",                   "(J)I",                           (void *) jGetFps},
        {"nGetWidth",                 "(J)I",                           (void *) jGetWidth},
        {"nGetHeight",                "(J)I",                           (void *) jGetHeight},
};

JNIEXPORT int JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    jclass javaClass = env->FindClass(JNI_REG_CLASS);
    if (javaClass == nullptr) {
        return JNI_ERR;
    }
    int methodCount = sizeof(methods) / sizeof(methods[0]);
    if (env->RegisterNatives(javaClass, methods, methodCount) < 0) {
        return JNI_ERR;
    }
    g_pVm = vm;
    jclass frameCallbackCls = env->FindClass("com/ang/camera/FrameCallback");
    jclass deviceCls = env->FindClass("com/ang/camera/Device");
    jclass deviceWatcherCls = env->FindClass("com/ang/camera/DeviceWatcher");
    g_frameCallbackCls = reinterpret_cast<jclass>(env->NewGlobalRef(frameCallbackCls));
    g_deviceCls = reinterpret_cast<jclass>(env->NewGlobalRef(deviceCls));
    g_deviceWatcherCls = reinterpret_cast<jclass>(env->NewGlobalRef(deviceWatcherCls));

    jclass frameRefCls = env->FindClass("com/ang/camera/Frame");
    g_frameRefCls = reinterpret_cast<jclass>(env->NewGlobalRef(frameRefCls));

    return JNI_VERSION_1_6;
}

JNIEXPORT
void JNICALL JNI_OnUnload(JavaVM * /*vm*/, void * /*reserved*/) {
    JNIEnv *env;
    if (g_pVm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return;
    }
    env->DeleteGlobalRef(g_frameCallbackCls);
    env->DeleteGlobalRef(g_deviceCls);
    env->DeleteGlobalRef(g_frameRefCls);
    env->DeleteGlobalRef(g_deviceWatcherCls);
    g_pVm = NULL;
}