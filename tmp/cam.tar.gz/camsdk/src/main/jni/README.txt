该jni目录只是为了采用ndk-build的方式来编译AngCamSDK\camsdk\src\main\cpp\src\thirdparty
目录下的libuvc-saki,该目录的UVCCamera项目中没使用，只是从https://github.com/saki4510t/UVCCamera开源项目中
挪过来libuvc和libusb，目的是使用saki4510t的libuvc
编译方式直接在该目录(即AngCamSDK\camsdk\src\main\jni)执行ndk-build